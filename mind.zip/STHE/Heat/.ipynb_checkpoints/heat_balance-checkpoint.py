from .Import.HeatBalance.HB_HSS import *

class HeatBalance():
    
    def __init__(self, ProjectData, BalanceData=[]):
        self.PD = ProjectData
        self.BalanceData = BalanceData
        if BalanceData == []:
            print('Сводим тепловой баланс...')
            self.BalanceData = initialize(self.PD.UserInput[0], self.PD.UserInput[1], self.PD.UserInput[2])
        
    def __repr__(self):
        return str(self.BalanceData)