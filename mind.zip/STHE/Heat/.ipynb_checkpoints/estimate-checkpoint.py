from .Import.EstimatedConstructions.EST import *

class Estimate():
    
    def __init__(self, ProjectData):
        self.PD = ProjectData
        self.EstimatedCalcData = Flow_Diagram_Of_Coolants_grid_generation(self.PD.HeatBalanceData.BalanceData,  self.PD.UserAnswers)
        self.DataAfterFilter = Best_Of_Grid_selection(self.EstimatedCalcData)
        #print(self.DataAfterFilter)
        
    def __repr__(self):
        return str(self.DataAfterFilter)