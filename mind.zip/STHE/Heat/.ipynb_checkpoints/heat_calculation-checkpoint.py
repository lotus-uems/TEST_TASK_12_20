import copy
from pprint import pprint
from openpyxl import load_workbook
import subprocess

from .Import.TubePattern.Magic import *
from .Import.TubePattern.diameters import *
from .Import.TubeSide.TubeHydraulics import *
from .Import.ShellSide.ShellL_G import *
from .Import.ShellSide.ShellHydraulics import *
from .Import.ShellSide.ShellPeretoki import *
from .Import.ShellSide.ShellAlpha import *
from .Import.ShellSide.ShellEntrance import *
from .Import.ShellSide.BaffleCutout import *
from .Import.ShellSide.test_baffle_cutout_F import *
from .Import.ShellSide.BafflePitch import *
from .Import.ShellSide.test_baffle_pitch_F import *
from .Import.ShellSide.test_result import *
from .Import.ShellSide.test_result_F import *
from .Import.ShellSide.test_choice_of_nozzle import *
from .Import.ShellSide.DrawShell import *
from .Import.TubeSide.TubeAlpha import *
from .Import.Interpolation import *
from .Import.TemperatureOfPipeWall import *
from .Import.MaxTempDeltaShellAndTube import *
from .Import.CalculatedK import *

class STHE_HeatCalculation():
    
    def __init__(self, ConstructionData, ProjectData):
        #print()
        print('Считаем конструкцию с диаметром:', ConstructionData.SDiam_in)
        print('Конструкция:', ConstructionData.Solution)
        
        self.log = []
        
        self.CalculatedKArray = []
        
        self.PD = ProjectData
        self.CD = ConstructionData
        self.PatternCharacter = 'Треугольники' # ЗАПЛАТКА!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        self.VDS = False # ЗАПЛАТКА!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        self.TWall = (self.CD.TDiam - self.CD.TDiam_in) / 2
        
        self.ShellRoV = 2250
        if self.CD.ShellType == 'E':
            self.BuildTubePattern(self.PatternCharacter, self.CD.TDiam*1000, self.CD.TubePassNum, self.CD.TubeNum, None, False, self.CD.FloatingHead, self.CD.UType, False, False, 5, 0) # ЗАПЛАТКА!!!!!!!!!!!!!!!
        if self.CD.ShellType == 'F':
            self.BuildTubePattern(self.PatternCharacter, self.CD.TDiam*1000, self.CD.TubePassNum, self.CD.TubeNum, None, False, self.CD.FloatingHead, self.CD.UType, True, False, 5, 0) # ЗАПЛАТКА!!!!!!!!!!!!!!!
        self.CalcTubeHydraulics()
        self.CalcShellL_G()
        self.CalcShellGeometry()
        #print('VelocityFlag', self.VelocityFlag)
        if self.VelocityFlag == True:
            self.CalcShellVelocity()
            self.CalcShellHydraulics()
            self.CheckShellHydraulics()
            self.CalcShellEntrance()
            self.CalcShellPeretoki()
            self.CalcShellAlpha()
            self.CalcTubeAlpha()
            self.CalcTemperatureOfPipeWall()
            self.CalcMaxTempDeltaShellAndTube()
            self.CalcK()
            print('DShellOuter', self.DShellOuter)
            print('Tubes_By_Pass', self.Tubes_By_Pass)
            print('TubeLenght', self.CD.TubeLenght)
            #print('res_baffle_pitch', self.res_baffle_pitch)
            #print('ShellVelocities', self.ShellVelocities)
        else:
            print('До свидания, вариант!')
            
        print('LOG')
        #pprint(self.log)
        print()
        print()
        
    #def __repr__(self):
        #return str(self.K)
    
    def BuildTubePattern(self, PatternCharacter, d, N_tube_passes, N_tubes_in_pass, Displacement_pipe, Fluoroplastic_Seal, Floating_head, U, DS, VDS, Design_clearance, DStart):
        #print('Строим разбивку')
        ResultArray = Magic(PatternCharacter, d, N_tube_passes, N_tubes_in_pass, Displacement_pipe, Fluoroplastic_Seal, Floating_head, U, DS, VDS, Design_clearance, DStart)
        self.TubePattern1 = ResultArray[0]
        print('OTL', self.TubePattern1.OTL)
        self.Tubes_By_Pass = ResultArray[1]
        self.ShellCutoutArray = ResultArray[2]
        self.ZZ = ResultArray[3]
        #print('ZZ', self.ZZ)
        self.DShellOuter = ResultArray[4]
        self.CD.SDiam_in = Diameters[self.DShellOuter][0]
        
        self.CD.Design_user_input['SHELL']['IN_FlangeAngle'] = ResultArray[5][0]
        self.CD.Design_user_input['TUBE']['IN_FlangeAngle'] = ResultArray[5][1]
        self.CD.Design_user_input['TUBE']['OUT_FlangeAngle'] = ResultArray[5][2]
        
        self.log.append(['BuildTubePattern', ['TubePattern1', self.TubePattern1], ['Tubes_By_Pass', self.Tubes_By_Pass], ['ShellCutoutArray', self.ShellCutoutArray], ['ZZ', self.ZZ], ['DShellOuter', self.DShellOuter], ['CD.SDiam_in', self.CD.SDiam_in]])

    def CalcTubeHydraulics(self):
        #print('Считаем гидравлику трубного')
        self.TubeInterpArr = GetInterpolatedProps(self.PD.HeatBalanceData.BalanceData, self.CD.tube, self.Tubes_By_Pass)
        #print('TubeInterpArr', self.TubeInterpArr)
        Result = GetTubeHydraulics(self.TubeInterpArr, 1, 1, self.Tubes_By_Pass, self.CD.TDiam, self.CD.TDiam_in, self.CD.TubeLenght)
        self.TubeHydraulics = Result
        self.TubeNozzles = Result[6]
        self.TubePattern1.DNozzle = self.TubeNozzles[0]*1000 #Надо разобраться с единицами в TubePattern
        self.TubeVelocityAveArray = Result[7]
        print('TubeVelocityAveArray', self.TubeVelocityAveArray)
        self.TubeSideDeltaP = Result[0]
        if self.TubeSideDeltaP > 1.1 * self.PD.UserAnswers['max_pressure_drop'][self.CD.tube]:
            print()
            print('ВНИМАНИЕ! Потери давления в трубном пространстве выходят за допустимый предел')
            print()
        print('TubeSideDeltaP', self.TubeSideDeltaP)
        print('Массив гидравлики в ТРУБНОМ:', self.TubeHydraulics)

        self.log.append(['CalcTubeHydraulics', ['TubeHydraulics', self.TubeHydraulics], ['TubeSideDeltaP', self.TubeSideDeltaP], ['TubeNozzles', self.TubeNozzles], ['TubeVelocityAveArray', self.TubeVelocityAveArray]])
    
    def CalcShellGeometry(self):
        res_baffle_cutout = None
        res_baffle_pitch = None
        if self.CD.ShellType == 'E':
            #print('DShellOuter', self.DShellOuter)
            arr = [self.CD.TubeLenght/2, self.CD.TubeLenght/2]
            flag = False
            while flag == False:
                #print('arr', arr)
                self.ShellInterpArr = GetInterpolatedProps(self.PD.HeatBalanceData.BalanceData, self.CD.shell, arr)
                #print('ShellInterpArr', self.ShellInterpArr[1])
                res_baffle_cutout = test_baffle_cutout(self.ShellCutoutArray, self.CD.TDiam, 0.2, self.ShellInterpArr[1], self.ShellRoV, 0.35)
                #print('test_baffle_cutout', res_baffle_cutout)
                if res_baffle_cutout == 'Ни один вариант не удовлетворяет заданным условиям. Дай следующий.':
                    print('Следующий cutout')
                    self.BuildTubePattern(self.PatternCharacter, self.CD.TDiam*1000, self.CD.TubePassNum, self.CD.TubeNum, None, False, self.CD.FloatingHead, self.CD.UType, False, False, 5, self.DShellOuter)
                    #print('DShellOuter', self.DShellOuter)
                    self.CalcTubeHydraulics()
                    arr = [self.CD.TubeLenght/2, self.CD.TubeLenght/2]
                elif res_baffle_cutout[0] == 'Error_мал_набивка':
                    #print('Переход на другой тип кожуха')
                    flag = True
                else:
                    res_baffle_pitch = test_baffle_pitch(self.CD.TubeLenght, [0, 0], self.ShellRoV, self.ShellRoV, self.CD.TDiam, 0.2, 2, 1, self.ShellRoV, 0.35, self.TWall, self.ShellInterpArr[1], res_baffle_cutout, self.ZZ)
                    print('res_baffle_pitch input', self.CD.TubeLenght, [0, 0], self.ShellRoV, self.ShellRoV, self.CD.TDiam, 0.2, 2, 1, self.ShellRoV, 0.35, self.TWall, self.ShellInterpArr[1], res_baffle_cutout, self.ZZ)
                    if res_baffle_pitch[0] == 'Error':
                        if res_baffle_pitch[1] == "Недостаточно длины. Попробуйте расположение патрубков - на одну сторону":
                            self.CD.A = 0
                            res_baffle_pitch = test_baffle_pitch(self.CD.TubeLenght, [0, 0], self.ShellRoV, self.ShellRoV, self.CD.TDiam, 0.2, 2, 0, self.ShellRoV, 0.35, self.TWall, self.ShellInterpArr[1], res_baffle_cutout, self.ZZ)
                            if res_baffle_pitch[0] == 'Error':
                                #print('res_baffle_pitch', res_baffle_pitch[1], 'ВСЁ!')
                                flag = True
                            else:
                                if len(res_baffle_pitch[1]) != len(arr):
                                    arr = res_baffle_pitch[1]
                                else:
                                    flag = True
                        else:
                            #print('res_baffle_pitch', res_baffle_pitch[1])
                            flag = True
                    else:
                        #print('res_baffle_pitch', res_baffle_pitch[1])
                        if len(res_baffle_pitch[1]) != len(arr):
                            arr = res_baffle_pitch[1]
                        else:
                            flag = True
                            
        if self.CD.ShellType == 'F':
            #print('DShellOuter', self.DShellOuter)
            #print('ShellCutoutArray', self.ShellCutoutArray)
            n_arr1 = self.ShellCutoutArray[0][1][0]/(self.ShellCutoutArray[0][1][0]+self.ShellCutoutArray[0][1][1])
            n_arr2 = self.ShellCutoutArray[0][1][1]/(self.ShellCutoutArray[0][1][0]+self.ShellCutoutArray[0][1][1])
            arr = [[n_arr1/3, n_arr1/3, n_arr1/3], [n_arr2/3, n_arr2/3, n_arr2/3]]
            flag = False
            while flag == False:
                #print('arr', arr)
                arr1 = arr[0] + arr[1]
                self.ShellInterpArr = GetInterpolatedProps(self.PD.HeatBalanceData.BalanceData, self.CD.shell, arr1)
                GIP_1 = []
                GIP_2 = []
                #print('ShellInterpArr', self.ShellInterpArr[1])
                
                for i in range(len(arr[0])+1):
                    GIP_1.append(self.ShellInterpArr[1][i])
                    
                for k in range(len(arr[0]), len(arr[1])+len(arr[0])+1):
                    GIP_2.append(self.ShellInterpArr[1][k])
                    
                #print('GIP_1', GIP_1)
                #print('GIP_2', GIP_2)
                res_baffle_cutout = test_baffle_cutout_F(self.ShellCutoutArray, self.CD.TDiam, 0.2, GIP_1, GIP_2, self.ShellRoV, 0.35, 'DS')
                #print('test_baffle_cutout', res_baffle_cutout)
                if res_baffle_cutout == 'Ни один вариант не удовлетворяет заданным условиям. Дай следующий.':
                    print('Следующий cutout')
                    self.BuildTubePattern(self.PatternCharacter, self.CD.TDiam*1000, self.CD.TubePassNum, self.CD.TubeNum, None, False, self.CD.FloatingHead, self.CD.UType, True, False, 5, self.DShellOuter)
                    #print('DShellOuter', self.DShellOuter)
                    self.CalcTubeHydraulics()
                    arr = [[n_arr1/3, n_arr1/3, n_arr1/3], [n_arr2/3, n_arr2/3, n_arr2/3]]
                elif res_baffle_cutout[0] == 'Error_мал_набивка':
                    #print('Переход на другой тип кожуха')
                    flag = True
                else:
                    res_baffle_pitch = test_baffle_pitch_F(self.CD.TubeLenght, [0, 0], self.ShellRoV, self.ShellRoV, self.CD.TDiam, 0.2, 2, self.ShellRoV, 0.35, self.TWall, GIP_1, GIP_2, res_baffle_cutout, self.ZZ)
                    print('res_baffle_pitch input', self.CD.TubeLenght, [0, 0], self.ShellRoV, self.ShellRoV, self.CD.TDiam, 0.2, 2, self.ShellRoV, 0.35, self.TWall, GIP_1, GIP_2, res_baffle_cutout, self.ZZ)
                    if res_baffle_pitch[0] == 'Error':
                        if res_baffle_pitch[1] == "Недостаточно длины. Попробуйте расположение патрубков - на одну сторону":
                            res_baffle_pitch = test_baffle_pitch(self.CD.TubeLenght, [0, 0], self.ShellRoV, self.ShellRoV, self.CD.TDiam, 0.2, 2, 0, self.ShellRoV, 0.35, self.TWall, self.ShellInterpArr[1], res_baffle_cutout, self.ZZ)
                            if res_baffle_pitch[0] == 'Error':
                                #print('res_baffle_pitch', res_baffle_pitch[1], 'ВСЁ!')
                                flag = True
                            else:
                                if len(res_baffle_pitch[1]) != len(arr):
                                    arr = res_baffle_pitch[1]
                                else:
                                    flag = True
                        else:
                            #print('res_baffle_pitch', res_baffle_pitch[1])
                            flag = True
                    else:
                        #print('res_baffle_pitch[1]', res_baffle_pitch[1])
                        if len(res_baffle_pitch[1]) != len(arr):
                            arr = res_baffle_pitch[1]
                        else:
                            flag = True
                        
        #print('res_baffle_cutout', res_baffle_cutout)
        if res_baffle_cutout != 'Ни один вариант не удовлетворяет заданным условиям. Дай следующий.' and res_baffle_cutout[0] != 'Error_мал_набивка' and res_baffle_pitch[0] != 'Error':
            self.VelocityFlag = True
            self.res_baffle_cutout = res_baffle_cutout
            print('res_baffle_cutout', self.res_baffle_cutout)
            self.res_baffle_pitch = res_baffle_pitch
            print('res_baffle_pitch', self.res_baffle_pitch)
            
            if len(self.res_baffle_pitch[1]) % 2 == 0:
                self.CD.Design_user_input['SHELL']['OUT_FlangeAngle'] = self.TubePattern1.ShellInNozzleAngle
            else:
                self.CD.Design_user_input['SHELL']['OUT_FlangeAngle'] = self.TubePattern1.ShellInNozzleAngle + 180

            self.log.append(['CalcShellGeometry', ['res_baffle_cutout', self.res_baffle_cutout], ['res_baffle_pitch', self.res_baffle_pitch], ['VelocityFlag', self.VelocityFlag]])
        else:
            self.VelocityFlag = False
            print('res_baffle_pitch', res_baffle_pitch)
            self.log.append(['CalcShellGeometry', ['res_baffle_cutout', res_baffle_cutout], ['res_baffle_pitch', res_baffle_pitch], ['VelocityFlag', self.VelocityFlag]])
  
    def CalcShellVelocity(self):
        self.ShellVelocities = ['Error', 'Ни один вариант не удовлетворяет заданным условиям. Дай следующий.']
        while self.ShellVelocities[1] == 'Ни один вариант не удовлетворяет заданным условиям. Дай следующий.':
            if self.VelocityFlag == True:
                if self.CD.ShellType == "E":
                    self.ShellInterpArr = GetInterpolatedProps(self.PD.HeatBalanceData.BalanceData, self.CD.shell, self.res_baffle_pitch[1])
                    self.ShellNozzles = test_choice_of_nozzle(self.ShellInterpArr[1], [0, 0], self.ShellRoV)
                    #print('ShellNozzles', self.ShellNozzles)
                    self.ShellVelocities = test_result(self.ShellNozzles, self.ShellInterpArr[1], self.res_baffle_pitch, self.ZZ, self.ShellRoV, self.ShellRoV, self.ShellRoV, self.res_baffle_cutout)
                    #print('ShellVelocities', self.ShellVelocities)
                    if self.ShellVelocities[1] == 'Ни один вариант не удовлетворяет заданным условиям. Дай следующий.':
                        print('Следующий velocity')
                        self.BuildTubePattern(self.PatternCharacter, self.CD.TDiam*1000, self.CD.TubePassNum, self.CD.TubeNum, None, False, self.CD.FloatingHead, self.CD.UType, False, False, 5, self.DShellOuter)
                        #print('DShellOuter', self.DShellOuter)
                        self.CalcTubeHydraulics()
                        self.CalcShellGeometry()
                elif self.CD.ShellType == "F":
                    array = self.res_baffle_pitch[1][0][0] + self.res_baffle_pitch[1][1][0]
                    self.ShellInterpArr = GetInterpolatedProps(self.PD.HeatBalanceData.BalanceData, self.CD.shell, array)
                    GIP_1 = []
                    GIP_2 = []

                    for i in range(len(self.res_baffle_pitch[1][0][0])+1):
                        GIP_1.append(self.ShellInterpArr[1][i])

                    for k in range(len(self.res_baffle_pitch[1][0][0]), len(self.res_baffle_pitch[1][1][0])+len(self.res_baffle_pitch[1][0][0])+1):
                        GIP_2.append(self.ShellInterpArr[1][k])
                    
                    self.ShellNozzles = test_choice_of_nozzle(self.ShellInterpArr[1], [0, 0], self.ShellRoV)
                    #print('ShellNozzles', self.ShellNozzles)
                    self.ShellVelocities = test_result_F(self.ShellNozzles, GIP_1, GIP_2, self.res_baffle_pitch, self.ZZ, self.ShellRoV, self.ShellRoV, self.ShellRoV, self.res_baffle_cutout, self.ShellCutoutArray)
                    #print('ShellVelocities', self.ShellNozzles, GIP_1, GIP_2, self.res_baffle_pitch, self.ZZ, self.ShellRoV, self.ShellRoV, self.ShellRoV, self.res_baffle_cutout, self.ShellCutoutArray)
                    if self.ShellVelocities[1] == 'Ни один вариант не удовлетворяет заданным условиям. Дай следующий.':
                        print('Следующий velocity')
                        self.BuildTubePattern(self.PatternCharacter, self.CD.TDiam*1000, self.CD.TubePassNum, self.CD.TubeNum, None, False, self.CD.FloatingHead, self.CD.UType, True, False, 5, self.DShellOuter)
                        #print('DShellOuter', self.DShellOuter)
                        self.CalcTubeHydraulics()
                        self.CalcShellGeometry()
                #print('res', self.ShellVelocities)

                self.log.append(['CalcShellVelocity', ['ShellNozzles', self.ShellNozzles], ['ShellVelocities', self.ShellVelocities]])
                
            else:
                break
        #print('После цикла', self.ShellVelocities)
        
    def CalcShellHydraulics(self):
        if self.VelocityFlag == True:
            #print('Считаем гидравлику межтрубного')
            # Массовый расход в межтрубном, кг/с
            G = self.PD.HeatBalanceData.BalanceData[3][self.CD.shell]['IN']['FLOW']['Mass Flow']
            if self.res_baffle_pitch[0] != 'Error' and self.ShellVelocities[0] != 'Error':
                
                if self.CD.ShellType == "E": 
                    self.ShellInterpArr = GetInterpolatedProps(self.PD.HeatBalanceData.BalanceData, self.CD.shell, self.res_baffle_pitch[1]) # [100, 150, 200] - массив с шагами перегородок
                    # Количество поперечных перегородок на пути среды (l`)
                    Number_of_buffles = len(self.res_baffle_pitch[1]) - 1
                    # Количество штуцеров на входе в межтрубное
                    N_IN_nozzle = 1
                    # Количество штуцеров на выходе из межтрубного
                    N_OUT_nozzle = 1
                    # Диаметр штуцеров на входе в межтрубное, мм
                    d_IN_nozzle = self.ShellNozzles[0]
                    # Диаметр штуцеров на выходе из межтрубного, мм
                    d_OUT_nozzle = self.ShellNozzles[1]
                    # Количество ПОПЕРЕЧНО ОМЫВАЕМЫХ РЯДОВ В КАЖДОМ ПРОЕМЕ
                    Number_of_cross_rows_ARRAY = self.ShellVelocities[1][8]
                    #print('Number_of_cross_rows_ARRAY', Number_of_cross_rows_ARRAY)
                    Velocity_opening_middle_ARRAY = self.ShellVelocities[1][0]
                    #print('Velocity_opening_middle_ARRAY', Velocity_opening_middle_ARRAY)
                    #print('Velocity_opening_middle_ARRAY', Velocity_opening_middle_ARRAY)
                    Velocity_CUT_ARRAY = self.ShellVelocities[1][5]
                    #print('Velocity_CUT_ARRAY', Velocity_CUT_ARRAY)
                    #print('Velocity_CUT_ARRAY', Velocity_CUT_ARRAY)
                    
                elif self.CD.ShellType == "F": 
                    array = self.res_baffle_pitch[1][0][0] + self.res_baffle_pitch[1][1][0]
                    #print('array', len(array))
                    #print('ShellVelocities', len(self.ShellVelocities[1][0]), len(self.ShellVelocities[1][8]))
                    self.ShellInterpArr = GetInterpolatedProps(self.PD.HeatBalanceData.BalanceData, self.CD.shell, array) # [100, 150, 200] - массив с шагами перегородок
                    # Количество поперечных перегородок на пути среды (l`)
                    Number_of_buffles = len(array) - 1
                    # Количество штуцеров на входе в межтрубное
                    N_IN_nozzle = 1
                    # Количество штуцеров на выходе из межтрубного
                    N_OUT_nozzle = 1
                    # Диаметр штуцеров на входе в межтрубное, мм
                    d_IN_nozzle = self.ShellNozzles[0]
                    # Диаметр штуцеров на выходе из межтрубного, мм
                    d_OUT_nozzle = self.ShellNozzles[1]
                    # Количество ПОПЕРЕЧНО ОМЫВАЕМЫХ РЯДОВ В КАЖДОМ ПРОЕМЕ
                    Number_of_cross_rows_ARRAY = self.ShellVelocities[1][8]
                    #print('Number_of_cross_rows_ARRAY', Number_of_cross_rows_ARRAY)
                    Velocity_opening_middle_ARRAY = self.ShellVelocities[1][0]
                    #print('Velocity_opening_middle_ARRAY', Velocity_opening_middle_ARRAY)
                    #print('Velocity_opening_middle_ARRAY', Velocity_opening_middle_ARRAY)
                    Velocity_CUT_ARRAY = self.ShellVelocities[1][5]
                    #print('Velocity_CUT_ARRAY', Velocity_CUT_ARRAY)
                    #print('Velocity_CUT_ARRAY', Velocity_CUT_ARRAY)
                
                self.ShellHydraulics = GetShellHydraulics(self.CD.TDiam, G, self.CD.ShellPassNum, Number_of_buffles, N_IN_nozzle, N_OUT_nozzle, d_IN_nozzle, d_OUT_nozzle, Number_of_cross_rows_ARRAY, self.ShellInterpArr, Velocity_opening_middle_ARRAY, Velocity_CUT_ARRAY, self.PatternCharacter)
                #print('ShellHydraulics', self.ShellHydraulics)
                
                self.ShellSideDeltaP = self.ShellHydraulics[0]
                print('ShellSideDeltaP', self.ShellSideDeltaP)
                print('Массив гидравлики МЕЖТРУБНОГО:', self.ShellHydraulics)
                
    def CheckShellHydraulics(self):
        if self.ShellSideDeltaP == 'Данный тип кожуха еще не описан':
            print('Пока не считаем гидравлику межтрубного для данного типа корпуса')
        elif type(self.ShellSideDeltaP) == str:
            print('Ошибка подсчета гидравлики межтрубного')
        elif self.ShellSideDeltaP > 1.1 * self.PD.UserAnswers['max_pressure_drop'][self.CD.shell]:
            print()
            print('ВНИМАНИЕ! Потери давления в межтрубном пространстве выходят за допустимый предел')
            print()

            while self.ShellSideDeltaP > 1.1 * self.PD.UserAnswers['max_pressure_drop'][self.CD.shell] and self.VelocityFlag == True:
                self.ShellRoV = self.ShellRoV - self.ShellRoV * 0.1
                self.CalcShellGeometry()
                self.CalcShellVelocity()
                self.CalcShellHydraulics()
                print('ShellRoV', self.ShellRoV, 'ShellSideDeltaP', self.ShellSideDeltaP)

        print('ShellSideDeltaP', self.ShellSideDeltaP)

        self.log.append(['CalcShellHydraulics', ['ShellHydraulics', self.ShellHydraulics], ['ShellSideDeltaP', self.ShellSideDeltaP]])
        
    def CalcShellEntrance(self):
        if self.VelocityFlag == True:
            # Объемный расход в межтрубном НА ВХОДЕ, м3/с
            result = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, self.CD.shell, 'IN')
            VolumeFlowIN = result['MIX'][1]
            Plate = False # ЗАПЛАТКА: БЕЗ ПЛАСТИНЫ !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            SPlate = 0 # ЗАПЛАТКА: БЕЗ ПЛАСТИНЫ !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            EntranceBaffleSpacing = 350 # ЗАПЛАТКА

            HArray = GetH(self.TubePattern1, self.VDS)
            h1 = HArray[0]
            h2 = HArray[1]
            K = HArray[2]
            if self.PatternCharacter == 'Треугольники' or self.PatternCharacter =='Коридорные квадраты':
                F2 = 1
            elif self.PatternCharacter == 'Повернутые треугольники':
                F2 = 0.866
            elif self.PatternCharacter == 'Квадраты':
                F2 = 0.707
            self.ShellEntranceArray = ShellEntrance(self.TubePattern1, VolumeFlowIN, Plate, SPlate, EntranceBaffleSpacing, h1, h2, F2, K)
            #print('ShellEntranceArray', ShellEntranceArray)

            self.log.append(['CalcShellEntrance', ['ShellEntranceArray', self.ShellEntranceArray]])
    
    def CalcShellPeretoki(self):
        if self.VelocityFlag == True:
            #print('Считаем коэффициент на перетоки В КАЖДОМ ПРОЕМЕ')
            if self.ShellHydraulics[0] != 'Данный тип кожуха еще не описан':
                Re_ave_array = self.ShellHydraulics[5]
                #print('Re_ave_array', Re_ave_array)
                p_array = self.ShellVelocities[1][8]
                N_tubes_array = []
                if self.CD.ShellType == "E":
                    for i in range(len(self.res_baffle_pitch[1])):
                        N_tubes_array.append(sum(self.Tubes_By_Pass)) #Общее количество труб, расположенных в разрезе текущего хода межтрубного (для одного хода в межтрубном это будет массив из значений, равных одному числу)
                elif self.CD.ShellType == "F":
                    array = self.res_baffle_pitch[1][0][0] + self.res_baffle_pitch[1][1][0]
                    for i in range(len(array)):
                        N_tubes_array.append(sum(self.Tubes_By_Pass)) #Общее количество труб, расположенных в разрезе текущего хода межтрубного (для одного хода в межтрубном это будет массив из значений, равных одному числу)
                #print('N_tubes_array', len(N_tubes_array))
                N_in_cut_array = self.ShellVelocities[1][10]
                #print('N_in_cut_array', len(N_in_cut_array))
                baffle_step_array = self.ShellVelocities[1][11] # ЗАПЛАТКА: ВОЗВРАЩАЕМ ОТ ТАНИ шаг ДЛЯ КАЖДОГО ПРОЕМА, м !!!!!!!!!!!!!!!
                #print('baffle_step_array', len(baffle_step_array))
                baffle_sq_array = self.ShellVelocities[1][7] # ЗАПЛАТКА: ВОЗВРАЩАЕМ ОТ ТАНИ шаг ДЛЯ КАЖДОГО ПРОЕМА, м2 !!!!!!!!!!!!!!!
                #print('baffle_sq_array', len(baffle_sq_array))
                length_middle_array = self.ShellVelocities[1][12] # Средневзвешенные зазоры, м
                #print('length_middle_array', len(length_middle_array))
                Ns = 2
                baffle_angle_array = self.ShellVelocities[1][9] # Углы перегородок в градусах
                #print('baffle_angle_array', len(baffle_angle_array))
                sealings = None
                if self.CD.Fluoroplastic_Seal == True:
                    sealings = 'Фторопласт'
                self.ShellPeretoki = GetShellPeretoki(Re_ave_array, p_array, self.CD.TDiam, self.TubePattern1.step, N_tubes_array, N_in_cut_array, self.CD.SDiam_in, self.TubePattern1.OTL, baffle_step_array, self.CD.ShellPassNum, baffle_sq_array, length_middle_array, Ns, baffle_angle_array, sealings)
                #print('ShellPeretoki', self.ShellPeretoki)
                self.log.append(['CalcShellPeretoki', ['ShellPeretoki', self.ShellPeretoki], ['VelocityFlag', self.VelocityFlag]])
            else:
                self.VelocityFlag = False
                print('Чето не то с гидравликой промежтруба')
                
    def CalcShellL_G(self):
        #print('Считаем длину L_Path и расход G_Path')
        Shell_Type = self.CD.ShellType
        U = False
        L_Pipes = self.CD.TubeLenght
        s_Tubesheet = 0.054
        G = self.PD.HeatBalanceData.BalanceData[3][self.CD.shell]['IN']['FLOW']['Mass Flow']

        self.ShellL_G = GetShellL_G(Shell_Type, U, L_Pipes, s_Tubesheet, G)
        
        self.log.append(['CalcShellL_G', ['ShellL_G', self.ShellL_G]])
        
    def CalcShellAlpha(self):
        if self.VelocityFlag == True:
            # Массив с массивами интерполированных свойств для межтрубного
            self.ShellAlphasArray = GetShellAlpha(self.CD.TDiam, self.PatternCharacter, self.ShellInterpArr, self.CD.shell, self.ShellVelocities[1][0]) # Альфа межтрубного БЕЗ учета перетоков
            self.ShellAlphasCorrectedArray = copy.deepcopy(self.ShellAlphasArray)
            for i in self.ShellAlphasCorrectedArray:
                for k in range(len(i)):
                    i[k][3] = i[k][3]*self.ShellPeretoki[k]  
            print('ShellAlphasCorrectedArray', self.ShellAlphasCorrectedArray)
            
            alpha_mix_sum = 0
            alpha_liq_sum = 0
            alpha_vap_sum = 0
            for l in range(len(self.ShellAlphasCorrectedArray[0])):
                alpha_mix_sum = alpha_mix_sum + self.ShellAlphasCorrectedArray[0][l][3]
                alpha_liq_sum = alpha_liq_sum + self.ShellAlphasCorrectedArray[1][l][3]
                alpha_vap_sum = alpha_vap_sum + self.ShellAlphasCorrectedArray[2][l][3]
            self.ShellAlphaMixAve = alpha_mix_sum / len(self.ShellAlphasCorrectedArray[0])
            self.ShellAlphaLiqAve = alpha_liq_sum / len(self.ShellAlphasCorrectedArray[0])
            self.ShellAlphaVapAve = alpha_vap_sum / len(self.ShellAlphasCorrectedArray[0])
            
            self.log.append(['CalcShellAlpha', ['ShellAlphasArray', self.ShellAlphasArray], ['ShellAlphasCorrectedArray', self.ShellAlphasCorrectedArray], ['ShellAlphaMixAve', self.ShellAlphaMixAve], ['ShellAlphaLiqAve', self.ShellAlphaLiqAve], ['ShellAlphaVapAve', self.ShellAlphaVapAve]])
        
    def CalcTubeAlpha(self):
        if self.VelocityFlag == True:
            # Массив с массивами интерполированных свойств для трубного
            self.TubeAlphasArray = GetTubeAlpha(self.CD.TDiam_in, self.CD.TubeLenght, self.TubeInterpArr, self.Tubes_By_Pass, self.TubeVelocityAveArray)
            print('TubeAlphasArray', self.TubeAlphasArray)
            alpha_mix_sum = 0
            alpha_liq_sum = 0
            alpha_vap_sum = 0
            for i in range(len(self.TubeAlphasArray[0])):
                alpha_mix_sum = alpha_mix_sum + self.TubeAlphasArray[0][i][3]
                alpha_liq_sum = alpha_liq_sum + self.TubeAlphasArray[1][i][3]
                alpha_vap_sum = alpha_vap_sum + self.TubeAlphasArray[2][i][3]
            self.TubeAlphaMixAve = alpha_mix_sum / len(self.TubeAlphasArray[0])
            self.TubeAlphaLiqAve = alpha_liq_sum / len(self.TubeAlphasArray[0])
            self.TubeAlphaVapAve = alpha_vap_sum / len(self.TubeAlphasArray[0])
            
            self.log.append(['CalcTubeAlpha', ['TubeAlphasArray', self.TubeAlphasArray], ['TubeAlphaMixAve', self.TubeAlphaMixAve], ['TubeAlphaLiqAve', self.TubeAlphaLiqAve], ['TubeAlphaVapAve', self.TubeAlphaVapAve]])
            
    def CalcTemperatureOfPipeWall(self):
        if self.VelocityFlag == True:
            self.TempPipeWall = GetTemperaturOfPipeWall(self.CD.TDiam, self.CD.TDiam_in, self.CD.TM_TC, self.TubeAlphaMixAve, self.ShellAlphaMixAve, self.CD.tube, self.CD.TFR, self.CD.SFR, self.PD.HeatBalanceData.BalanceData)
            print('TempPipeWall', self.TempPipeWall)
            
            self.log.append(['CalcTemperatureOfPipeWall', ['TempPipeWall', self.TempPipeWall]])
            
    def CalcMaxTempDeltaShellAndTube(self):
        if self.VelocityFlag == True:
            self.MaxTempDeltaShellAndTube = GetMaxTempDeltaShellAndTube(self.TempPipeWall[0], self.TempPipeWall[1], self.PD.HeatBalanceData.BalanceData, self.CD.tube)
            #print('MaxTempDeltaShellAndTube', self.MaxTempDeltaShellAndTube)
            if self.MaxTempDeltaShellAndTube > 40:
                if self.CD.UType == False and self.CD.FloatingHead == False:
                    self.CD.LensCompensator = True
                    self.CD.Design_user_input['SHELL']['compensator'] = True
            #print('LensCompensator', self.CD.LensCompensator)
            
            self.log.append(['CalcMaxTempDeltaShellAndTube', ['MaxTempDeltaShellAndTube', self.MaxTempDeltaShellAndTube], ['LensCompensator', self.CD.LensCompensator]])
            
    def CalcK(self):
        if self.VelocityFlag == True:
            k = 2
            if self.CD.UType == True:
                k = 1
            self.F = 3.1415*self.CD.TDiam*(self.CD.TubeLenght - k * self.res_baffle_pitch[2]/1000)*sum(self.Tubes_By_Pass)
            #print('F', self.F)
            self.CalculatedKArray = GetCaclculatedK(self.CD.TDiam, self.CD.TDiam_in, self.CD.TM_TC, self.TubeAlphaMixAve, self.ShellAlphaMixAve, self.CD.TFR, self.CD.SFR, self.PD.HeatBalanceData.BalanceData, self.F, self.CD.MLTD) #Посчитать актуальную площадь
            print('CALCULATED_K_ARRAY ([K_clean, K_dirty, K_required, F_fact, F_clean, F_dirty, surface_margin_clean, surface_margin_dirty])', self.CalculatedKArray)
            
            self.log.append(['CalcK', ['F', self.F], ['CalculatedKArray', self.CalculatedKArray]])
            
    def GetXLS(self, template, filename):
        wb = load_workbook(filename = template)
        sheet_ranges = wb['Отчет']
        
        sheet_ranges['E11'] = self.CD.Design_input_dict['GENERAL']['customer'] = 'Газпром'
        sheet_ranges['I13'] = self.CD.Design_input_dict['GENERAL']['name_apparatus'] = 'Холодильник'
        sheet_ranges['X13'] = self.CD.Design_input_dict['GENERAL']['position'] = 'Т-100'
        sheet_ranges['H14'] = self.CD.Design_input_dict['GENERAL']['appointment_apparatus'] = 'Охлаждение воды'
        sheet_ranges['E12'] = 'Иванов И. И.'
        sheet_ranges['Y11'] = 'г. Самара'
        sheet_ranges['W12'] = '8-912-600-30-40'
        sheet_ranges['Y14'] = self.CD.CaseNum
        
        if self.CD.CaseNum == 1:
            sheet_ranges['Z15'] = ''
            sheet_ranges['AF15'] = ''
        else:
            sheet_ranges['Z15'] = 'последовательно'
            sheet_ranges['AF15'] = 'последовательно'

        sheet_ranges['U16'] = self.CD.CaseNum
        sheet_ranges['W16'] = 1

        sheet_ranges['B9'] = self.CD.Design_input_dict['GENERAL']['appointment_apparatus'] + ' - LOTUS - '
        sheet_ranges['U9'] = self.CD.Design_input_dict['GENERAL']['TEMA'] + ' - '
        sheet_ranges['P15'] = self.CD.Design_input_dict['GENERAL']['TEMA']        
        sheet_ranges['X9'] = self.CD.Design_input_dict['GENERAL']['media_typ'] + ' - '
        sheet_ranges['Z9'] = self.CD.Design_input_dict['GENERAL']['heat_load']/1000
        sheet_ranges['L38'] = self.CD.Design_input_dict['GENERAL']['heat_load']
        sheet_ranges['AC9'] = ' - '
        sheet_ranges['AD9'] = self.CD.Design_input_dict['GENERAL']['order']
        sheet_ranges['AG9'] = ' / '
        sheet_ranges['AH9'] = self.CD.Design_input_dict['GENERAL']['revision']
        sheet_ranges['B10'] = 'ТУ 3612-001-60793544-2009'
        
        sheet_ranges['K16'] = self.CD.Design_input_dict['GENERAL']['area'] # Общая площадь теплообмена установки
        sheet_ranges['AG16'] = self.CD.Design_input_dict['GENERAL']['area'] / self.CD.CaseNum # Площадь теплообмена каждого корпуса в установке
        sheet_ranges['E15'] = self.CD.Design_input_dict['GENERAL']['D']
        
        if sheet_ranges['E15'] != self.CD.SDiam_in:
            sheet_ranges['R46'] = self.CD.Design_input_dict['GENERAL']['D']
            sheet_ranges['N46'] = self.CD.SDiam_in
        else:
            sheet_ranges['N46'] = ''
            sheet_ranges['R46'] = self.CD.Design_input_dict['GENERAL']['D']
        
        sheet_ranges['J45'] = 'обварка с последующей развальцовкой'
        sheet_ranges['N47'] = self.MaxTempDeltaShellAndTube
        sheet_ranges['N48'] = min(self.TempPipeWall)
        
        sheet_ranges['H15'] = self.CD.Design_input_dict['SHELL']['L_pipe']
        sheet_ranges['AC51'] = sheet_ranges['AH51'] = self.CD.Design_input_dict['GENERAL']['T_minimum']
        sheet_ranges['M54'] = ''
        sheet_ranges['M55'] = self.CD.Design_input_dict['GENERAL']['climatic']
        sheet_ranges['Q41'] = self.CD.Design_input_dict['GENERAL']['performance_device']
        
        if self.CD.Design_input_dict['TUBE']['DN_IN_diffuser'] != '':
            sheet_ranges['AE43'] = self.CD.Design_input_dict['TUBE']['DN_IN'] + 'x' + self.CD.Design_input_dict['TUBE']['DN_IN_diffuser']
        else:
            sheet_ranges['AE43'] = self.CD.Design_input_dict['TUBE']['DN_IN']
        
        if self.CD.Design_input_dict['TUBE']['DN_OUT_diffuser'] != '':
            sheet_ranges['AE44'] = self.CD.Design_input_dict['TUBE']['DN_OUT'] + 'x' + self.CD.Design_input_dict['TUBE']['DN_OUT_diffuser']
        else:
            sheet_ranges['AE44'] = self.CD.Design_input_dict['TUBE']['DN_OUT']
            
        sheet_ranges['AE45'] = self.CD.Design_input_dict['TUBE']['DN_connecting']
        sheet_ranges['AE46'] = self.CD.Design_input_dict['TUBE']['DN_deflating']
        sheet_ranges['AE47'] = self.CD.Design_input_dict['TUBE']['DN_drainage']
        sheet_ranges['AE49'] = self.CD.Design_input_dict['TUBE']['P_calculation']
        sheet_ranges['AE50'] = self.CD.Design_input_dict['TUBE']['P_vacuum']
        sheet_ranges['AH43'] = sheet_ranges['AH44'] = self.CD.Design_input_dict['TUBE']['PN']
        sheet_ranges['Z33'] = self.CD.Design_input_dict['TUBE']['P_IN']
        sheet_ranges['Z34'] = 'min-max: ' + str(round(min(self.TubeVelocityAveArray), 1)) + ' - ' + str(round(max(self.TubeVelocityAveArray), 1))
        sheet_ranges['Z27'] = self.CD.Design_input_dict['TUBE']['T_IN']
        sheet_ranges['AE27'] = self.CD.Design_input_dict['TUBE']['T_OUT']
        sheet_ranges['Z19'] = self.CD.Design_input_dict['TUBE']['name_medium']
        
        sheet_ranges['Z20'] = self.CD.Design_input_dict['TUBE']['mass_consumption']
        if self.CD.tube == 'COLD':
            ################ в трубном на входе ##########################
            if self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Vapour'] == 0:
                sheet_ranges['Z21'] = ''
            else:
                sheet_ranges['Z21'] = self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Vapour']*3600
                
            if (self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Light Liquid']) == 0:
                sheet_ranges['Z22'] = ''
            else:
                sheet_ranges['Z22'] = (self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Light Liquid'])*3600
            
            #sheet_ranges['Z25'] = round((self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Inerts'], 0)
            sheet_ranges['Z25'] = ''
            
            Tube_mix_volflow_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['MIX'][1]*3600 # м3/час
            sheet_ranges['Z26'] = Tube_mix_volflow_in
            
            Tube_vapour_density_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Vapour'][2] # кг/м3
            sheet_ranges['Z28'] = Tube_vapour_density_in
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Vapour'][5] != None:
                Tube_vapour_viscosity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Vapour'][5] * 1000 # мПа·с
                sheet_ranges['Z29'] = Tube_vapour_viscosity_in
            else:
                sheet_ranges['Z29'] = None
                
            Tube_vapour_capasity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Vapour'][3] # Дж/(кг·°С)
            sheet_ranges['Z30'] = Tube_vapour_capasity_in
            Tube_vapour_thermal_cond_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Vapour'][4] # Вт/(м·°С)
            sheet_ranges['Z31'] = Tube_vapour_thermal_cond_in
            
            Tube_liquid_mix_density_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Mix_liquid'][2] # кг/м3
            sheet_ranges['AC28'] = Tube_liquid_mix_density_in
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Mix_liquid'][5] != None:
                Tube_liquid_mix_viscosity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Mix_liquid'][5] * 1000 # мПа·с
                sheet_ranges['AC29'] = Tube_liquid_mix_viscosity_in
            else:
                sheet_ranges['AC29'] = None
                
            Tube_liquid_mix_capasity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Mix_liquid'][3] # Дж/(кг·°С)
            sheet_ranges['AC30'] = Tube_liquid_mix_capasity_in
            Tube_liquid_mix_thermal_cond_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Mix_liquid'][4] # Вт/(м·°С)
            sheet_ranges['AC31'] = Tube_liquid_mix_thermal_cond_in

            ################ в трубном на выходе ##########################
            
            if self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Vapour'] == 0:
                sheet_ranges['AE21'] = ''
            else:
                sheet_ranges['AE21'] = self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Vapour']*3600
                
            if (self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Light Liquid']) == 0:
                sheet_ranges['AE22'] = ''
            else:
                sheet_ranges['AE22'] = (self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Light Liquid'])*3600
            
            #sheet_ranges['AF25'] = round((self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Inerts'], 0)
            sheet_ranges['AF25'] = ''
            
            Tube_mix_volflow_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['MIX'][1]*3600 # м3/час
            sheet_ranges['AE26'] = Tube_mix_volflow_out
            
            Tube_vapour_density_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Vapour'][2] # кг/м3
            sheet_ranges['AE28'] = Tube_vapour_density_out
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Vapour'][5] != None:
                Tube_vapour_viscosity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Vapour'][5] * 1000 # мПа·с
                sheet_ranges['AE29'] = Tube_vapour_viscosity_out
            else:
                sheet_ranges['AE29'] = None
                
            Tube_vapour_capasity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Vapour'][3] # Дж/(кг·°С)
            sheet_ranges['AE30'] = Tube_vapour_capasity_out
            Tube_vapour_thermal_cond_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Vapour'][4] # Вт/(м·°С)
            sheet_ranges['AE31'] = Tube_vapour_thermal_cond_out
            
            Tube_liquid_mix_density_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Mix_liquid'][2] # кг/м3
            sheet_ranges['AH28'] = Tube_liquid_mix_density_out
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Mix_liquid'][5] != None:
                Tube_liquid_mix_viscosity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Mix_liquid'][5] * 1000 # мПа·с
                sheet_ranges['AH29'] = Tube_liquid_mix_viscosity_out
            else:
                sheet_ranges['AH29'] = None
                
            Tube_liquid_mix_capasity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Mix_liquid'][3] # Дж/(кг·°С)
            sheet_ranges['AH30'] = Tube_liquid_mix_capasity_out
            Tube_liquid_mix_thermal_cond_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Mix_liquid'][4] # Вт/(м·°С)
            sheet_ranges['AH31'] = Tube_liquid_mix_thermal_cond_out
            
            ################ в межтрубном на входе ##########################
            
            if self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Vapour'] == 0:
                sheet_ranges['P21'] = ''
            else:
                sheet_ranges['P21'] = self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Vapour']*3600
                
            if (self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Light Liquid']) == 0:
                sheet_ranges['P22'] = ''
            else:
                sheet_ranges['P22'] = (self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Light Liquid'])*3600
            
            #sheet_ranges['P25'] = round((self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Inerts'], 0)
            sheet_ranges['P25'] = ''
            
            Shell_mix_volflow_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['MIX'][1]*3600 # м3/час
            sheet_ranges['P26'] = Shell_mix_volflow_in
            
            Shell_vapour_density_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Vapour'][2] # кг/м3
            sheet_ranges['P28'] = Shell_vapour_density_in
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Vapour'][5] != None:
                Shell_vapour_viscosity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Vapour'][5] * 1000 # мПа·с
                sheet_ranges['P29'] = Shell_vapour_viscosity_in
            else:
                sheet_ranges['P29'] = None
                
            Shell_vapour_capasity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Vapour'][3] # Дж/(кг·°С)
            sheet_ranges['P30'] = Shell_vapour_capasity_in
            Shell_vapour_thermal_cond_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Vapour'][4] # Вт/(м·°С)
            sheet_ranges['P31'] = Shell_vapour_thermal_cond_in
            
            Shell_liquid_mix_density_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Mix_liquid'][2] # кг/м3
            sheet_ranges['S28'] = Shell_liquid_mix_density_in
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Mix_liquid'][5] != None:
                Shell_liquid_mix_viscosity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Mix_liquid'][5] * 1000 # мПа·с
                sheet_ranges['S29'] = Shell_liquid_mix_viscosity_in
            else:
                sheet_ranges['S29'] = None
                
            Shell_liquid_mix_capasity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Mix_liquid'][3] # Дж/(кг·°С)
            sheet_ranges['S30'] = Shell_liquid_mix_capasity_in
            Shell_liquid_mix_thermal_cond_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Mix_liquid'][4] # Вт/(м·°С)
            sheet_ranges['S31'] = Shell_liquid_mix_thermal_cond_in
            
            ################ в межтрубном на выходе ##########################
            
            if self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Vapour'] == 0:
                sheet_ranges['U21'] = ''
            else:
                sheet_ranges['U21'] = self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Vapour']*3600
                
            if (self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Light Liquid']) == 0:
                sheet_ranges['U22'] = ''
            else:
                sheet_ranges['U22'] = (self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Light Liquid'])*3600
            
            #sheet_ranges['V25'] = round((self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Inerts'], 0)
            sheet_ranges['V25'] = ''
            
            Shell_mix_volflow_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['MIX'][1]*3600 # м3/час
            sheet_ranges['U26'] = Shell_mix_volflow_out
            
            Shell_vapour_density_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Vapour'][2] # кг/м3
            sheet_ranges['U28'] = Shell_vapour_density_out
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Vapour'][5] != None:
                Shell_vapour_viscosity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Vapour'][5] * 1000 # мПа·с
                sheet_ranges['U29'] = Shell_vapour_viscosity_out
            else:
                sheet_ranges['U29'] = None
                
            Shell_vapour_capasity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Vapour'][3] # Дж/(кг·°С)
            sheet_ranges['U30'] = Shell_vapour_capasity_out
            Shell_vapour_thermal_cond_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Vapour'][4] # Вт/(м·°С)
            sheet_ranges['U31'] = Shell_vapour_thermal_cond_out
            
            Shell_liquid_mix_density_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Mix_liquid'][2] # кг/м3
            sheet_ranges['X28'] = Shell_liquid_mix_density_out
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Mix_liquid'][5] != None:
                Shell_liquid_mix_viscosity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Mix_liquid'][5] * 1000 # мПа·с
                sheet_ranges['X29'] = Shell_liquid_mix_viscosity_out
            else:
                sheet_ranges['X29'] = None
                
            Shell_liquid_mix_capasity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Mix_liquid'][3] # Дж/(кг·°С)
            sheet_ranges['X30'] = Shell_liquid_mix_capasity_out
            Shell_liquid_mix_thermal_cond_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Mix_liquid'][4] # Вт/(м·°С)
            sheet_ranges['X31'] = Shell_liquid_mix_thermal_cond_out
                
        else:
            ################ в трубном на входе ##########################
            
            if self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Vapour'] == 0:
                sheet_ranges['Z21'] = ''
            else:
                sheet_ranges['Z21'] = self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Vapour']*3600
                
            if (self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Light Liquid']) == 0:
                sheet_ranges['Z22'] = ''
            else:
                sheet_ranges['Z22'] = (self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Light Liquid'])*3600
            
            #sheet_ranges['Z25'] = round((self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Inerts'], 0)
            sheet_ranges['Z25'] = ''
            
            Tube_mix_volflow_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['MIX'][1]*3600 # м3/час
            sheet_ranges['Z26'] = Tube_mix_volflow_in
            
            Tube_vapour_density_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Vapour'][2] # кг/м3
            sheet_ranges['Z28'] = Tube_vapour_density_in
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Vapour'][5] != None:
                Tube_vapour_viscosity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Vapour'][5] * 1000 # мПа·с
                sheet_ranges['Z29'] = Tube_vapour_viscosity_in
            else:
                sheet_ranges['Z29'] = None
                
            Tube_vapour_capasity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Vapour'][3] # Дж/(кг·°С)
            sheet_ranges['Z30'] = Tube_vapour_capasity_in
            Tube_vapour_thermal_cond_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Vapour'][4] # Вт/(м·°С)
            sheet_ranges['Z31'] = Tube_vapour_thermal_cond_in
            
            Tube_liquid_mix_density_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Mix_liquid'][2] # кг/м3
            sheet_ranges['AC28'] = Tube_liquid_mix_density_in
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Mix_liquid'][5] != None:
                Tube_liquid_mix_viscosity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Mix_liquid'][5] * 1000 # мПа·с
                sheet_ranges['AC29'] = Tube_liquid_mix_viscosity_in
            else:
                sheet_ranges['AC29'] = None
                
            Tube_liquid_mix_capasity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Mix_liquid'][3] # Дж/(кг·°С)
            sheet_ranges['AC30'] = Tube_liquid_mix_capasity_in
            Tube_liquid_mix_thermal_cond_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'IN')['Mix_liquid'][4] # Вт/(м·°С)
            sheet_ranges['AC31'] = Tube_liquid_mix_thermal_cond_in
            
            ################ в трубном на выходе ##########################
            
            if self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Vapour'] == 0:
                sheet_ranges['AE21'] = ''
            else:
                sheet_ranges['AE21'] = self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Vapour']*3600
                
            if (self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Light Liquid']) == 0:
                sheet_ranges['AE22'] = ''
            else:
                sheet_ranges['AE22'] = (self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Light Liquid'])*3600
            
            #sheet_ranges['AF25'] = round((self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Inerts'], 0)
            sheet_ranges['AF25'] = ''
            
            Tube_mix_volflow_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['MIX'][1]*3600 # м3/час
            sheet_ranges['AE26'] = Tube_mix_volflow_out
            
            Tube_vapour_density_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Vapour'][2] # кг/м3
            sheet_ranges['AE28'] = Tube_vapour_density_out
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Vapour'][5] != None:
                Tube_vapour_viscosity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Vapour'][5] * 1000 # мПа·с
                sheet_ranges['AE29'] = Tube_vapour_viscosity_out
            else:
                sheet_ranges['AE29'] = None
                
            Tube_vapour_capasity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Vapour'][3] # Дж/(кг·°С)
            sheet_ranges['AE30'] = Tube_vapour_capasity_out
            Tube_vapour_thermal_cond_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Vapour'][4] # Вт/(м·°С)
            sheet_ranges['AE31'] = Tube_vapour_thermal_cond_out
            
            Tube_liquid_mix_density_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Mix_liquid'][2] # кг/м3
            sheet_ranges['AH28'] = Tube_liquid_mix_density_out
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Mix_liquid'][5] != None:
                Tube_liquid_mix_viscosity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Mix_liquid'][5] * 1000 # мПа·с
                sheet_ranges['AH29'] = Tube_liquid_mix_viscosity_out
            else:
                sheet_ranges['AH29'] = None
                
            Tube_liquid_mix_capasity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Mix_liquid'][3] # Дж/(кг·°С)
            sheet_ranges['AH30'] = Tube_liquid_mix_capasity_out
            Tube_liquid_mix_thermal_cond_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'HOT', 'OUT')['Mix_liquid'][4] # Вт/(м·°С)
            sheet_ranges['AH31'] = Tube_liquid_mix_thermal_cond_out
            
            ################ в межтрубном на входе ##########################
            
            if self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Vapour'] == 0:
                sheet_ranges['P21'] = ''
            else:
                sheet_ranges['P21'] = self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Vapour']*3600
                
            if (self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Light Liquid']) == 0:
                sheet_ranges['P22'] = ''
            else:
                sheet_ranges['P22'] = (self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Light Liquid'])*3600
            
            #sheet_ranges['P25'] = round((self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Inerts'], 0)
            sheet_ranges['P25'] = ''
            
            Shell_mix_volflow_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['MIX'][1]*3600 # м3/час
            sheet_ranges['P26'] = Shell_mix_volflow_in
            
            Shell_vapour_density_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Vapour'][2] # кг/м3
            sheet_ranges['P28'] = Shell_vapour_density_in
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Vapour'][5] != None:
                Shell_vapour_viscosity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Vapour'][5] * 1000 # мПа·с
                sheet_ranges['P29'] = Shell_vapour_viscosity_in
            else:
                sheet_ranges['P29'] = None
                
            Shell_vapour_capasity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Vapour'][3] # Дж/(кг·°С)
            sheet_ranges['P30'] = Shell_vapour_capasity_in
            Shell_vapour_thermal_cond_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Vapour'][4] # Вт/(м·°С)
            sheet_ranges['P31'] = Shell_vapour_thermal_cond_in
            
            Shell_liquid_mix_density_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Mix_liquid'][2] # кг/м3
            sheet_ranges['S28'] = Shell_liquid_mix_density_in
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Mix_liquid'][5] != None:
                Shell_liquid_mix_viscosity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Mix_liquid'][5] * 1000 # мПа·с
                sheet_ranges['S29'] = Shell_liquid_mix_viscosity_in
            else:
                sheet_ranges['S29'] = None
                
            Shell_liquid_mix_capasity_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Mix_liquid'][3] # Дж/(кг·°С)
            sheet_ranges['S30'] = Shell_liquid_mix_capasity_in
            Shell_liquid_mix_thermal_cond_in = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'IN')['Mix_liquid'][4] # Вт/(м·°С)
            sheet_ranges['S31'] = Shell_liquid_mix_thermal_cond_in
            
            ################ в межтрубном на выходе ##########################
            
            if self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Vapour'] == 0:
                sheet_ranges['P21'] = ''
            else:
                sheet_ranges['P21'] = self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Vapour']*3600
                
            if (self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Light Liquid']) == 0:
                sheet_ranges['P22'] = ''
            else:
                sheet_ranges['P22'] = (self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Heavy Liquid'] + self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Light Liquid'])*3600
            
            #sheet_ranges['V25'] = round((self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Inerts'], 0)
            sheet_ranges['V25'] = ''
            
            Shell_mix_volflow_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['MIX'][1]*3600 # м3/час
            sheet_ranges['U26'] = Shell_mix_volflow_out
            
            Shell_vapour_density_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Vapour'][2] # кг/м3
            sheet_ranges['U28'] = Shell_vapour_density_out
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Vapour'][5] != None:
                Shell_vapour_viscosity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Vapour'][5] * 1000 # мПа·с
                sheet_ranges['U29'] = Shell_vapour_viscosity_out
            else:
                sheet_ranges['U29'] = None
                
            Shell_vapour_capasity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Vapour'][3] # Дж/(кг·°С)
            sheet_ranges['U30'] = Shell_vapour_capasity_out
            Shell_vapour_thermal_cond_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Vapour'][4] # Вт/(м·°С)
            sheet_ranges['U31'] = Shell_vapour_thermal_cond_out
            
            Shell_liquid_mix_density_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Mix_liquid'][2] # кг/м3
            sheet_ranges['X28'] = Shell_liquid_mix_density_out
            
            if PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Mix_liquid'][5] != None:
                Shell_liquid_mix_viscosity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Mix_liquid'][5] * 1000 # мПа·с
                sheet_ranges['X29'] = Shell_liquid_mix_viscosity_out
            else:
                sheet_ranges['X29'] = None
                
            Shell_liquid_mix_capasity_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Mix_liquid'][3] # Дж/(кг·°С)
            sheet_ranges['X30'] = Shell_liquid_mix_capasity_out
            Shell_liquid_mix_thermal_cond_out = PropsOfMixtureToHEC(self.PD.HeatBalanceData.BalanceData, 'COLD', 'OUT')['Mix_liquid'][4] # Вт/(м·°С)
            sheet_ranges['X31'] = Shell_liquid_mix_thermal_cond_out
            
        sheet_ranges['AF35'] = self.CD.Design_input_dict['TUBE']['hydraulic_friction']
        sheet_ranges['Z35'] = self.PD.UserAnswers['max_pressure_drop'][self.CD.tube]/1000 # кПа
        sheet_ranges['Z36'] = self.CD.TFR
        sheet_ranges['Z37'] = self.TubeAlphaMixAve
        sheet_ranges['AE51'] = self.CD.Design_input_dict['TUBE']['T_calculation']
        sheet_ranges['AE52'] = self.CD.Design_input_dict['TUBE']['motion']
        sheet_ranges['AE53'] = self.CD.Design_input_dict['TUBE']['corrosion']
        sheet_ranges['AE54'] = self.CD.Design_input_dict['TUBE']['group_apparatus']
        sheet_ranges['AE55'] = '-'
        
        if self.CD.Design_input_dict['SHELL']['DN_IN_diffuser'] != '':
            sheet_ranges['Z43'] = self.CD.Design_input_dict['SHELL']['DN_IN'] + 'x' + self.CD.Design_input_dict['SHELL']['DN_IN_diffuser']
        else:
            sheet_ranges['Z43'] = self.CD.Design_input_dict['SHELL']['DN_IN']
        
        if self.CD.Design_input_dict['SHELL']['DN_OUT_diffuser'] != '':
            sheet_ranges['Z44'] = self.CD.Design_input_dict['SHELL']['DN_OUT'] + 'x' + self.CD.Design_input_dict['SHELL']['DN_OUT_diffuser']
        else:
            sheet_ranges['Z44'] = self.CD.Design_input_dict['SHELL']['DN_OUT']
            
        sheet_ranges['Z45'] = self.CD.Design_input_dict['SHELL']['DN_connecting']
        sheet_ranges['Z46'] = self.CD.Design_input_dict['SHELL']['DN_deflating']
        sheet_ranges['Z47'] = self.CD.Design_input_dict['SHELL']['DN_drainage']
        sheet_ranges['Z49'] = self.CD.Design_input_dict['SHELL']['P_calculation']
        sheet_ranges['Z50'] = self.CD.Design_input_dict['SHELL']['P_vacuum']
        sheet_ranges['AC43'] = sheet_ranges['AC44'] = self.CD.Design_input_dict['SHELL']['PN']
        sheet_ranges['P33'] = self.CD.Design_input_dict['SHELL']['P_IN']
        sheet_ranges['P34'] = 'min-max: ' + str(round(min(self.ShellVelocities[1][0]), 1)) + ' - ' + str(round(max(self.ShellVelocities[1][0]), 1))
        sheet_ranges['P27'] = self.CD.Design_input_dict['SHELL']['T_IN']
        sheet_ranges['U27'] = self.CD.Design_input_dict['SHELL']['T_OUT']
        sheet_ranges['P19'] = self.CD.Design_input_dict['SHELL']['name_medium']
        sheet_ranges['P20'] = self.CD.Design_input_dict['SHELL']['mass_consumption']
        sheet_ranges['V35'] = self.CD.Design_input_dict['SHELL']['hydraulic_friction']
        sheet_ranges['P35'] = self.PD.UserAnswers['max_pressure_drop'][self.CD.shell]/1000 # кПа
        sheet_ranges['P36'] = self.CD.SFR
        sheet_ranges['P37'] = self.ShellAlphaMixAve
        
        sheet_ranges['AD38'] = self.CD.MLTD
        sheet_ranges['AG39'] = self.CalculatedKArray[0]
        sheet_ranges['AA39'] = self.CalculatedKArray[1]
        sheet_ranges['S39'] = self.CalculatedKArray[2]
        
        sheet_ranges['N42'] = self.TubePattern1.step
        
        #sheet_ranges['D49'] = 1
        #sheet_ranges['D50'] = 2
        #sheet_ranges['D51'] = 3
        #sheet_ranges['D52'] = 4
        
        if self.TubePattern1.PatternCharacter == 'Треугольники':
            sheet_ranges['Q43'] = 'Треугольники'
        elif self.TubePattern1.PatternCharacter == 'Повернутые треугольники':
            sheet_ranges['Q43'] = 'Повернутые треугольники'
        elif self.TubePattern1.PatternCharacter == 'Квадраты':
            sheet_ranges['Q43'] = 'Квадраты'
        elif self.TubePattern1.PatternCharacter == 'Коридорные квадраты':
            sheet_ranges['Q43'] = 'Коридорные квадраты'
        
        sheet_ranges['Z51'] = self.CD.Design_input_dict['SHELL']['T_calculation']
        sheet_ranges['Z52'] = self.CD.Design_input_dict['SHELL']['motion']
        sheet_ranges['Z53'] = self.CD.Design_input_dict['SHELL']['corrosion']
        sheet_ranges['Z54'] = self.CD.Design_input_dict['SHELL']['group_apparatus']
        sheet_ranges['Z55'] = '-'
        
        if self.CD.UType == False: # !!!!!!!!!!!!!!!!!!!!!!!!
            sheet_ranges['I41'] = self.CD.Design_input_dict['SHELL']['N_pipe']
        else:
            sheet_ranges['I41'] = self.CD.Design_input_dict['SHELL']['N_pipe']/2
            
        sheet_ranges['I42'] = self.CD.Design_input_dict['SHELL']['D_pipe']
        sheet_ranges['I43'] = self.CD.Design_input_dict['SHELL']['S_pipe']
        
        sheet_ranges['I44'] = self.CD.Design_input_dict['SHELL']['L_pipe'] / 1000
        
        sheet_ranges['G59'] = self.CD.Design_input_dict['REFERENCE']['TUBE']['steel'][0] # !!!!!!!!!!!!!!!!!!!!!!!!
        sheet_ranges['E57'] = self.CD.Design_input_dict['REFERENCE']['SHELL']['steel'][0]
        sheet_ranges['E58'] = self.CD.Design_input_dict['REFERENCE']['SHELL']['pipe'][0]
        
        if self.CD.UType == False: # !!!!!!!!!!!!!!!!!!!!!!!!
            sheet_ranges['AB57'] = sheet_ranges['AB58'] = self.CD.Design_input_dict['REFERENCE']['SHELL']['tube_sheet'][0]        
        else:
            sheet_ranges['AB57'] = self.CD.Design_input_dict['REFERENCE']['SHELL']['tube_sheet'][0]
            sheet_ranges['AB58'] = ''
        
        sheet_ranges['AA59'] = self.CD.Design_input_dict['REFERENCE']['SHELL']['floating_head_cover'][0]
        sheet_ranges['X60'] = self.CD.Design_input_dict['REFERENCE']['SHELL']['partition'][0]
        sheet_ranges['X61'] = self.CD.Design_input_dict['REFERENCE']['SHELL']['compensator'][0]

        

        
        wb.save(filename = filename)
        self.convert_xls_to_pdf_by_libreoffice(filename)

    def convert_xls_to_pdf_by_libreoffice(self, filename):
        subprocess.call(f'libreoffice --convert-to pdf {filename} --outdir /data/www/lotus/uems.lotus1.ru/UEMS/static/files/', shell=True)
        