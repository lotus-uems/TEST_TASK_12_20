from .heat_calculation import *

class STHE_Construction():
    
    def __init__(self, ProjectData, FilteredSolution):
        self.PD = ProjectData
        self.Solution = FilteredSolution
        self.ShellType = FilteredSolution['ShellType']
        self.TubePassNum = FilteredSolution['TubePassNum']
        self.ShellPassNum = FilteredSolution['ShellPassNum']
        self.CaseNum = FilteredSolution['CaseNum']
        self.MLTD = FilteredSolution['MLTD']
        self.shell = FilteredSolution['shell']
        self.tube = FilteredSolution['tube']
        self.TFR = FilteredSolution['TFR']
        self.SFR = FilteredSolution['SFR']
        self.TDiam = FilteredSolution['TDiam']
        self.TDiam_in = FilteredSolution['TDiam_in']
        self.TM = FilteredSolution['TM']
        self.TM_TC = FilteredSolution['TM_TC']
        self.TubeNum = FilteredSolution['TubeNum']
        self.TubeLenght = FilteredSolution['TubeLenght']
        self.SDiam_in = FilteredSolution['SDiam_in']
        self.LnD_Ratio = FilteredSolution['LnD_Ratio']
        self.tube_delta_p = FilteredSolution['tube_delta_p']
        self.shell_delta_p = FilteredSolution['shell_delta_p']
        self.TA_DB = FilteredSolution['TA_DB']
        self.SA_DB = FilteredSolution['SA_DB']
        self.TA = FilteredSolution['TA']
        self.SA = FilteredSolution['SA']
        self.k = FilteredSolution['k']
        self.F = FilteredSolution['F']
        
        self.UType = False
        self.FloatingHead = False
        self.Fluoroplastic_Seal = False
        self.LensCompensator = False
        
        self.Design_input_dict = {
            'GENERAL':
            {'customer': '', 'name_apparatus': '', 'position': '', 'appointment_apparatus': '', 'TEMA': '', 'media_typ': '', 'order': None, 'revision': '', 'area': None, 'D': None, 'heat_load': None,  'T_minimum': None, 'climatic': '', 'performance_device': ''},
            'TUBE':
            {'DN_IN': None, 'DN_IN_diffuser': '', 'DN_OUT': None, 'DN_OUT_diffuser': '', 'DN_connecting': '', 'DN_deflating': '', 'DN_drainage': '', 'P_calculation': None, 'P_vacuum': '', 'PN': None, 'P_IN': None, 'hydraulic_friction': None, 'T_IN': None, 'T_OUT': None, 'T_calculation': None, 'name_medium': '', 'mass_consumption': None, 'motion': None,  'corrosion': None, 'group_apparatus': None, 'steel': '' },
            'SHELL':
            {'DN_IN': None, 'DN_IN_diffuser': '', 'DN_OUT': None, 'DN_OUT_diffuser': '', 'DN_connecting': '', 'DN_deflating': '', 'DN_drainage': '', 'P_calculation': None, 'P_vacuum': '', 'PN': None, 'P_IN': None, 'hydraulic_friction': None, 'T_IN': None, 'T_OUT': None, 'T_calculation': None, 'name_medium': '', 'mass_consumption': None, 'motion': None,  'corrosion': None, 'group_apparatus': None, 'N_pipe': None, 'D_pipe': None, 'S_pipe': None, 'L_pipe': None, 'steel': '', 'mat_pipe':'', 'mat_tube_sheet': ''},
            'REFERENCE':
            {'TUBE': {'steel': ['']}, 'SHELL': {'steel': [''], 'pipe': [''], 'tube_sheet': [''], 'floating_head_cover': [''], 'partition': [''], 'compensator': ['']}
            }
}

        self.Design_user_input = {'GENERAL': 
                  {'execution_tab_1':1,   #Исполнение таблицы_1 эскиза (от КО)
                   'execution_scheme_load':1,    #Исполнение схемы нагрузок на эскизе (от КО)
                  },
              'TUBE':
                  {'corrosion_cracking': True,     #Коррозионное растрескивание (от КО)
                   'IN_input_seal_surface':'E-F',  #Исполнение уплотнительной поверхности фланцев входа (от КО)
                   'OUT_input_seal_surface':'E-F', #Исполнение уплотнительной поверхности фланцев выхода (от КО)
                   'IN_row': '1',                  #Ряд исполнение фланцев входа (от КО)
                   'OUT_row': '1',                 #Ряд исполнение фланцев выхода (от КО)
                   'IN_FlangeAngle':90,            #Угол поворота штуцера входа (от ТО)
                   'OUT_FlangeAngle':270,          #Угол поворота штуцера выхода (от ТО)
                   'IN_FlangePosition_z':0,        #Смещение штуцера входа (от ТО)
                   'OUT_FlangePosition_z':0,       #Смещение штуцера выхода (от ТО)
                   'instrumentation':True,         #Наличие бобышек на штуцерах под КИП (от КО)
                   'camera_partition': [True,                              #Перегородка камеры [от КО,
                                       'tube_partition',                                    #'tube_partition' -имя неизменное
                                       {'Dimensions':[None, 700, None]},                    #{'Dimensions':[None, Ширина (от ТО), None]},
                                       'Перегородка камеры',                                #имя неизменное
                                       'C'],                                                #тип перегородки (от ТО)
                   'cap_partition': [False,                                #Перегородка камеры [от КО,
                                     'tube_partition',                                         #'tube_partition' -имя неизменное
                                     {'Dimensions':[None, 500, None]},                         #{'Dimensions':[None, Ширина (от ТО), None]},
                                     'Перегородка крышки',                                     #имя неизменное
                                     'A'],                                                     #тип перегородки (от ТО)
                   'loads_fitting_in':[2000,2000,2000,1200,1600,2000],           #Нагрузки на штуцера от КО, но надо знать на стадии теплового расчета, т.к. они 
                   'loads_fitting_out':[2000,2000,2000,1200,1600,2000],          #могут повлиять на первый и последний проем
                   'transition_camera': False,                                   #Камера в виде конической обечайки, если один ход по трубному от КО
                   'transition_cap': False,                                      #Крышка в виде конической обечайки, если один ход по трубному от КО
                   'shell_cap': True,                                            #Обечайка в крышка от КО
                   'flow_movement': False,                                       #Поменять направление движение среды (True - прямое(слева направо), False - обратное)
                   'environmental_hazard_class': 1,                              #Класс опасности среды, (от КО)
                   'flammability':True,                                          #Воспломеняемость среды, (от КО)
                   'danger_of_explosion': True,                                  #Взрывоопасность среды, (от КО)
                  },
              'SHELL':
                  {'corrosion_cracking': True,      #Коррозионное растрескивание (от КО)
                   'IN_input_seal_surface':'E-F',   #Исполнение уплотнительной поверхности фланцев входа (от КО)
                   'OUT_input_seal_surface':'E-F',  #Исполнение уплотнительной поверхности фланцев выхода (от КО)
                   'IN_row': '1',                   #Ряд исполнение фланцев входа (от КО)
                   'OUT_row': '1',                  #Ряд исполнение фланцев выхода (от КО)
                   'IN_FlangeAngle':90,             #Угол поворота штуцера входа (от ТО)
                   'OUT_FlangeAngle':270,           #Угол поворота штуцера выхода (от ТО)
                   'IN_FlangePosition_z':0,         #Смещение штуцера входа (от ТО)
                   'OUT_FlangePosition_z':0,        #Смещение штуцера выхода (от ТО)
                   'instrumentation': True,         #Наличие бобышек на штуцерах под КИП (от КО)
                   'longitudinal_partition':[True,'rectangular', {'Dimensions':[6900, 697, 1]}, 'Продольная перегородка'], #[от ТО, неизменно, {'Dimensions':[Длина от ТО, Ширина от ТО, Кол-во от ТО]},неизменно ]
                   'anti_bypass_lane': [True,'rectangular', {'Dimensions':[6900, 25, 8]},'Противобайпасная полоса'],       #[от ТО, неизменно, {'Dimensions':[Длина от ТО, Ширина от ТО, Кол-во от ТО]},неизменно]
                   'cross_partition': [True,                                                                            #Перегородки поперечные [неизменно,
                                       'circle',                                                                               #неизменно,
                                       {'Dimensions':[[3, 10, 30, 159, 2000],                                                  #{'Dimensions':[[неизменно, Смещение выреза от центра (от ТО), None, None, None],
                                                      [325, 325, 325, 325, 325, 325, 325, 325, 325,325, 325, 325, 325], 12]},  #[шаг, шаг.....], кол-во]},
                                       'Поперечная перегородка'],                                                              #неизменно
                   'compensator': False,           #необходимость компенсатора
                   'loads_fitting_in':[3000,3000,3000,1600,2000,2400],         #Нагрузки на штуцера от КО, но надо знать на стадии теплового расчета, т.к. они 
                   'loads_fitting_out':[1000,1000,1000,1000,1200,1400],         #могут повлиять на первый и последний проем
                   'flow_movement': True,                             #Поменять направление движение среды (True - прямое(слева направо), False - обратное)
                   'environmental_hazard_class': 2,                   #Класс опасности среды, (от КО)
                   'flammability':True,                               #Воспломеняемость среды, (от КО)
                   'danger_of_explosion':True,                        #Взрывоопасность среды, (от КО)
                   'between_supports': '',                            #Расстояние между опорами (от КО)
                   'n_supports': '',                                  #Кол-во опорами (от КО)
                   'R_pipe_min':39,                                   #минимальный радиус гиба для U-образных труб (от ТО, ели u-образник)
                   'R_pipe_max':221,                                  #максимальный радиус гиба для U-образных труб  (от ТО, ели u-образник)
                   'user_fixed_support_poz' :'',                     #Положние опор (от КО)
                   'user_mobile_support_poz':'',                     #Положние опор (от КО)
                   'user_fixed_support_poz_y' :'',                   #Положние опор (от КО)
                   'user_mobile_support_poz_y':'',                   #Положние опор (от КО)
                  }
             }
          
        
        
        
    def HeatCalc(self, ProjectData):
        self.HeatCalcData = STHE_HeatCalculation(self, ProjectData)
        
        if self.HeatCalcData.CalculatedKArray != []:
            # Наполняем массив Design_input_dict
            # 'GENERAL' ПОКА!!!
            self.Design_input_dict['GENERAL']['customer'] = 'Газпром'
            self.Design_input_dict['GENERAL']['name_apparatus'] = 'Холодильник'
            self.Design_input_dict['GENERAL']['position'] = 'Т-100'
            self.Design_input_dict['GENERAL']['appointment_apparatus'] = 'Охлаждение воды'
            
            if self.PD.UserAnswers['mechanical_clean']['tube'] == True: # !!!!!!!!!!!!!!!
                self.Design_input_dict['GENERAL']['TEMA'] = 'A' + self.ShellType + 'M' # ПОКА!!!
            else:
                self.Design_input_dict['GENERAL']['TEMA'] = 'B' + self.ShellType + 'M' # ПОКА!!!

            self.Design_input_dict['GENERAL']['media_typ'] = 'WG'
            self.Design_input_dict['GENERAL']['order'] = 20088406
            self.Design_input_dict['GENERAL']['revision'] = self.number
            self.Design_input_dict['GENERAL']['area'] = self.HeatCalcData.F # Эффективная поверность одного корпуса, м²
            self.Design_input_dict['GENERAL']['D'] = self.HeatCalcData.TubePattern1.D
            #self.Design_input_dict['GENERAL']['heat_load'] = self.PD.HeatBalanceData.BalanceData[3]['COLD']['Q']/1000 # кВт
            self.Design_input_dict['GENERAL']['heat_load'] = 2800 # кВт
            self.Design_input_dict['GENERAL']['T_minimum'] = self.PD.UserAnswers2['GENERAL']['T_minimum']
            self.Design_input_dict['GENERAL']['climatic'] = self.PD.UserAnswers2['GENERAL']['climatic']
            self.Design_input_dict['GENERAL']['performance_device'] = self.PD.UserAnswers2['GENERAL']['performance_device']

            # 'TUBE' ПОКА!!!
            self.Design_input_dict['TUBE']['DN_IN'] = self.HeatCalcData.TubeNozzles[0] * 1000 # D патрубка входа, мм 
            self.Design_input_dict['TUBE']['DN_IN_diffuser'] = '' # D диффузора входа, мм
            self.Design_input_dict['TUBE']['DN_OUT'] = self.HeatCalcData.TubeNozzles[1] * 1000 # D патрубка выхода, мм
            self.Design_input_dict['TUBE']['DN_OUT_diffuser'] = '' # D диффузора выхода, мм
            if self.CaseNum == 1:
                self.Design_input_dict['TUBE']['DN_connecting'] = '' # D патрубка промежуточного, мм
            else:
                self.Design_input_dict['TUBE']['DN_connecting'] = '' # Пока !!!
            self.Design_input_dict['TUBE']['DN_deflating'] = '' # D воздушника, мм
            self.Design_input_dict['TUBE']['DN_drainage'] = '' # D дренажа, мм
            self.Design_input_dict['TUBE']['P_calculation'] = self.PD.UserAnswers2['TUBE']['P_calculation'] # Расчетное давление в трубном, МПа (изб.)
            self.Design_input_dict['TUBE']['P_vacuum'] = self.PD.UserAnswers2['TUBE']['P_vacuum'] # Вакуум в трубном, кПа (абс.)
            self.Design_input_dict['TUBE']['PN'] = 1.0 # Условное давление в трубном, МПа (изб.)
            if self.tube == 'COLD':
                self.Design_input_dict['TUBE']['P_IN'] = (self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Pressure'] - 101325) / 10**6 # Давление на входе, МПа (изб.)
                self.Design_input_dict['TUBE']['T_IN'] = self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Temperature'] # Температура на входе в трубном
                self.Design_input_dict['TUBE']['T_OUT'] = self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Temperature'] # Температура на выходе в трубном
                self.Design_input_dict['TUBE']['name_medium'] = self.PD.HeatBalanceData.BalanceData[0] # Название среды в трубном
                self.Design_input_dict['TUBE']['mass_consumption'] = self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Mass Flow'] * 3600 # массовый расход в трубном, кг/час
            else:
                self.Design_input_dict['TUBE']['P_IN'] = (self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Pressure'] - 101325) / 10**6 # Давление на входе, МПа (изб.)
                self.Design_input_dict['TUBE']['T_IN'] = self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Temperature'] # Температура на входе в трубном
                self.Design_input_dict['TUBE']['T_OUT'] = self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Temperature'] # Температура на выходе в трубном
                self.Design_input_dict['TUBE']['name_medium'] = self.PD.HeatBalanceData.BalanceData[1] # Название среды в трубном
                self.Design_input_dict['TUBE']['mass_consumption'] = self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Mass Flow'] * 3600 # массовый расход в трубном, кг/час

            self.Design_input_dict['TUBE']['hydraulic_friction'] = self.HeatCalcData.TubeHydraulics[0]/1000 # Потери гидравлики в трубном, кПа
            self.Design_input_dict['TUBE']['T_calculation'] = self.PD.UserAnswers2['TUBE']['T_calculation'] # Расчетная температура в трубном
            self.Design_input_dict['TUBE']['motion'] = self.TubePassNum # Количество ходов в трубном
            self.Design_input_dict['TUBE']['corrosion'] = self.PD.UserAnswers2['TUBE']['corrosion'] # Поправка на коррозию в трубном
            self.Design_input_dict['TUBE']['group_apparatus'] = self.PD.UserAnswers2['TUBE']['group_apparatus'] # Группа аппарата по ГОСТ 34347-2017

            # 'SHELL' ПОКА!!!
            self.Design_input_dict['SHELL']['DN_IN'] = self.HeatCalcData.ShellNozzles[0] * 1000 # D патрубка входа, мм 
            self.Design_input_dict['SHELL']['DN_IN_diffuser'] = '' # D диффузора входа, мм
            self.Design_input_dict['SHELL']['DN_OUT'] = self.HeatCalcData.ShellNozzles[1] * 1000 # D патрубка выхода, мм
            self.Design_input_dict['SHELL']['DN_OUT_diffuser'] = '' # D диффузора выхода, мм
            if self.CaseNum == 1:
                self.Design_input_dict['SHELL']['DN_connecting'] = '' # D патрубка промежуточного, мм
            else:
                self.Design_input_dict['SHELL']['DN_connecting'] = '' # Пока !!!
            self.Design_input_dict['SHELL']['DN_deflating'] = '' # D воздушника, мм
            self.Design_input_dict['SHELL']['DN_drainage'] = '' # D дренажа, мм
            self.Design_input_dict['SHELL']['P_calculation'] = self.PD.UserAnswers2['SHELL']['P_calculation'] # Расчетное давление, МПа (изб.)
            self.Design_input_dict['SHELL']['P_vacuum'] = self.PD.UserAnswers2['SHELL']['P_vacuum'] # Вакуум, кПа (абс.)
            self.Design_input_dict['SHELL']['PN'] = 1.0 # Условное давление, МПа (изб.)

            if self.shell == 'COLD':
                self.Design_input_dict['SHELL']['P_IN'] = (self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Pressure'] - 101325) / 10**6 # Давление на входе, МПа (изб.)
                self.Design_input_dict['SHELL']['T_IN'] = self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Temperature'] # Температура на входе в трубном
                self.Design_input_dict['SHELL']['T_OUT'] = self.PD.HeatBalanceData.BalanceData[3]['COLD']['OUT']['FLOW']['Temperature'] # Температура на выходе в трубном
                self.Design_input_dict['SHELL']['name_medium'] = self.PD.HeatBalanceData.BalanceData[0] # Название среды в трубном
                self.Design_input_dict['SHELL']['mass_consumption'] = self.PD.HeatBalanceData.BalanceData[3]['COLD']['IN']['FLOW']['Mass Flow'] * 3600 # массовый расход в трубном, кг/час
            else:
                self.Design_input_dict['SHELL']['P_IN'] = (self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Pressure'] - 101325) / 10**6 # Давление на входе, МПа (изб.)
                self.Design_input_dict['SHELL']['T_IN'] = self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Temperature'] # Температура на входе в трубном
                self.Design_input_dict['SHELL']['T_OUT'] = self.PD.HeatBalanceData.BalanceData[3]['HOT']['OUT']['FLOW']['Temperature'] # Температура на выходе в трубном
                self.Design_input_dict['SHELL']['name_medium'] = self.PD.HeatBalanceData.BalanceData[1] # Название среды в трубном
                self.Design_input_dict['SHELL']['mass_consumption'] = self.PD.HeatBalanceData.BalanceData[3]['HOT']['IN']['FLOW']['Mass Flow'] * 3600 # массовый расход в трубном, кг/час

            self.Design_input_dict['SHELL']['hydraulic_friction'] = self.HeatCalcData.ShellHydraulics[0]/1000 # Потери гидравлики в межтрубном, кПа
            self.Design_input_dict['SHELL']['T_calculation'] = self.PD.UserAnswers2['SHELL']['T_calculation'] # Расчетная температура в межтрубном
            self.Design_input_dict['SHELL']['motion'] = self.ShellPassNum # Количество ходов в межтрубном
            self.Design_input_dict['SHELL']['corrosion'] = self.PD.UserAnswers2['SHELL']['corrosion'] # Поправка на коррозию в межтрубном
            self.Design_input_dict['SHELL']['group_apparatus'] = self.PD.UserAnswers2['SHELL']['group_apparatus'] # Группа аппарата по ГОСТ 34347-2017

            self.Design_input_dict['SHELL']['N_pipe'] = sum(self.HeatCalcData.Tubes_By_Pass) # Количество теплообменных труб во всей разбивке

            self.Design_input_dict['SHELL']['D_pipe'] = self.TDiam * 1000 # Диаметр теплообменной трубы (наружный), мм
            self.Design_input_dict['SHELL']['S_pipe'] = round((self.TDiam - self.TDiam_in)/2 * 1000, 1) # Толщина теплообменной трубы, мм
            self.Design_input_dict['SHELL']['L_pipe'] = self.TubeLenght * 1000 # Длина теплообменной трубы, мм

            # 'REFERENCE' ПОКА!!!
            self.Design_input_dict['REFERENCE']['TUBE']['steel'][0] = '09Г2С' # Материал распределительной камеры
            self.Design_input_dict['REFERENCE']['SHELL']['steel'][0] = '09Г2С' # Материал корпуса 
            self.Design_input_dict['REFERENCE']['SHELL']['pipe'][0] = self.TM # Материал теплообменной трубы
            self.Design_input_dict['REFERENCE']['SHELL']['tube_sheet'][0] = '12Х18Н10Т' # Материал трубной решетки
            self.Design_input_dict['REFERENCE']['SHELL']['floating_head_cover'][0] = '12Х18Н10Т' # Материал плавающей головки
            self.Design_input_dict['REFERENCE']['SHELL']['partition'][0] = 'Ст3' # Материал перегородки
            self.Design_input_dict['REFERENCE']['SHELL']['compensator'][0] = '12Х18Н10Т' # Материал компенсатора

            # Наполняем массив Design_user_input
            # 'SHELL' Пока !!!!!
            self.Design_user_input['TUBE']['IN_FlangeAngle'] = 90 # Угол поворота штуцера входа
            self.Design_user_input['TUBE']['OUT_FlangeAngle'] = 270 # Угол поворота штуцера выхода
            self.Design_user_input['TUBE']['IN_FlangePosition_z'] = 0 # Смещение штуцера входа
            self.Design_user_input['TUBE']['OUT_FlangePosition_z'] = 0 # Смещение штуцера выхода
            self.Design_user_input['TUBE']['camera_partition'][2]['Dimensions'][1] = self.SDiam_in # Ширина перегородок в камере !!!!!!!!!!!!!!!!!
            self.Design_user_input['TUBE']['camera_partition'][4] = 'C' # Тип перегородок в камере !!!!!!!!!!!!!!!!
            self.Design_user_input['TUBE']['cap_partition'][2]['Dimensions'][1] = self.SDiam_in # Ширина перегородок в крышке !!!!!!!!!!!!!!!!!
            self.Design_user_input['TUBE']['cap_partition'][4] = 'C' # Тип перегородок в крышке !!!!!!!!!!!!!!!!
            self.Design_user_input['TUBE']['loads_fitting_in'] = [1,1,1,1,1,1] # Нагрузки на штуцер входа пока !!!!!!!!!!!!!!!!
            self.Design_user_input['TUBE']['loads_fitting_out'] = [1,1,1,1,1,1] # Нагрузки на штуцер выхода пока !!!!!!!!!!!!!!!!
            self.Design_user_input['TUBE']['flow_movement'] = False # Поменять направление движение среды пока !!!!!!!!!!!!!!!!

            # 'TUBE' Пока !!!!!
            self.Design_user_input['SHELL']['IN_FlangeAngle'] = 90 # Угол поворота штуцера входа
            self.Design_user_input['SHELL']['OUT_FlangeAngle'] = 270 # Угол поворота штуцера выхода
            self.Design_user_input['SHELL']['IN_FlangePosition_z'] = 0 # Смещение штуцера входа
            self.Design_user_input['SHELL']['OUT_FlangePosition_z'] = 0 # Смещение штуцера выхода
            #self.Design_user_input['SHELL']['longitudinal_partition'][2]['Dimensions'] = [self.HeatCalcData.longitudinal_partition*1000, self.SDiam_in*1000, 1] # Продольная перегородка [Длина, ширина, количество]
            self.Design_user_input['SHELL']['longitudinal_partition'][2]['Dimensions'] = [self.TubeLenght*1000 - 200, self.SDiam_in, 1] # Продольная перегородка [Длина, ширина, количество]
            
            #self.Design_user_input['SHELL']['anti_bypass_lane'][2]['Dimensions'] = [self.HeatCalcData.longitudinal_partition*1000, 25, 8] # Противобайпасная полоса [Длина, ширина, количество]
            self.Design_user_input['SHELL']['anti_bypass_lane'][2]['Dimensions'] = [self.TubeLenght*1000 - 200, 25, 8] # Противобайпасная полоса [Длина, ширина, количество]
            #self.Design_user_input['SHELL']['cross_partition'][2]['Dimensions'][0][1] = self.HeatCalcData.x_c*1000 # смещение выреза перегородки от оси аппарата, мм
            self.Design_user_input['SHELL']['cross_partition'][2]['Dimensions'][0][1] = self.SDiam_in/4 # смещение выреза перегородки от оси аппарата, мм
            self.Design_user_input['SHELL']['cross_partition'][2]['Dimensions'][1] = [325, 325, 325, 325, 325, 325, 325, 325, 325, 325, 325, 325, 325] # шаги перегородок, мм
            self.Design_user_input['SHELL']['cross_partition'][2]['Dimensions'][2] = 12 # количество перегородок
            self.Design_user_input['SHELL']['compensator'] = True # кнеобходимость в компенсаторе
            self.Design_user_input['SHELL']['loads_fitting_in'] = [1,1,1,1,1,1] # Нагрузки на штуцер входа пока !!!!!!!!!!!!!!!!
            self.Design_user_input['SHELL']['loads_fitting_out'] = [1,1,1,1,1,1] # Нагрузки на штуцер выхода пока !!!!!!!!!!!!!!!!
            self.Design_user_input['SHELL']['flow_movement'] = False # Поменять направление движение среды пока !!!!!!!!!!!!!!!!
            self.Design_user_input['SHELL']['R_pipe_min'] = 3*self.TDiam/2 * 1000 # минимальный радиус гиба для U-образных труб, мм пока !!!!!!!!!!!!!
            self.Design_user_input['SHELL']['R_pipe_max'] = self.SDiam_in/2 # максимальный радиус гиба для U-образных труб, мм пока !!!!!!!!!!!!!
            
    
    #def __repr__(self):
        #return str(self.__dict__)

'''
'ShellType': 'E', 'TubePassNum': 1, 'ShellPassNum': 1, 'CaseNum': 3, 'MLTD': 57.64908277902784, 'shell': 'COLD', 'tube': 'HOT', 'TFR': 0, 'SFR': 0, 'TDiam': 0.02, 'TDiam_in': 0.018000000000000002, 'TM': 'Сталь 20', 'TM_TC': 47.0, 'TubeNum': 59, 'TubeLenght': 1.0, 'SDiam_in': 0.257, 'LnD_Ratio': 3.8910505836575875, 'tube_delta_p': 52737.94880290739, 'shell_delta_p': 117273.92663147565, 'TA_DB': 4366.514285714286, 'SA_DB': 'Не удалось сделать репрезентативную выборку!', 'TA': 6272.381528559591, 'SA': 3013.531119076239, 'k': 1881.8316015462287, 'F': 11.121237993707869
'''