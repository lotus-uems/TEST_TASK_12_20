from .construction import *
from .heat_balance import *
from .heat_calculation import *
from .estimate import *

class STHE_Project():
    
    def __init__(self, UserInput, Answers):
        self.UserInput = UserInput # Данные для сведения теплового баланса
        self.UserAnswers = Answers # Данные для выбора конструкции
        self.UserAnswers2 = {
            'GENERAL':{
                'customer': 'ГАЗПРОМ',
                'name_apparatus': 'Холодильник',
                'position': 'Х-101',
                'appointment_apparatus': 'Охлаждение парового конденсата',
                'order': 20088406, # ПОКА!!!
                'revision': '', # ПОКА!!!
                'T_minimum': -40.0, # ПОКА!!!
                'climatic': 'УХЛ1', # ПОКА!!!
                'performance_device': 'горизонтальный' # ПОКА!!!
            },
            'TUBE':{
                'P_calculation': 1.6, # ПОКА!!!
                'P_vacuum': None, # ПОКА!!!
                'T_calculation': 200, # ПОКА!!!
                'corrosion': 2, # ПОКА!!!
                'group_apparatus': 1.0 # ПОКА!!!
            },
            'SHELL':{
                'P_calculation': 1.6, # ПОКА!!!
                'P_vacuum': None, # ПОКА!!!
                'T_calculation': 200, # ПОКА!!!
                'corrosion': 2, # ПОКА!!!
                'group_apparatus': 1.0 # ПОКА!!!
            }
        }
    
    # Сводим тепловой баланс
    def HeatBalance(self):
        self.HeatBalanceData = HeatBalance(self)
        print(self.HeatBalanceData)
        
    # Прикидочная функция
    def EstimatedCalculations(self):
        print('Выполняем прикидочный расчет...')
        self.EstimatedCalc = Estimate(self)
        self.Constructions = []
        for i in range(len(self.EstimatedCalc.DataAfterFilter)):
            self.Constructions.append(STHE_Construction(self, self.EstimatedCalc.DataAfterFilter[i]))
            self.Constructions[i].number = i
            print('Создана конструкция', i, self.Constructions[i].Solution)
            print()
    
    # Точно считаем все варианты
    def CalcAllConstructions(self):
        print()
        print('Детально рассчитываем все конструкции...')
        print()
        #self.Constructions[24].HeatCalc(self)
        for i in range(len(self.Constructions)):
            print(self.Constructions[i].number)
            self.Constructions[i].HeatCalc(self)
            '''
            print(i.HeatCalcData.TubePattern1)
            print(i.HeatCalcData.TubeHydraulics)
            print(i.HeatCalcData.ShellHydraulics)
            print(i.HeatCalcData.ShellPeretoki)
            print(i.HeatCalcData.ShellL_G)
            print(i.HeatCalcData.TubeAlphasArray)
            print(i.HeatCalcData.ShellAlphasCorrectedArray)
            print()
            '''
    
    # Ищем лучший вариант
    def FindBestConstruction(self):
        print('Ищем лучшую конструкцию...')
        Best = self.Constructions[0]
        for i in self.Constructions:
            if i.CalcData.K > Best.CalcData.K:
                Best = i
        print('Найдена лучшая конструкция с K = ', Best.CalcData.K)
        self.Best = Best
        
        