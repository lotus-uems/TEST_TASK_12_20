import math
# Функция для расчета наибольшей разности температур кожуха и труб
# t_tube_ave, t_shell_ave - средние температуры трубного и межтрубного

def GetMaxTempDeltaShellAndTube(t_wall_clean, t_wall_dirty, HBOutputArray, side_in_tube):
    
    if side_in_tube == 'HOT':
        t_shell_ave = (HBOutputArray[3]['COLD']['IN']['FLOW']['Temperature'] + HBOutputArray[3]['COLD']['OUT']['FLOW']['Temperature']) / 2
        TempDeltaShellAndTube1 = t_wall_clean - t_shell_ave
        TempDeltaShellAndTube2 = t_wall_dirty - t_shell_ave
        MaxTempDeltaShellAndTube = max(TempDeltaShellAndTube1, TempDeltaShellAndTube2)
    else:
        t_shell_ave = (HBOutputArray[3]['HOT']['IN']['FLOW']['Temperature'] + HBOutputArray[3]['HOT']['OUT']['FLOW']['Temperature']) / 2
        TempDeltaShellAndTube1 = t_shell_ave - t_wall_clean
        TempDeltaShellAndTube2 = t_shell_ave - t_wall_dirty
        MaxTempDeltaShellAndTube = max(TempDeltaShellAndTube1, TempDeltaShellAndTube2)
        
    return MaxTempDeltaShellAndTube
