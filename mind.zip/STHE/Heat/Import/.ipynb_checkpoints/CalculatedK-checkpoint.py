import math

# Расчет коэффициента теплопередачи БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ и С УЧЕТОМ ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ, Вт/(м²·°С)
# Расчет требуемого К (Вт/(м²·°С)) и полученного запаса поверхности (%). Анализ полученных результатов
def GetCaclculatedK(d, d_in, Lambda, alfa_tube, alfa_shell, pollution_resistance_tube, pollution_resistance_shell, HBOutputArray, F_fact, delta_T):
    # d, d_in - в м!
    # Lambda - теплопроводность материала стенки трубы, Вт/(м*°C)
    # alfa_tube - альфа трубного, Вт/(м2*°C)
    # alfa_shell - альфа межтрубного, Вт/(м2*°C)
    # pollution_resistance_tube - сопротивление загрязнений со стороны трубного пространства, м²·С/Вт
    # pollution_resistance_shell - сопротивление загрязнений со стороны межтрубного пространства, м²·С/Вт
    # Q - тепловая нагрузка аппарата, Вт!
    # F_fact - поверхность теплообмена ФАКТИЧЕСКАЯ, м2
    # delta_T - средний температурный напор в аппарате, °C
    
    Q = HBOutputArray[3]['HOT']['IN']['FLOW']['Heat Flow'] - HBOutputArray[3]['HOT']['OUT']['FLOW']['Heat Flow']
    
    # Коэффициент теплопередачи БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ, Вт/(м²·°С)
    K_clean = 1/(1/alfa_shell + (d*math.log(d/d_in)/(2*Lambda)) + d/(d_in*alfa_tube))
    
    # Коэффициент теплопередачи С УЧЕТОМ ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ, Вт/(м²·°С)
    K_dirty = 1/(1/alfa_shell + pollution_resistance_tube + (d*math.log(d/d_in)/(2*Lambda)) + d/(d_in*alfa_tube) + d*pollution_resistance_shell/d_in)
    
    # Требуемый К
    K_required = Q/F_fact/delta_T
    print('Q', Q)
    print('F_fact', F_fact)
    print('delta_T', delta_T)
    
    # Расчетная поверхность теплообмена, которой бы было достаточно БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ, м2
    F_clean = Q/delta_T/K_clean
    
    # Расчетная поверхность теплообмена, которой бы было достаточно С УЧЕТОМ ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ, м2
    F_dirty = Q/delta_T/K_dirty
    
    # Запас ЧИСТОЙ поверхности, %
    surface_margin_clean = (F_fact - F_clean)/F_clean*100
    
    # Запас ЗАГРЯЗНЕННОЙ поверхности, %
    surface_margin_dirty = (F_fact - F_dirty)/F_dirty*100
    
    
    return [K_clean, K_dirty, K_required, F_fact, F_clean, F_dirty, surface_margin_clean, surface_margin_dirty]
