import math

def GetTemperaturOfPipeWall(d, d_in, Lambda, alfa_tube, alfa_shell, side_in_tube, pollution_resistance_tube, pollution_resistance_shell, HB_Output_Array):
    # side_in_tube - какая среда находится в трубном
    # side_in_shell - какая среда находится в межтрубном
    # d, d_in - в м!
    # alfa_tube - альфа трубного, Вт/(м2*°C)
    # alfa_shell - альфа межтрубного, Вт/(м2*°C)
    # Lambda - теплопроводность материала стенки трубы, Вт/(м*°C)
    # pollution_resistance_tube - сопротивление загрязнений со стороны трубного пространства, м²·С/Вт
    # pollution_resistance_shell - сопротивление загрязнений со стороны межтрубного пространства, м²·С/Вт
    
    if side_in_tube == 'COLD':
        side_in_shell = 'HOT'
    else:
        side_in_shell = 'COLD'
    
    # Линейный коэффициент теплопередачи БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
    kl_clean = 1/((1/alfa_tube/d_in) + (math.log(d/d_in)/2/Lambda) + (1/alfa_shell/d))
    kl_dirty = 1/((1/(alfa_tube*d_in) + (1/(2*2)*math.log(d_in/(d_in - pollution_resistance_tube*2*2)) + (1/(2*Lambda)*math.log(d/d_in)) + (1/(2*2)*math.log((d + pollution_resistance_shell*2*2)/d))+(1/(alfa_shell*d)))))
    
    # Средние температуры трубного и межтрубного
    t_tube_ave = (HB_Output_Array[3][side_in_tube]['IN']['FLOW']['Temperature']+HB_Output_Array[3][side_in_tube]['OUT']['FLOW']['Temperature'])/2
    t_shell_ave = (HB_Output_Array[3][side_in_shell]['IN']['FLOW']['Temperature']+HB_Output_Array[3][side_in_shell]['OUT']['FLOW']['Temperature'])/2
    
    if side_in_tube == 'COLD': # Горячее в межтрубном
        # Линейный тепловой поток БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        ql_clean = kl_clean*math.pi*(t_shell_ave - t_tube_ave)
        #t_wall_clean_shell - температура стенки на поверхности трубы со стороны межтрубного БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        t_wall_clean_shell = t_shell_ave - ql_clean/(math.pi*alfa_shell*d)
        #t_wall_clean_tube - температура стенки на поверхности трубы со стороны трубного БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        t_wall_clean_tube = t_shell_ave - ql_clean/math.pi*((1/(alfa_shell*d))+(1/(2*Lambda)*math.log(d/d_in)))
        ##############
        # Линейный тепловой поток С УЧЕТОМ ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        ql_dirty = kl_dirty*math.pi*(t_shell_ave - t_tube_ave)
        #t_wall_dirty_shell - температура стенки на поверхности трубы со стороны межтрубного С УЧЕТОМ ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        t_wall_dirty_shell = t_shell_ave - ql_dirty/(math.pi*(1/(1/alfa_shell+pollution_resistance_shell))*d)
        #t_wall_dirty_tube - температура стенки на поверхности трубы со стороны трубного С УЧЕТОМ ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        t_wall_dirty_tube = t_shell_ave - ql_dirty/math.pi*((1/(1/(1/alfa_shell+pollution_resistance_shell))/d)+(1/2/Lambda*math.log(d/d_in)))
        
    else:  # Горячее в трубном
        # Линейный тепловой поток БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        ql_clean = kl_clean*math.pi*(t_tube_ave - t_shell_ave)
        #t_wall_clean_shell - температура стенки на поверхности трубы со стороны межтрубного БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        t_wall_clean_shell = t_tube_ave - ql_clean/math.pi*((1/(alfa_tube*d_in))+(1/(2*Lambda)*math.log(d/d_in)))
        #t_wall_clean_tube - температура стенки на поверхности трубы со стороны трубного БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        t_wall_clean_tube = t_tube_ave - ql_clean/math.pi*(1/(alfa_tube*d_in))
        ##############
        # Линейный тепловой поток С УЧЕТОМ ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        ql_dirty = kl_dirty*math.pi*(t_tube_ave - t_shell_ave)
        #t_wall_dirty_shell - температура стенки на поверхности трубы со стороны межтрубного С УЧЕТОМ ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        t_wall_dirty_shell = t_tube_ave - ql_dirty/math.pi*((1/(1/(1/alfa_tube + pollution_resistance_tube))/d_in) + (1/2/Lambda*math.log(d/d_in)))
        #t_wall_dirty_tube - температура стенки на поверхности трубы со стороны трубного С УЧЕТОМ ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ
        t_wall_dirty_tube = t_tube_ave - ql_dirty/(math.pi*(1/(1/alfa_tube + pollution_resistance_tube))*d_in)
        
    # t_wall_clean - температура стенки ЧИСТОЙ трубы (БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ)
    t_wall_clean = (t_wall_clean_shell + t_wall_clean_tube)/2
    # t_wall_dirty - температура стенки ЧИСТОЙ трубы (БЕЗ УЧЕТА ТЕРМИЧЕСКИХ СОПРОТИВЛЕНИЙ)
    t_wall_dirty = (t_wall_dirty_shell + t_wall_dirty_tube)/2

    return [t_wall_clean, t_wall_dirty]