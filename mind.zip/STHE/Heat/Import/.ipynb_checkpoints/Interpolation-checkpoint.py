import math

def PropsOfMixtureToHEC(HB_Output_Array, side, I_O):
    #Исходные данные
    Keys = ['Light Liquid', 'Heavy Liquid', 'Vapour']
    MixOfPhases = []

    for i in Keys:
        if HB_Output_Array[3][side][I_O]['FLOW'][i] is not None and HB_Output_Array[3][side][I_O]['FLOW'][i] != 0:
            MixOfPhases.append(i)
            
    mix_massflow = HB_Output_Array[3][side][I_O]['FLOW']['Mass Flow']
    
    massflow = []
    volflow = []
    density = []
    viscosity = []
    thermal_cond = []
    thermal_cond_x = []
    heat_capasity = []
    heat_capasity_x = []
    
    liquid_mix_mass_flow = 0
    liquid_mix_density = None
    liquid_mix_thermal_cond = None
    liquid_mix_viscosity = None
    
    vapour_mass_flow = HB_Output_Array[3][side][I_O]['FLOW']['Vapour']
    vapour_volflow = 0
    vapour_density = HB_Output_Array[3][side][I_O]['PROPERTIES']['Vapour']['density']
    vapour_capasity = HB_Output_Array[3][side][I_O]['PROPERTIES']['Vapour']['constant_p_specific_heat']
    vapour_thermal_cond = HB_Output_Array[3][side][I_O]['PROPERTIES']['Vapour']['thermal_conductivity']
    vapour_viscosity = HB_Output_Array[3][side][I_O]['PROPERTIES']['Vapour']['absolute_viscosity']
        
    for i in MixOfPhases:
        massflow.append(HB_Output_Array[3][side][I_O]['FLOW'][i])
        volflow.append(HB_Output_Array[3][side][I_O]['FLOW'][i] / HB_Output_Array[3][side][I_O]['PROPERTIES'][i]['density'])
        density.append(HB_Output_Array[3][side][I_O]['PROPERTIES'][i]['density'])
        viscosity.append(HB_Output_Array[3][side][I_O]['PROPERTIES'][i]['absolute_viscosity'])
        thermal_cond.append(HB_Output_Array[3][side][I_O]['PROPERTIES'][i]['thermal_conductivity'])
        thermal_cond_x.append(HB_Output_Array[3][side][I_O]['PROPERTIES'][i]['thermal_conductivity'] * HB_Output_Array[3][side][I_O]['FLOW'][i] / HB_Output_Array[3][side][I_O]['PROPERTIES'][i]['density'])
        heat_capasity.append(HB_Output_Array[3][side][I_O]['PROPERTIES'][i]['constant_p_specific_heat'])
        heat_capasity_x.append(HB_Output_Array[3][side][I_O]['PROPERTIES'][i]['constant_p_specific_heat'] * HB_Output_Array[3][side][I_O]['FLOW'][i])
        
    mix_volflow = sum(volflow)
    mix_density = mix_massflow / mix_volflow
    mix_heat_capasity = sum(heat_capasity_x) / mix_massflow
    #mix_thermal_cond = sum(thermal_cond_x) / mix_volflow  # - формула, принятая в модуле теплотехнического расчета ЛОТОС
    
        

    if 'Light Liquid' in MixOfPhases and 'Heavy Liquid' in MixOfPhases:
        liquid_mix_mass_flow = massflow[0] + massflow[1]
        liquid_mix_volflow = volflow[0] + volflow[1]
        liquid_mix_density = liquid_mix_mass_flow/liquid_mix_volflow
        liquid_mix_capasity = (heat_capasity_x[0] + heat_capasity_x[1])/liquid_mix_mass_flow
        
        liquid_mix_thermal_cond = (volflow[0] ** 2 * thermal_cond[0] +
                                           4 * volflow[0] * volflow[1] / (1 / thermal_cond[0] + 1 / thermal_cond[1]) +
                                           volflow[1] ** 2 * thermal_cond[1]) / liquid_mix_volflow ** 2
        if volflow[0] / liquid_mix_volflow >= 0.5:
            liquid_mix_viscosity = viscosity[0] * math.exp(3.6 * (1-volflow[0] / liquid_mix_volflow))
        elif volflow[0] / liquid_mix_volflow < 0.33:
            liquid_mix_viscosity = (1 + 2.5 * volflow[0] / liquid_mix_volflow *
                                            (viscosity[0] + 0.4 * viscosity[1]) /
                                            (viscosity[0] + viscosity[1])) * viscosity[1]
        else:
            liquid_mix_viscosity = ((viscosity[0] * math.exp(3.6 * (1-volflow[0] / liquid_mix_volflow))) *
                                            (volflow[0] / liquid_mix_volflow - 0.33) +
                                            (1 + 2.5 * volflow[0] / liquid_mix_volflow *
                                            (viscosity[0] + 0.4 * viscosity[1]) /
                                            (viscosity[0] + viscosity[1])) * viscosity[1] * 
                                            (0.5 - volflow[0] / liquid_mix_volflow))/0.17
        if 'Vapour' in MixOfPhases:
            vapour_volflow = HB_Output_Array[3][side][I_O]['FLOW']['Vapour']/HB_Output_Array[3][side][I_O]['PROPERTIES']['Vapour']['density']
            
            mix_thermal_cond = (liquid_mix_thermal_cond * liquid_mix_volflow + volflow[2] * thermal_cond[2]) / mix_volflow
            mix_viscosity = liquid_mix_viscosity * viscosity[2] * mix_volflow / (liquid_mix_viscosity * volflow[2] + viscosity[2] * liquid_mix_volflow)
        else:
            mix_thermal_cond = liquid_mix_thermal_cond
            mix_viscosity = liquid_mix_viscosity

    elif 'Light Liquid' in MixOfPhases or 'Heavy Liquid' in MixOfPhases:
        liquid_mix_mass_flow = massflow[0] 
        liquid_mix_volflow = volflow[0]
        liquid_mix_density = liquid_mix_mass_flow/liquid_mix_volflow
        liquid_mix_capasity = (heat_capasity_x[0])/liquid_mix_mass_flow
        
        liquid_mix_thermal_cond = thermal_cond[0]
        liquid_mix_viscosity = viscosity[0]
        if 'Vapour' in MixOfPhases:
            vapour_volflow = HB_Output_Array[3][side][I_O]['FLOW']['Vapour']/HB_Output_Array[3][side][I_O]['PROPERTIES']['Vapour']['density']
            
            mix_thermal_cond = (volflow[0] * thermal_cond[0] + volflow[1] * thermal_cond[1]) / mix_volflow
            mix_viscosity = viscosity[0] * viscosity[1] * mix_volflow / (viscosity[0] * volflow[1] + viscosity[1] * volflow[0])
        else:
            mix_thermal_cond = liquid_mix_thermal_cond
            mix_viscosity = liquid_mix_viscosity
    else:
        vapour_volflow = HB_Output_Array[3][side][I_O]['FLOW']['Vapour']/HB_Output_Array[3][side][I_O]['PROPERTIES']['Vapour']['density']
        
        mix_thermal_cond = thermal_cond[0]
        mix_viscosity = viscosity[0]
        
    result = {'MIX': [mix_massflow, mix_volflow, mix_density, mix_heat_capasity, mix_thermal_cond, mix_viscosity],
        'Mix_liquid': [liquid_mix_mass_flow, liquid_mix_volflow, liquid_mix_density, liquid_mix_capasity, liquid_mix_thermal_cond, liquid_mix_viscosity],
        'Vapour': [vapour_mass_flow, vapour_volflow, vapour_density, vapour_capasity, vapour_thermal_cond, vapour_viscosity]}
        
    return result


def GetInterpolatedProps(HB_Output_Array, side, Array):
    '''
    HB_Output_Array - массив, получаемый после сведения теплового баланса
    side - 'COLD' или 'HOT'
    Array - массив значений, относительно которых будет осуществляться интерполяция свойств среды по мере
    прохождения поверхности теплообмена ОТ ВХОДА ДО ВЫХОДА.
    Для трубного это будет массив количества труб по всем ходам, для межтрубного - массив длин проемов
    на пути прохождения среды L_Path
    Array = [150, 130, 100, 80]
    Формируем словарь InOutProps - словарь свойств среды на входе и выходе, который формируется в результате
    двухкратного обращения к функции PropsOfMixtureToHEC и принимает вид:
    {
    'IN' : [mix_massflow, mix_volflow, mix_density, mix_heat_capasity, mix_thermal_cond, mix_viscosity, T_IN],
    'OUT' : [mix_massflow, mix_volflow, mix_density, mix_heat_capasity, mix_thermal_cond, mix_viscosity, T_OUT]
    }
    
    На выходе получаем массив из массивов свойств вида: [InOutProps, InterpolatedPropsArray]
    [{температуры, все свойства и расходы на входе и на выходе из аппарата},[температура, все свойства и расходы на выходе из каждого хода/проема]]
    '''
    # Объединенные свойства смеси (паров и жидкостей) на входе и выходе:
    resIN = PropsOfMixtureToHEC(HB_Output_Array, side, 'IN')
    resOUT = PropsOfMixtureToHEC(HB_Output_Array, side, 'OUT')
    
    InOutProps = {'IN' : None, 'OUT' : None}
    InOutProps['IN'] = resIN['MIX']
    InOutProps['OUT'] = resOUT['MIX']
    
    LiqProps = {'IN' : None, 'OUT' : None}
    LiqProps['IN'] = resIN['Mix_liquid']
    LiqProps['OUT'] = resOUT['Mix_liquid']
    
    VapProps = {'IN' : None, 'OUT' : None}
    VapProps['IN'] = resIN['Vapour']
    VapProps['OUT'] = resOUT['Vapour']
    
    T_IN = HB_Output_Array[3][side]['IN']['FLOW']['Temperature']
    T_OUT = HB_Output_Array[3][side]['OUT']['FLOW']['Temperature']
    
    InOutProps['IN'].append(T_IN)
    InOutProps['OUT'].append(T_OUT)
    LiqProps['IN'].append(T_IN)
    LiqProps['OUT'].append(T_OUT)
    VapProps['IN'].append(T_IN)
    VapProps['OUT'].append(T_OUT)
    
    ########################### ИНТЕРПОЛИРУЕМ ВСЕ СВОЙСТВА ДЛЯ СМЕСИ ############################################################
    # Начинаем формировать массив интерполированных температур и свойств, начиная с добавления в него температуры и свойств входа
    InterpolatedPropsArray = [InOutProps['IN']]
    
    SUM = sum(Array)
    PropsDeltaArray = []
    for i in range(len(InOutProps['IN'])):
        PropsDeltaArray.append(InOutProps['IN'][i] - InOutProps['OUT'][i])
    
    coef = 0
    coef1 = 0
    for i in range(len(Array)):
        coef = Array[i]/SUM
        InterpolatedPropsArray.append([])
        for k in range(len(PropsDeltaArray)):
            InterpolatedPropsArray[i+1].append(InOutProps['IN'][k] - PropsDeltaArray[k]*(coef + coef1))
        coef1 = coef1 + coef
    # Превращаем массив InterpolatedPropsArray в словарь для удобства и наглядности, превращая температуру в каждой точке в ключ,
    # по которому видны все свойства
    IPA = {} # Словарь {температура: {'mass_flow': , 'vol_flow': ,'density': , 'heat_capasity': , 'thermal_cond': , 'viscosity': }}
    for i in InterpolatedPropsArray:
        IPA[i[-1]] = {'mass_flow': i[0], 'vol_flow': i[1],'density': i[2], 'heat_capasity': i[3], 'thermal_cond': i[4], 'viscosity': i[5]}
    
     ########################### ИНТЕРПОЛИРУЕМ ВСЕ СВОЙСТВА ДЛЯ ЖИЖКИ ############################################################
    # Начинаем формировать массив интерполированных температур и свойств, начиная с добавления в него температуры и свойств входа
    InterpolatedPropsArrayLIQ = [LiqProps['IN']]
    
    PropsDeltaArrayLIQ = []
    for i in range(len(LiqProps['IN'])):
        if LiqProps['IN'][i] == None:
            LiqProps['IN'][i] = 0
        if LiqProps['OUT'][i] == None:
            LiqProps['OUT'][i] = 0
        PropsDeltaArrayLIQ.append(LiqProps['IN'][i] - LiqProps['OUT'][i])

    coef = 0
    coef1 = 0
    for i in range(len(Array)):
        coef = Array[i]/SUM
        InterpolatedPropsArrayLIQ.append([])
        for k in range(len(PropsDeltaArrayLIQ)):
            InterpolatedPropsArrayLIQ[i+1].append(LiqProps['IN'][k] - PropsDeltaArrayLIQ[k]*(coef + coef1))
        coef1 = coef1 + coef
        
    ########################### ИНТЕРПОЛИРУЕМ ВСЕ СВОЙСТВА ДЛЯ ПАРА ############################################################
    # Начинаем формировать массив интерполированных температур и свойств, начиная с добавления в него температуры и свойств входа
    InterpolatedPropsArrayVAP = [VapProps['IN']]
    
    PropsDeltaArrayVAP = []
    for i in range(len(VapProps['IN'])):
        if VapProps['IN'][i] == None:
            VapProps['IN'][i] = 0
        if VapProps['OUT'][i] == None:
            VapProps['OUT'][i] = 0
        PropsDeltaArrayVAP.append(VapProps['IN'][i] - VapProps['OUT'][i])

    coef = 0
    coef1 = 0
    for i in range(len(Array)):
        coef = Array[i]/SUM
        InterpolatedPropsArrayVAP.append([])
        for k in range(len(PropsDeltaArrayVAP)):
            InterpolatedPropsArrayVAP[i+1].append(VapProps['IN'][k] - PropsDeltaArrayVAP[k]*(coef + coef1))
        coef1 = coef1 + coef
    
    #print('IPA', IPA, 'InterpolatedPropsArray', InterpolatedPropsArray)
    return [IPA, InterpolatedPropsArray, InterpolatedPropsArrayLIQ, InterpolatedPropsArrayVAP]
        
        
    
    