import math
from collections import Counter

pi = 3.1415

# Создаем класс для теплообменной трубы
class Tube:
    def __init__(self, x, y, row, col, calculated=False):
        self.x = x # координата x центра трубы
        self.y = y # координата y центра трубы
        self.row = row # номер ряда трубы (отсчет от горизонтальной оси аппарата: < 0 - для рядов выше оси, > 0 - для рядов ниже оси)
        self.col = col # колонка трубы (отсчет от вертикальной оси аппарата: > 0 - для рядов правее оси, < 0 - для рядов левее оси)
        self.calculated = calculated # Calculated - труба, вокруг центра которой построены все возможные трубы
        self.state = 0 # Статус: 0 - выключена, 1 - включена, 2 - вытеснена трубой, 3 - вытеснена перегородками, 4 - другое, 5 - у-образным гибом
        self.position = '' # 'up' - для разбивок "Повернутые треугольники" и "квадраты" - верхний ряд в паре, "down" - нижний в паре
        self.color = 'blue' # цвет линии окружности
        self.fill_color = 'white'
        self.v_i = None
        self.connections = {
            'D' : [],
            'Displacement_pipe' : {},
            'VDS' : {},
            'Buffles' : [],
            'NextTube' : {}
        }
        
    def __str__(self):
        return "<%s:%s [%s]>" %(self.x, self.y, self.state)
    
    def __repr__(self):
        return "<%s:%s [%s]>" %(self.x, self.y, self.state)
    
        
