from ipycanvas import MultiCanvas, hold_canvas
from .diameters import *

pi = 3.1415

def DrawTubePattern(canvas, TubePattern):
    
    deltaX = (TubePattern.D+10)/2
    deltaY =(TubePattern.D+10)/2
    size = 10
    pi = 3.1415926535

    DrawCircle(canvas, deltaX, deltaY, TubePattern.D/2, 2, color='red')
    if TubePattern.D != Diameters[TubePattern.D][0]:
        DrawCircle(canvas, deltaX, deltaY, TubePattern.D_in/2, 2, color='red')
    DrawCircle(canvas, deltaX, deltaY, TubePattern.OTL/2, 1, color='violet')
    if TubePattern.Displacement_pipe != None:
        DrawCircle(canvas, deltaX, deltaY, TubePattern.Displacement_pipe/2, 2, color='red')
    DrawLine(canvas, -TubePattern.D/2+deltaX, deltaY, TubePattern.D/2+deltaX, deltaY, 1, 'gray')
    DrawLine(canvas, deltaX, TubePattern.D/2+deltaY, deltaX, -TubePattern.D/2+deltaY, 0, 'gray')

    ###### Рисуем перегородки ########
    for i in TubePattern.Buffles:
        # Строим первый отрезок для "коридора" перегородки
        X1 = i.BuffleType[1][0]
        X2 = i.BuffleType[1][2]
        Y1 = i.BuffleType[1][1]
        Y2 = i.BuffleType[1][3]
        DrawLine(canvas, X1+deltaX, Y1+deltaY, X2+deltaX, Y2+deltaY, 1, 'green', [5, 10])
        # Строим первый отрезок для самой перегородки
        X_1 = i.BuffleType[2][0]
        X_2 = i.BuffleType[2][2]
        Y_1 = i.BuffleType[2][1]
        Y_2 = i.BuffleType[2][3]
        DrawLine(canvas, X_1+deltaX, Y_1+deltaY, X_2+deltaX, Y_2+deltaY, 1, 'green')
        
        # Строим второй отрезок для "коридора" перегородки
        X3 = i.BuffleType[1][4]
        X4 = i.BuffleType[1][6]
        Y3 = i.BuffleType[1][5]
        Y4 = i.BuffleType[1][7]
        DrawLine(canvas, X3+deltaX, Y3+deltaY, X4+deltaX, Y4+deltaY, 1, 'green', [5, 10])
        # Строим второй отрезок для самой перегородки
        X_3 = i.BuffleType[2][4]
        X_4 = i.BuffleType[2][6]
        Y_3 = i.BuffleType[2][5]
        Y_4 = i.BuffleType[2][7]
        DrawLine(canvas, X_3+deltaX, Y_3+deltaY, X_4+deltaX, Y_4+deltaY, 1, 'green')        
        
    # Рисуем центральную перегородку, если есть
    for i in TubePattern.V_Buffle_array:
        # Строим первый отрезок для "коридора" перегородки
        X1 = i.V_BuffleType[1][0]
        X2 = i.V_BuffleType[1][2]
        Y1 = i.V_BuffleType[1][1]
        Y2 = i.V_BuffleType[1][3]
        DrawLine(canvas, X1+deltaX, Y1+deltaY, X2+deltaX, Y2+deltaY, 1, 'green', [5, 10])
        # Строим первый отрезок для самой перегородки
        X_1 = i.V_BuffleType[2][0]
        X_2 = i.V_BuffleType[2][2]
        Y_1 = i.V_BuffleType[2][1]
        Y_2 = i.V_BuffleType[2][3]
        DrawLine(canvas, X_1+deltaX, Y_1+deltaY, X_2+deltaX, Y_2+deltaY, 1, 'green')
        
        # Строим второй отрезок для "коридора" перегородки
        X3 = i.V_BuffleType[1][4]
        X4 = i.V_BuffleType[1][6]
        Y3 = i.V_BuffleType[1][5]
        Y4 = i.V_BuffleType[1][7]
        DrawLine(canvas, X3+deltaX, Y3+deltaY, X4+deltaX, Y4+deltaY, 1, 'green', [5, 10])
        # Строим второй отрезок для самой перегородки
        X_3 = i.V_BuffleType[2][4]
        X_4 = i.V_BuffleType[2][6]
        Y_3 = i.V_BuffleType[2][5]
        Y_4 = i.V_BuffleType[2][7]
        DrawLine(canvas, X_3+deltaX, Y_3+deltaY, X_4+deltaX, Y_4+deltaY, 1, 'green')

    for i in TubePattern.DShell_array:
        # Строим первый отрезок для "коридора" перегородки
        X1 = i.DShell_Type[1][0]
        X2 = i.DShell_Type[1][2]
        Y1 = i.DShell_Type[1][1]
        Y2 = i.DShell_Type[1][3]
        DrawLine(canvas, X1+deltaX, Y1+deltaY, X2+deltaX, Y2+deltaY, 1, 'red', [5, 10])
        # Строим первый отрезок для самой перегородки
        X_1 = i.DShell_Type[2][0]
        X_2 = i.DShell_Type[2][2]
        Y_1 = i.DShell_Type[2][1]
        Y_2 = i.DShell_Type[2][3]
        DrawLine(canvas, X_1+deltaX, Y_1+deltaY, X_2+deltaX, Y_2+deltaY, 1, 'blue')
        
        # Строим второй отрезок для "коридора" перегородки
        X3 = i.DShell_Type[1][4]
        X4 = i.DShell_Type[1][6]
        Y3 = i.DShell_Type[1][5]
        Y4 = i.DShell_Type[1][7]
        DrawLine(canvas, X3+deltaX, Y3+deltaY, X4+deltaX, Y4+deltaY, 1, 'red', [5, 10])
        # Строим второй отрезок для самой перегородки
        X_3 = i.DShell_Type[2][4]
        X_4 = i.DShell_Type[2][6]
        Y_3 = i.DShell_Type[2][5]
        Y_4 = i.DShell_Type[2][7]
        DrawLine(canvas, X_3+deltaX, Y_3+deltaY, X_4+deltaX, Y_4+deltaY, 1, 'blue')
        
    """
    # Получаем массив скоростей для текущей разбивки
    Speeds = TubePattern.Speeds
    # Выводим полученные 
    count = 0
    v_i_dict = {}
    for i in TubePattern.TubesByRow.keys():
        N0 = Speeds[i][0]
        N_on_joint = Speeds[i][1]
        N_pipe = Speeds[i][2]
        v_i = Speeds[i][3]
        # Печатаем справа напротив каждого ряда: номер ряда, (кол-во труб в ряду итоговое/кол-во труб без вытеснения), скорость среды в каждом ряду
        DrawText(canvas, TubePattern.D/2 + 20 + deltaX, i*TubePattern.b+deltaY, str(i) + '  (' + str(N_on_joint) + ' / ' + str(N0) + ')'  + ' / v_i ' + str(v_i), size, 'black')
        count += 1
    """
    
    for i in TubePattern.Tubes:
        if i.state == 1:
            DrawCircle(canvas, i.x+deltaX, i.y+deltaY, TubePattern.d/2, 1, i.color, i.fill_color)
            # Печатаем внизу номера колонок
            DrawText(canvas, i.col*TubePattern.c + deltaX, TubePattern.D/2 + 20 + deltaY, str(i.col), size, 'black')
    for i in TubePattern.Tubes:
        if 'x' in i.connections['NextTube'].keys():
            DrawLine(canvas, i.x+deltaX, i.y+deltaY, i.connections['NextTube']['x']+deltaX, i.connections['NextTube']['y']+deltaY, 1, color='red')
        if 'x' in i.connections['Displacement_pipe'].keys():
            DrawLine(canvas, i.x+deltaX, i.y+deltaY, i.connections['Displacement_pipe']['x']+deltaX, i.connections['Displacement_pipe']['y']+deltaY, 1, color='red')
        if 'x' in i.connections['VDS'].keys():
            DrawLine(canvas, i.x+deltaX, i.y+deltaY, i.connections['VDS']['x']+deltaX, i.connections['VDS']['y']+deltaY, 1, color='red')
        for k in i.connections['D']:
            if 'x' in k.keys():
                DrawLine(canvas, i.x+deltaX, i.y+deltaY, k['x']+deltaX, k['y']+deltaY, 1, color='red')
        DrawText(canvas, i.x + deltaX-6, i.y + deltaY+2, str(i.row)+','+str(i.col), 8, 'black')
        
    #Рисуем номера ходов
    for i in TubePattern.TubesByPass:
        DrawText(canvas, i[2][0]+deltaX-TubePattern.d/2, i[2][1]+deltaY, i[0], TubePattern.d*2, 'blue')
        
    #Рисуем патрубки
    DrawLine(canvas, TubePattern.ShellNozzleXin1+deltaX, TubePattern.ShellNozzleYin11+deltaY, TubePattern.ShellNozzleXin1+deltaX, TubePattern.ShellNozzleYin12+deltaY, 1, 'red')
    DrawLine(canvas, TubePattern.ShellNozzleXin2+deltaX, TubePattern.ShellNozzleYin21+deltaY, TubePattern.ShellNozzleXin2+deltaX, TubePattern.ShellNozzleYin22+deltaY, 1, 'red')
    DrawLine(canvas, TubePattern.ShellNozzleXout1+deltaX, TubePattern.ShellNozzleYout11+deltaY, TubePattern.ShellNozzleXout1+deltaX, TubePattern.ShellNozzleYout12+deltaY, 1, 'blue')
    DrawLine(canvas, TubePattern.ShellNozzleXout2+deltaX, TubePattern.ShellNozzleYout21+deltaY, TubePattern.ShellNozzleXout2+deltaX, TubePattern.ShellNozzleYout22+deltaY, 1, 'blue')
            
def DrawCircle(canvas, x, y, D, width, color='black', fill_color='white'):
    canvas.stroke_style = color
    canvas.fill_style = fill_color
    #canvas.line_width = width
    canvas.fill_arc(x, y, D, 0, 2 * pi)
    canvas.stroke_arc(x, y, D, 0, 2 * pi)
    
def DrawLine(canvas, x1, y1, x2, y2, width, color='black', line_style = 'solid'):
    canvas.begin_path()
    if line_style != 'solid':
        canvas.set_line_dash(line_style)
    canvas.fill_style = color
    canvas.stroke_style = color
    canvas.line_width = width
    canvas.move_to(x1, y1)
    canvas.line_to(x2, y2)
    canvas.stroke()
    canvas.set_line_dash([])

def DrawText(canvas, x, y, text, size, color='black'):
    canvas.font = str(size) + 'px serif'
    canvas.fill_style = color
    canvas.fill_text(text, x, y)

def rgb_to_hex(rgb):
    return '%02x%02x%02x' % rgb