def tube_alpha(d_tubes_inside, l_tubes, ural_k, allowed_vel_number, n_tubes_passes):
    volflow_passes_in = []
    ave_dens_passes_in = []
    ave_visc_passes_in = []
    ave_heatcap_passes_in = []
    ave_thermcond_passes_in = []
    velocity_passes_in = []
    allowed_velocity_passes_in = []
    Prandtl_passes_in = []
    Reynolds_passes_in = []
    Nusselt_passes_in = []
    alpha_passes_in = []
    
    Prandtl_steam_passes_in = []
    Reynolds_steam_passes_in = []
    Nusselt_steam_passes_in = []
    alpha_steam_passes_in = []
    
    Prandtl_liq_passes_in = []
    Reynolds_liq_passes_in = []
    Nusselt_liq_passes_in = []
    alpha_liq_passes_in = []    
    
    for i in range(0, len(n_tubes_passes)):
        volflow_passes_in.append([massflow_passes_in[i][0] / dens_passes_in[i][0], massflow_passes_in[i][1] / dens_passes_in[i][1]])
        ave_dens_passes_in.append((massflow_passes_in[i][0] + massflow_passes_in[i][1]) / (volflow_passes_in[i][0] + volflow_passes_in[i][1]))
        ave_visc_passes_in.append((visc_passes_in[i][0] * visc_passes_in[i][1]) / ((visc_passes_in[i][0] * volflow_passes_in[i][1] / (volflow_passes_in[i][0] + volflow_passes_in[i][1])) + (visc_passes_in[i][1] * volflow_passes_in[i][0] / (volflow_passes_in[i][0] + volflow_passes_in[i][1]))))
        ave_heatcap_passes_in.append((massflow_passes_in[i][0] * heatcap_passes_in[i][0] + massflow_passes_in[i][1] * heatcap_passes_in[i][1]) / (massflow_passes_in[i][0] + massflow_passes_in[i][1]))
        ave_thermcond_passes_in.append((volflow_passes_in[i][0] * thermcond_passes_in[i][0] + volflow_passes_in[i][1] * thermcond_passes_in[i][1]) / (volflow_passes_in[i][0] + volflow_passes_in[i][1]))
        velocity_passes_in.append((volflow_passes_in[i][0] + volflow_passes_in[i][1]) / 3600 / cross_section_passes[i])
        allowed_velocity_passes_in.append((allowed_vel_number / ave_dens_passes_in[i])**0.5)
        
        if allowed_velocity_passes_in[i] < velocity_passes_in[i]:
            print('Значение скорости хода '+str(i+1)+' выходит за допустимый предел')
            print()
        
        '''
        # Определение показателей для смеси
        Prandtl_passes_in.append(ave_heatcap_passes_in[i] * ave_visc_passes_in[i] / ave_thermcond_passes_in[i] / 1000)
        Reynolds_passes_in.append(velocity_passes_in[i] * ave_dens_passes_in[i] * d_tubes_inside / ave_visc_passes_in[i])
        
        if Reynolds_passes_in[i] < 2300:
            Nusselt_passes_in.append(1.61 * (Reynolds_passes_in[i] * Prandtl_passes_in[i] * d_tubes_inside / l_tubes / 1000)**0.33 * 1.4)
        elif Reynolds_passes_in[i] < 10000:
            Nusselt_passes_in.append(0.008 * Reynolds_passes_in[i]**0.9 * Prandtl_passes_in[i]**0.43)
        else:
            Nusselt_passes_in.append(0.022 * Reynolds_passes_in[i]**0.8 * Prandtl_passes_in[i]**0.43)
            
        alpha_passes_in.append(Nusselt_passes_in[i] * ave_thermcond_passes_in[i] / d_tubes_inside * 1000)
        '''
        
        # Определение показателей для паровой фазы
        if massflow_passes_in[i][1] != 0:
            Prandtl_steam_passes_in.append(heatcap_passes_in[i][1] * visc_passes_in[i][1] / thermcond_passes_in[i][1] / 1000)
            Reynolds_steam_passes_in.append(velocity_passes_in[i] * dens_passes_in[i][1] * d_tubes_inside / visc_passes_in[i][1])
            
            if Reynolds_steam_passes_in[i] < 2300:
                Nusselt_steam_passes_in.append(1.61 * (Reynolds_steam_passes_in[i] * Prandtl_steam_passes_in[i] * d_tubes_inside / l_tubes / 1000)**0.33 * 1.4)
            elif Reynolds_steam_passes_in[i] < 10000:
                Nusselt_steam_passes_in.append(0.008 * Reynolds_steam_passes_in[i]**0.9 * Prandtl_steam_passes_in[i]**0.43)
            else:
                Nusselt_steam_passes_in.append(0.022 * Reynolds_steam_passes_in[i]**0.8 * Prandtl_steam_passes_in[i]**0.43)
                
            alpha_steam_passes_in.append(Nusselt_steam_passes_in[i] * thermcond_passes_in[i][1] / d_tubes_inside * 1000 * ural_k)
        else:
            Prandtl_steam_passes_in.append(0)
            Reynolds_steam_passes_in.append(0)
            Nusselt_steam_passes_in.append(0)
            alpha_steam_passes_in.append(0)
        
        # Определение показателей для жидкой фазы
        if massflow_passes_in[i][0] != 0:
            Prandtl_liq_passes_in.append(heatcap_passes_in[i][0] * visc_passes_in[i][0] / thermcond_passes_in[i][0] / 1000)
            Reynolds_liq_passes_in.append(velocity_passes_in[i] * dens_passes_in[i][0] * d_tubes_inside / visc_passes_in[i][0])
            
            if Reynolds_liq_passes_in[i] < 2300:
                Nusselt_liq_passes_in.append(1.61 * (Reynolds_liq_passes_in[i] * Prandtl_liq_passes_in[i] * d_tubes_inside / l_tubes / 1000)**0.33 * 1.4)
            elif Reynolds_liq_passes_in[i] < 10000:
                Nusselt_liq_passes_in.append(0.008 * Reynolds_liq_passes_in[i]**0.9 * Prandtl_liq_passes_in[i]**0.43)
            else:
                Nusselt_liq_passes_in.append(0.022 * Reynolds_liq_passes_in[i]**0.8 * Prandtl_liq_passes_in[i]**0.43)
                
            alpha_liq_passes_in.append(Nusselt_liq_passes_in[i] * thermcond_passes_in[i][0] / d_tubes_inside * 1000)
        else:
            Prandtl_liq_passes_in.append(0)
            Reynolds_liq_passes_in.append(0)
            Nusselt_liq_passes_in.append(0)
            alpha_liq_passes_in.append(0)
