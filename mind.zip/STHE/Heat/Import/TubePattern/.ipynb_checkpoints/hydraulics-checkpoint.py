import copy

def tube_hydraulics(TubeHydrInputArray):
    
    '''
    Функция рассчитывает гидравлическое сопротивление трубного пространства для одного корпуса
    '''
    vol_flow_in = TubeHydrInputArray['vol_flow_in']
    n_nozzle_in = TubeHydrInputArray['n_nozzle_in']
    d_nozzle_in = TubeHydrInputArray['d_nozzle_in']
    dens_in = TubeHydrInputArray['dens_in']
    vol_flow_out = TubeHydrInputArray['vol_flow_out']
    n_nozzle_out = TubeHydrInputArray['n_nozzle_out']
    d_nozzle_out = TubeHydrInputArray['d_nozzle_out']
    dens_out = TubeHydrInputArray['dens_out']
    velocity_ave = TubeHydrInputArray['velocity_ave']
    n_passes = TubeHydrInputArray['n_passes']
    dens_ave = TubeHydrInputArray['dens_ave']
    velocity_passes_in = TubeHydrInputArray['velocity_passes_in']
    density_passes_in = TubeHydrInputArray['density_passes_in']
    Re_passes = TubeHydrInputArray['Re_passes']
    l_tubes = TubeHydrInputArray['l_tubes']
    d_tubes_inside = TubeHydrInputArray['d_tubes_inside']
    velocity_passes_ave = TubeHydrInputArray['velocity_passes_ave']
    density_passes_ave = TubeHydrInputArray['density_passes_ave']
    
    delta_p_1 = 1.5 * (4 * vol_flow_in / (3.1415927 * n_nozzle_in * d_nozzle_in ** 2)) ** 2 * dens_in / 2 # входные патрубки
    delta_p_2 = 1.5 * (4 * vol_flow_out / (3.1415927 * n_nozzle_out * d_nozzle_out ** 2)) ** 2 * dens_out / 2 # выходные патрубки
    delta_p_3 = 2.5 * (n_passes - 1) * (velocity_ave / 2)**2 * dens_ave / 2 # распределительная камера (ОЧЕНЬ БОЛЬШОЙ КОЭФФИЦИЕНТ СОПРОТИВЛЕНИЯ НА РАЗВОРОТ В КАМЕРЕ + СТРАННО СЧИТАТЬ ПОТЕРИ В КАМЕРЕ ПО ПОЛОВИНЕ СРЕДНЕЙ СКОРОСТИ В ТРУБАХ ПО КОРПУСУ)

    la = []
    dp5 = []
    delta_p_4 = 0
    delta_p_5 = 0
    for i in range(n_passes):
        delta_p_4 = delta_p_4 + 2 * velocity_passes_in[i] ** 2 * density_passes_in[i] / 2  # ОЧЕНЬ БОЛЬШОЙ КОЭФФИЦИЕНТ СОПРОТИВЛЕНИЯ ДЛЯ ПОТЕРЬ НАПОРА НА ВХОДЕ В ТРУБЫ И НА ВЫХОДЕ ИЗ ТРУБ + СТРАННО СЧИТАТЬ ПОТЕРИ И ВХОДА И ВЫХОДА ПО СКОРОСТИ И ПЛОТНОСТИ НА ВХОДЕ
        
        if Re_passes[i] > 2320: # вычисляем коэффициенты лямбда для каждого хода
            if Re_passes[i] < 4000:
                la.append(64 / Re_passes[i] * (4000 - Re_passes[i]) + 0.3164 / Re_passes[i] ** 0.25 * (Re_passes[i] - 2300)) / 1700
            elif Re_passes[i] < 100000:
                la.append(0.3164 / Re_passes[i] ** 0.25) # Без учета шероховатости труб. АЛЬТШУЛЬ?
            else:
                la.append(0.0178)
        else:
            la.append(64/Re_passes[i])
    
        dp5.append((la[i] * (l_tubes / d_tubes_inside) * velocity_passes_ave[i]**2 * density_passes_ave[i] / 2))
        delta_p_5 = delta_p_5 + (la[i] * (l_tubes / d_tubes_inside) * velocity_passes_ave[i]**2 * density_passes_ave[i] / 2)
        
    delta_p = delta_p_1 + delta_p_2 + delta_p_3 + delta_p_4 + delta_p_5
    return [delta_p, dp5]

def FromHBtoHEC_tube_hydraulics(result_array, tubes_per_pass, n_passes, tube, d_tubes_inside, n_nozzle_in, n_nozzle_out, l_tubes):
    '''
    Функция принимает на вход массив баланса, некоторые данные о расчитанном аппарате и формирует массив для расчета гидравлики трубного пространства. Также определяет патрубки трубного
    '''

#Исходные данные
    massflow = result_array[3][tube]['IN']['FLOW']['Mass Flow']
    Keys = ['Light Liquid', 'Heavy Liquid', 'Vapour']
    IsNotNone_in = 0
    vol_flow_in = 0
    vol_flow_in_arr = []
    abs_visc_in_arr = []
    for i in Keys:
        vol_flow_i = result_array[3][tube]['IN']['FLOW'][i] / result_array[3][tube]['IN']['PROPERTIES'][i]['density'] if result_array[3][tube]['IN']['PROPERTIES'][i]['density'] is not None else None
        abs_visc_in_arr.append(result_array[3][tube]['IN']['PROPERTIES'][i]['absolute_viscosity']) #if result_array[3][tube]['IN']['FLOW'][i] is not None else None
        vol_flow_in_arr.append(vol_flow_i)
        vol_flow_in += vol_flow_i if vol_flow_i is not None else 0
        IsNotNone_in += 1 if vol_flow_i is not None else 0
    dens_in = massflow / vol_flow_in

    IsNotNone_out = 0
    vol_flow_out = 0
    vol_flow_out_arr = []
    abs_visc_out_arr = []
    for i in Keys:
        vol_flow_i = result_array[3][tube]['OUT']['FLOW'][i] / result_array[3][tube]['OUT']['PROPERTIES'][i]['density'] if result_array[3][tube]['OUT']['PROPERTIES'][i]['density'] is not None else None
        abs_visc_out_arr.append(result_array[3][tube]['OUT']['PROPERTIES'][i]['absolute_viscosity']) #if result_array[3][tube]['OUT']['FLOW'][i] is not None else None
        vol_flow_out_arr.append(vol_flow_i)
        vol_flow_out += vol_flow_i if vol_flow_i is not None else 0
        IsNotNone_out += 1 if vol_flow_i is not None else 0
    dens_out = massflow / vol_flow_out

    dens_ave = (dens_in + dens_out) / 2
    
    if IsNotNone_in == 1:
        for i in range(len(abs_visc_in_arr)):
            if abs_visc_in_arr[i] is not None:
                abs_visc_in = abs_visc_in_arr[i]
    elif IsNotNone_in == 2:
        vol_flow_in_arr2 = [vol_flow_in_arr[i] for i in range(3) if vol_flow_in_arr[i] is not None]
        abs_visc_in_arr2 = [abs_visc_in_arr[i] for i in range(3) if abs_visc_in_arr[i] is not None]
        abs_visc_in = abs_visc_in_arr2[0]*abs_visc_in_arr2[1]*vol_flow_in / (abs_visc_in_arr2[1]*vol_flow_in_arr2[0] + abs_visc_in_arr2[0]*vol_flow_in_arr2[1])
    else:
        vol_flow_in_liq = vol_flow_in_arr[0] + vol_flow_in_arr[1]
        abs_visc_in_liq = abs_visc_in_arr[0]*abs_visc_in_arr[1]*vol_flow_in_liq / (abs_visc_in_arr[1]*vol_flow_in_arr[0] + abs_visc_in_arr[0]*vol_flow_in_arr[1])
        abs_visc_in = abs_visc_in_arr[2]*abs_visc_in_liq*vol_flow_in / (abs_visc_in_arr[2]*vol_flow_in_liq + abs_visc_in_liq*vol_flow_in_arr[2])

    if IsNotNone_out == 1:
        for i in range(len(abs_visc_out_arr)):
            if abs_visc_out_arr[i] is not None:
                abs_visc_out = abs_visc_out_arr[i]
    elif IsNotNone_out == 2:
        vol_flow_out_arr2 = [vol_flow_out_arr[i] for i in range(3) if vol_flow_out_arr[i] is not None]
        abs_visc_out_arr2 = [abs_visc_out_arr[i] for i in range(3) if abs_visc_out_arr[i] is not None]
        abs_visc_out = abs_visc_out_arr2[0]*abs_visc_out_arr2[1]*vol_flow_out / (abs_visc_out_arr2[1]*vol_flow_out_arr2[0] + abs_visc_out_arr2[0]*vol_flow_out_arr2[1])
    else:
        vol_flow_out_liq = vol_flow_out_arr[0] + vol_flow_out_arr[1]
        abs_visc_out_liq = abs_visc_out_arr[0]*abs_visc_out_arr[1]*vol_flow_out_liq / (abs_visc_out_arr[1]*vol_flow_out_arr[0] + abs_visc_out_arr[0]*vol_flow_out_arr[1])
        abs_visc_out = abs_visc_out_arr[2]*abs_visc_out_liq*vol_flow_out / (abs_visc_out_arr[2]*vol_flow_out_liq + abs_visc_out_liq*vol_flow_out_arr[2])
        
    visc_ave = (abs_visc_in + abs_visc_out) / 2
    
    velocity_passes_in = []
    density_passes_in = []
    Re_passes = []
    for i in range(n_passes):
        velocity_passes_in.append(4 * vol_flow_in / tubes_per_pass[i] / 3.1415927 / d_tubes_inside ** 2)
        density_passes_in.append(dens_ave)
        Re_passes.append(density_passes_in[i] * velocity_passes_in[i] * d_tubes_inside / visc_ave)

    velocity_passes_ave = copy.deepcopy(velocity_passes_in)
    density_passes_ave = []
    density_passes_out = copy.deepcopy(density_passes_in)
    velocity_ave = sum(velocity_passes_ave)/len(velocity_passes_ave)

    for i in range(n_passes):
        density_passes_ave.append((density_passes_in[i] + density_passes_out[i]) / 2)
    
    # Определеяем диаметр патрубков
    nozzles = [10, 15, 20, 25, 32, 40, 50, 65, 80, 100, 125, 150, 200, 250, 300, 350, 400, 450, 500, 600, 700, 800] # Стандартный ряд патрубков по ГОСТ
    vel_nozzle_in_allowed = (2250 / dens_in)**0.5
    vel_nozzle_out_allowed = (2250 / dens_out)**0.5
    d_nozzle_in = (4 * vol_flow_in / 3.1415927 / vel_nozzle_in_allowed / n_nozzle_in)**0.5 * 1000
    for i in nozzles:
        if d_nozzle_in <= i:
            d_nozzle_in = i
            break
    d_nozzle_out = (4 * vol_flow_out / 3.1415927 / vel_nozzle_out_allowed / n_nozzle_out)**0.5 * 1000
    for i in nozzles:
        if d_nozzle_out <= i:
            d_nozzle_out = i
            break
    return {'vol_flow_in': vol_flow_in,
            'n_nozzle_in': n_nozzle_in,
            'd_nozzle_in': d_nozzle_in,
            'dens_in': dens_in,
            'vol_flow_out': vol_flow_out,
            'n_nozzle_out': n_nozzle_out,
            'd_nozzle_out': d_nozzle_out,
            'dens_out': dens_out,
            'velocity_ave': velocity_ave,
            'n_passes': n_passes,
            'dens_ave': dens_ave,
            'velocity_passes_in': velocity_passes_in,
            'density_passes_in': density_passes_in,
            'Re_passes': Re_passes,
            'l_tubes': l_tubes,
            'd_tubes_inside': d_tubes_inside,
            'velocity_passes_ave': velocity_passes_ave,
            'density_passes_ave': density_passes_ave
           }
