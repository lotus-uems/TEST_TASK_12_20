import math
from .diameters import *

# Создаем класс для перегородок межтрубного прстранства  
class DShell:
    def __init__(self, Angle, d, D, Design_clearance):
        self.Angle = Angle # угол поворота перегородки относительно оси x (горизонтальной оси аппарата)
        self.d = d # диаметр труб
        self.D = D # характерный диаметр аппарата
        self.D_in = Diameters[D][0] # внутренний диаметр аппарата
        self.Design_clearance = Design_clearance
        self.Thikness = Diameters[D][2][0] # Толщина перегородки в зависимости от диаметра аппарата
        self.OTL_DShell= self.Thikness+2*Design_clearance # Толщина "коридора"
        
        # Создаем массив с координатами отрезков для вытеснения труб и типом гиба (горизонтальный, вертикальный, радиальный)
        self.GetDShellType()
        
    def __repr__(self):
        return "<%s:%s>" %(self.Thikness)
       
    # Определяем координаты точек, по которым будут строиться линии, образующие "коридор"
    # пополняем этими данными массив DShell_Type
    def GetDShellType(self):
        DShell_Type = []
        # рассчитываем переменные a, b, c, A, B, C - промежуточные вычисления
        # x_1, x_2, x_3, x_4, y_1, y_2, y_3, y_4 - координаты для построения линий для построения перегородки в камере (сплошная)
        # x1, x2, x3, x4, y1, y2, y3, y4 - координаты для построения линий, показывающих "коридор" вокруг перегородки с учетом конструктивного зазора (пунктир)
        
        a = 0
        b = a - self.OTL_DShell/2 # Для построения "коридора перегородки"
        c = a + self.OTL_DShell/2 # Для построения "коридора перегородки"
        
        b_ = a - self.Thikness/2 # Для построения перегородки непосредственно
        c_ = a + self.Thikness/2 # Для построения перегородки непосредственно

        A = self.OTL_DShell/2
        B = ((self.D_in/2)**2-b**2)**(0.5)
        C = ((self.D_in/2)**2-c**2)**(0.5)
        
        A_ = self.Thikness/2 # Для построения перегородки непосредственно
        B_ = ((self.D_in/2)**2-b_**2)**(0.5) # Для построения перегородки непосредственно
        C_ = ((self.D_in/2)**2-c_**2)**(0.5) # Для построения перегородки непосредственно
        
        if self.Angle == 0:
            x1 = round((-1)*B, 10) # Для построения "коридора перегородки"
            x_1 = (-1)*B_ # Для построения перегородки непосредственно
        if self.Angle == 90:
            x1 = round(self.OTL_DShell/2, 6)
            x_1 = round(self.Thikness/2, 6) 

        if self.Angle == 0:
            x2 = (-1)*x1
            x_2 = (-1)*x_1
        if self.Angle == 90:
            x2 = x1
            x_2 = x_1

        if self.Angle == 0:
            x3 = round((-1)*C, 10)
            x_3 = round((-1)*C_, 10)
        if self.Angle == 90:
            x3 = - round(self.OTL_DShell/2, 6)
            x_3 = - round(self.Thikness/2, 6)

        if self.Angle == 0:
            x4 = (-1)*x3
            x_4 = (-1)*x_3
        if self.Angle == 90:
            x4 = x3
            x_4 = x_3

        if self.Angle == 0:
            y1 = round((-1)*self.OTL_DShell/2, 10)
            y_1 = round((-1)*self.Thikness/2, 10)
        if self.Angle == 90:
            y1 = round(B, 6)
            y_1 = round(B_, 6)

        if self.Angle == 0:
            y2 = y1
            y_2 = y_1
        if self.Angle == 90:
            y2 = (-1)*y1
            y_2 = (-1)*y_1

        if self.Angle == 0:
            y3 = round(self.OTL_DShell/2, 10)
            y_3 = round(self.Thikness/2, 10)
        if self.Angle == 90:
            y3 = round(C, 6)
            y_3 = round(C_, 6)
            
        if self.Angle == 0:
            y4 = y3
            y_4 = y_3
        if self.Angle == 90:
            y4 = (-1)*y3
            y_4 = (-1)*y_3

        if self.Angle == 0:
            Type = 'Горизонтальная перегородка межтрубного пространства'
            DShell_Type = [Type, [x1, y1, x2, y2, x3, y3, x4, y4], [x_1, y_1, x_2, y_2, x_3, y_3, x_4, y_4]]   

        if self.Angle == 90:
            Type = 'Вертикальная перегородка межтрубного пространства'
            DShell_Type = [Type, [x1, y1, x2, y2, x3, y3, x4, y4], [x_1, y_1, x_2, y_2, x_3, y_3, x_4, y_4]]  
        
        #print(DShell_Type)
        self.DShell_Type = DShell_Type