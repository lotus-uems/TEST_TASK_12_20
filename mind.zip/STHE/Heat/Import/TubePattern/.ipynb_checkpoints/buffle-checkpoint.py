import math
from .diameters import *

# Создаем класс для перегородки    
class Buffle:
    def __init__(self, x, y, Angle, D, Design_clearance):
        self.x = x # координата x центра перегородки
        self.y = y # координата y центра перегородки
        self.Angle = Angle # угол поворота перегородки относительно оси x (горизонтальной оси аппарата)
        self.D_in = Diameters[D][0] # Внутренний диаметр аппарата
        self.Design_clearance = Design_clearance
        self.Thikness = Diameters[D][2][0] # Толщина перегородки в зависимости от диаметра аппарата
        self.OTL_buffle = self.Thikness+2*Design_clearance # Толщина "коридора" под перегородку с учетом конструктивного зазора (5мм)
        
        # Конвертируем массив перегородок в массив с координатами отрезков и типами перегородок
        self.GetBuffleType()
        
    def __repr__(self):
        return "<%s:%s [%s]>" %(self.x, self.y, self.Thikness)
       
    # Определяем координаты точек, по которым будут строиться линии, образующие "коридор" перегородки
    # (с учетом толщины перегородки и конструктивного зазора),
    # а также определяем тип каждой перегородки
    # (радиальная - центр находится в центре аппарата, остальные перегородки - с центром в любой другой точке)
    # пополняем этими данными массив BuffleTypes  
    def GetBuffleType(self):
        BuffleType = []            
        # рассчитываем переменные a, b, c, A, B, C - промежуточные вычисления
        # x_1, x_2, x_3, x_4, y_1, y_2, y_3, y_4 - координаты для построения линий для построения перегородки в камере (сплошная)
        # x1, x2, x3, x4, y1, y2, y3, y4 - координаты для построения линий, показывающих "коридор" вокруг перегородки с учетом конструктивного зазора (пунктир)
        
        a = (self.x**2+self.y**2)**(0.5)
        b = a - self.OTL_buffle/2 # Для построения "коридора перегородки"
        c = a + self.OTL_buffle/2 # Для построения "коридора перегородки"
        
        b_ = a - self.Thikness/2 # Для построения перегородки непосредственно
        c_ = a + self.Thikness/2 # Для построения перегородки непосредственно

        A = self.OTL_buffle/2 # Для построения "коридора перегородки"
        B = ((self.D_in/2)**2-b**2)**(0.5) # Для построения "коридора перегородки"
        C = ((self.D_in/2)**2-c**2)**(0.5) # Для построения "коридора перегородки"
        
        A_ = self.Thikness/2 # Для построения перегородки непосредственно
        B_ = ((self.D_in/2)**2-b_**2)**(0.5) # Для построения перегородки непосредственно
        C_ = ((self.D_in/2)**2-c_**2)**(0.5) # Для построения перегородки непосредственно


        if self.Angle == 0:
            x1 = (-1)*B # Для построения "коридора перегородки"
            x_1 = (-1)*B_ # Для построения перегородки непосредственно
        elif self.Angle == 90:
            if (self.x-self.OTL_buffle/2)>0:
                x1 = self.x-(self.OTL_buffle/2)
            elif (self.x-self.OTL_buffle/2)<0:
                x1 = (self.x+self.OTL_buffle/2)
            else:
                x1 = 0
            
            if (self.x-self.Thikness/2)>0:
                x_1 = self.x-(self.Thikness/2)
            elif (self.x-self.Thikness/2)<0:
                x_1 = (self.x+self.Thikness/2)
            else:
                x_1 = 0 
                
        else:
            x1 = (-1)*math.cos(math.radians(self.Angle))*(((self.D_in/2)**2-(self.OTL_buffle/2)**2)**0.5-math.tan(math.radians(self.Angle))*(self.OTL_buffle/2))
            x_1 = (-1)*math.cos(math.radians(self.Angle))*(((self.D_in/2)**2-(self.Thikness/2)**2)**0.5-math.tan(math.radians(self.Angle))*(self.Thikness/2))

        if self.Angle == 0:
            x2 = (-1)*x1
            x_2 = (-1)*x_1
        elif self.Angle == 90:
            x2 = x1
            x_2 = x_1
        else:
            x2 = (self.D_in/2)*math.cos(math.radians(self.Angle)-math.asin(self.OTL_buffle/self.D_in))
            x_2 = (self.D_in/2)*math.cos(math.radians(self.Angle)-math.asin(self.Thikness/self.D_in))

        if self.Angle == 0:
            x3 = (-1)*C
            x_3 = (-1)*C_
        elif self.Angle == 90:
            if (self.x - self.OTL_buffle/2) > 0:
                x3 = self.x + self.OTL_buffle/2
            elif (self.x - self.OTL_buffle/2) < 0:
                x3 = self.x - self.OTL_buffle/2
            else:
                x3 = 0
                
            if (self.x - self.Thikness/2) > 0:
                x_3 = self.x + self.Thikness/2
            elif (self.x - self.Thikness/2) < 0:
                x_3 = self.x - self.Thikness/2
            else:
                x_3 = 0
                
        else:
            x3 = (-1)*x2
            x_3 = (-1)*x_2

        if self.Angle == 0:
            x4 = (-1)*x3
            x_4 = (-1)*x_3
        elif self.Angle == 90:
            x4 = x3
            x_4 = x_3
        else:
            x4 = (-1)*x1
            x_4 = (-1)*x_1

        if self.Angle == 0:
            if self.y >= 0:
                y1 = self.y-(self.OTL_buffle/2)
                y_1 = self.y-(self.Thikness/2)
            else:
                y1 = self.y+(self.OTL_buffle/2)
                y_1 = self.y+(self.Thikness/2)
        elif self.Angle == 90:
            y1 = B
            y_1 = B_
        else:
            y1 = (-1)*(math.sin(math.radians(self.Angle))*(((self.D_in/2)**2 - (self.OTL_buffle/2)**2)**0.5 - math.tan(math.radians(self.Angle))*(self.OTL_buffle/2)) + (self.OTL_buffle/2)/math.cos(math.radians(self.Angle)))
            y_1 = (-1)*(math.sin(math.radians(self.Angle))*(((self.D_in/2)**2 - (self.Thikness/2)**2)**0.5 - math.tan(math.radians(self.Angle))*(self.Thikness/2)) + (self.Thikness/2)/math.cos(math.radians(self.Angle)))

        if self.Angle == 0:
            y2 = y1
            y_2 = y_1
        elif self.Angle == 90:
            y2 = (-1)*y1
            y_2 = (-1)*y_1
        else:
            y2 = (self.D_in/2)*(math.sin(math.radians(self.Angle) - math.asin(self.OTL_buffle/self.D_in)))
            y_2 = (self.D_in/2)*(math.sin(math.radians(self.Angle) - math.asin(self.Thikness/self.D_in)))

        if self.Angle == 0:
            if self.y >= 0:
                y3 = self.y + (self.OTL_buffle/2)
                y_3 = self.y + (self.Thikness/2)
            else:
                y3 = self.y - (self.OTL_buffle/2)
                y_3 = self.y - (self.Thikness/2)
        else:
            if self.Angle == 90:
                y3 = C
                y_3 = C_
            else:
                y3 = (-1)*y2
                y_3 = (-1)*y_2

        if self.Angle == 0:
            y4 = y3
            y_4 = y_3
        elif self.Angle == 90:
            y4 = (-1)*y3
            y_4 = (-1)*y_3
        else:
            y4 = (-1)*y1
            y_4 = (-1)*y_1

        if self.x == 0 and self.y == 0:
            Type = 'Радиальные перегородки'
            BuffleType = [Type, [x1, y1, x2, y2, x3, y3, x4, y4], [x_1, y_1, x_2, y_2, x_3, y_3, x_4, y_4]]   

        else:
            Type = 'Остальные перегородки'
            BuffleType = [Type, [x1, y1, x2, y2, x3, y3, x4, y4], [x_1, y_1, x_2, y_2, x_3, y_3, x_4, y_4]]  

        self.BuffleType = BuffleType
