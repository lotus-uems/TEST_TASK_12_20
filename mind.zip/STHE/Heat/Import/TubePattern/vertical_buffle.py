import math
from .diameters import *

# Создаем класс для вертикальной перегородки  
class V_Buffle:
    def __init__(self, d, D, Design_clearance):
        self.d = d # диаметр труб
        self.D = D # характерный диаметр аппарата
        self.D_in = Diameters[D][0] # Внутренний диаметр аппарата
        self.Design_clearance = Design_clearance
        self.Thikness = Diameters[D][2][0] # Толщина перегородки в зависимости от диаметра аппарата
        self.OTL_buffle = self.Thikness+2*Design_clearance # Толщина "коридора" под перегородку с учетом конструктивного зазора (5мм)
        
        # Конвертируем массив перегородок в массив с координатами отрезков и типами перегородок
        self.Get_V_BuffleType()
        
    def __repr__(self):
        return "<%s:%s>" %(self.Thikness)
    
    # Определяем координаты точек, по которым будут строиться линии, образующие "коридор"
    # пополняем этими данными массив U_Types  
    def Get_V_BuffleType(self):
        V_BuffleType = []            
        # рассчитываем переменные a, b, c, A, B, C - промежуточные вычисления
        # x_1, x_2, x_3, x_4, y_1, y_2, y_3, y_4 - координаты для построения линий для построения перегородки в камере (сплошная)
        # x1, x2, x3, x4, y1, y2, y3, y4 - координаты для построения линий, показывающих "коридор" вокруг перегородки с учетом конструктивного зазора (пунктир)
        
        a = 0
        b = a - self.OTL_buffle/2 # Для построения "коридора перегородки"
        c = a + self.OTL_buffle/2 # Для построения "коридора перегородки"
        
        b_ = a - self.Thikness/2 # Для построения перегородки непосредственно
        c_ = a + self.Thikness/2 # Для построения перегородки непосредственно

        A = self.OTL_buffle/2
        B = ((self.D_in/2)**2-b**2)**(0.5)
        C = ((self.D_in/2)**2-c**2)**(0.5)
        
        A_ = self.Thikness/2 # Для построения перегородки непосредственно
        B_ = ((self.D_in/2)**2-b_**2)**(0.5) # Для построения перегородки непосредственно
        C_ = ((self.D_in/2)**2-c_**2)**(0.5) # Для построения перегородки непосредственно

        x1 = round(self.OTL_buffle/2, 6)
        x_1 = round(self.Thikness/2, 6)

        x2 = x1
        x_2 = x_1

        x3 = - round(self.OTL_buffle/2, 6)
        x_3 = - round(self.Thikness/2, 6)

        x4 = x3
        x_4 = x_3

        y1 = round(B, 6)
        y_1 = round(B_, 6)

        y2 = (-1)*y1
        y_2 = (-1)*y_1

        y3 = round(C, 6)
        y_3 = round(C_, 6)

        y4 = (-1)*y3
        y_4 = (-1)*y_3

        Type = 'Вертикальный перегородка'
        V_BuffleType = [Type, [x1, y1, x2, y2, x3, y3, x4, y4], [x_1, y_1, x_2, y_2, x_3, y_3, x_4, y_4]]   

        self.V_BuffleType = V_BuffleType