﻿from tube_pattern import *
from diameters import *
from buffle import *
from U_bend import *
from vertical_buffle import *
from dshell import *
from sideseg import *
from minD import *

def Magic(PatternCharacter, d, N_tube_passes, N_tubes_in_pass, Displacement_pipe, Fluoroplastic_Seal, Floating_head, U, DS, VDS, Design_clearance):
   
    if Displacement_pipe == 0:
        Displacement_pipe=None
    
    Buffles = []
    TubesByPass = []
    U_bend_array = []
    V_Buffle_array = []
    DShell_array = []
    
    v_buff = False
    flag = False
    
    while flag == False:
    
        mDF = minDFull1(d, N_tubes_in_pass, N_tube_passes, PatternCharacter, Floating_head, Fluoroplastic_Seal)
        
        if mDF == False:
            return False
        
        D = mDF[2]
        
        a = Count_a(Diameters, D, Floating_head, Fluoroplastic_Seal)

        # Шаг перегородок, мм
        h = 100
        # Объемный расход среды в межтрубном, м3/час
        V = 0.02*3600

        Array = 'Перейти на новый диаметр'
        #print('Стартовый диаметр', D)

        while type(Array) == str:
            TubePattern1 = TubePattern(PatternCharacter, D, a, d, Design_clearance, Displacement_pipe, U_bend_array, V_Buffle_array, DShell_array, Buffles, TubesByPass)

            # Наличие у-образного гиба
            if U == True:
                if N_tube_passes > 2:
                    v_buff = True
                if v_buff == True or VDS == True:
                    U_bend_array = [U_bend(90, TubePattern1.d, TubePattern1.D)]
                else:
                    U_bend_array = [U_bend(0, TubePattern1.d, TubePattern1.D)]
                if VDS == True and N_tube_passes == 4:
                    U_bend_array = [U_bend(0, TubePattern1.d, TubePattern1.D)]
            
            #print(U_bend_array)
            
            # Наличие вертикальной перегородки (для разбивки трубного "по долькам")
            if v_buff == True:
                V_Buffle_array = [V_Buffle(TubePattern1.d, TubePattern1.D, Design_clearance)]

            # Два хода по межтрубному (наличие продольной перегородки в межтрубном пространстве)
            if DS == True:
                DShell_array = [DShell(0, TubePattern1.d, TubePattern1.D, Design_clearance)]

            # Два хода по межтрубному и движение среды межтрубного вдоль продольной перегородки
            if VDS == True:
                DShell_array = [DShell(90, TubePattern1.d, TubePattern1.D, Design_clearance)]
                v_buff = True

            TubePattern1 = TubePattern(PatternCharacter, D, a, d, Design_clearance, Displacement_pipe, U_bend_array, V_Buffle_array, DShell_array, Buffles, TubesByPass)
            TubePattern1.BuildTubes(0, 0, 0, 0)
            Y_0 = TubePattern1.GetY0()
            #print(Y_0)
            TubePattern1.CutTubes([],[])

            if DS == True:
                Array = TubePattern1.SetAllBufflesHorizontalDS(N_tubes_in_pass, N_tube_passes, Y_0, Diameters[D][2], v_buff)
            else:
                Array = TubePattern1.SetAllBufflesHorizontal(N_tubes_in_pass, N_tube_passes, Y_0, Diameters[D][2], v_buff, VDS)

            #print(Array)
            if Array == 'Перейти на новый диаметр':
                D = NextD(Diameters, D)
                
                if D == False and v_buff == True:
                    return False
                
                if D == False:
                    if N_tube_passes == 1 or N_tube_passes == 3:
                        return False
                    else:
                        D = 3200
                        v_buff = True
                        #print('Уходим на разбивку "по долькам"')
                        continue
                
                a = Count_a(Diameters, D, Floating_head, Fluoroplastic_Seal)
                #print('Уходим на новый диаметр', D)
            else:
                Buffles = Array[0]
                TubesByPass = Array[3]
                TubePattern1 = TubePattern(PatternCharacter, D, a, d, Design_clearance, Displacement_pipe, U_bend_array, V_Buffle_array, DShell_array, Buffles, TubesByPass)
                TubePattern1.BuildTubes(0, 0, 0, 0)
                Off_rows_bottom_array = Array[-2]
                Off_rows_top_array = Array[-1]
                delta = 0
                #count = 0
                while abs(len(Off_rows_top_array) - len(Off_rows_bottom_array)) > delta or len(Off_rows_top_array) < len(Off_rows_bottom_array):
                    #print('Сдвиг', Off_rows_top_array, Off_rows_bottom_array)
                    #count = count + 1
                    Y_0 = Y_0 + TubePattern1.b
                    Buffles = []
                    TubesByPass = []
                    TubePattern1 = TubePattern(PatternCharacter, D, a, d, Design_clearance, Displacement_pipe, U_bend_array, V_Buffle_array, DShell_array, Buffles, TubesByPass)
                    TubePattern1.BuildTubes(0, 0, 0, 0)
                    TubePattern1.CutTubes([],[])

                    if DS == True:
                        Array = TubePattern1.SetAllBufflesHorizontalDS(N_tubes_in_pass, N_tube_passes, Y_0, Diameters[D][2], v_buff)
                    else:
                        Array = TubePattern1.SetAllBufflesHorizontal(N_tubes_in_pass, N_tube_passes, Y_0, Diameters[D][2], v_buff, VDS)

                    #print(Array)
                    if type(Array) == str:
                        delta = delta + 1
                        #print('delta', delta)
                        Y_0 = TubePattern1.GetY0()
                        Buffles = []
                        TubesByPass = []
                        TubePattern1 = TubePattern(PatternCharacter, D, a, d, Design_clearance, Displacement_pipe, U_bend_array, V_Buffle_array, DShell_array, Buffles, TubesByPass)
                        TubePattern1.BuildTubes(0, 0, 0, 0)
                        TubePattern1.CutTubes([],[])

                        if DS == True:
                            Array = TubePattern1.SetAllBufflesHorizontalDS(N_tubes_in_pass, N_tube_passes, Y_0, Diameters[D][2], v_buff)
                        else:
                            Array = TubePattern1.SetAllBufflesHorizontal(N_tubes_in_pass, N_tube_passes, Y_0, Diameters[D][2], v_buff, VDS)

                    if N_tube_passes == 1:
                    #if Array[1][-1] == 'delta':
                        delta = delta + 1
                        #print('Array delta', delta)
                    Off_rows_bottom_array = Array[-2]
                    Off_rows_top_array = Array[-1]
                    #print('Выход', Off_rows_top_array, Off_rows_bottom_array)
                    #print('Кол-во труб в ходах:', Array[1])
                Buffles = Array[0]
                TubesByPass = Array[3]
                #Buffles = []
                #print('Кол-во труб в ходах:', Array[1])
                #print('Кол-во труб с номерами ходов', Array[3])

                #print(U_bend_array)
                TubePattern1 = TubePattern(PatternCharacter, D, a, d, Design_clearance, Displacement_pipe, U_bend_array, V_Buffle_array, DShell_array, Buffles, TubesByPass)
                TubePattern1.BuildTubes(0, 0, 0, 0)
                #print(Off_rows_bottom_array, Off_rows_top_array)

                if DS == True:
                    Off_rows_bottom_array1 = copy.deepcopy(Off_rows_bottom_array)
                    for k in Off_rows_bottom_array1:
                        Off_rows_bottom_array.append(-k)

                    Off_rows_top_array1 = copy.deepcopy(Off_rows_top_array)
                    for k in Off_rows_top_array1:
                        Off_rows_top_array.append(-k)

                #Off_rows_bottom_array.append(0)
                TubePattern1.CutTubes(Off_rows_bottom_array, Off_rows_top_array)
                TubePattern1.GroupRows()
                TubePattern1.BuildXGrid()
        
        if N_tube_passes > 1:
            # Максимальное полученное количество труб в ходу:
            Max = max(Array[1])
            # Минимальное полученное количество труб в ходу:
            Min = min(Array[1])
            # Анализируем разницу и принимаем решение, переходить ли на расположение ходов трубного "по долькам":

            if Max != Min and v_buff == False:
                if DS == True or U == True:
                    if N_tube_passes in [4, 8, 12, 16, 20]:
                        v_buff = True
                        #print('Уходим на разбивку "по долькам"')
                        Buffles = []
                        U_bend_array = []
                        V_Buffle_array = []
                        DShell_array = []
                        SideSeg_array = []
                        continue
                    else:
                        flag = True
                else:
                    if N_tube_passes != 3:
                        v_buff = True
                        #print('Уходим на разбивку "по долькам"')
                        Buffles = []
                        U_bend_array = []
                        V_Buffle_array = []
                        DShell_array = []
                        SideSeg_array = []
                        continue
                    else:
                        flag = True
            else:
                flag = True
        else:
            flag = True
            continue
            
    return [D, Array[1], v_buff]