﻿import math
import copy
from collections import Counter

from tube import *
from buffle import *
from diameters import *

pi = 3.1415

class TubePattern:
    step_array = [[10,15],[12,17],[16,21],[20,26],[25,32],[32,40],[38,48],[57,70]] 
    
    def __init__(self, PatternCharacter, D, a, d, Design_clearance, Displacement_pipe, U_bend_array, V_Buffle_array, DShell_array, Buffles, TubesByPass):
        self.PatternCharacter = PatternCharacter
        self.D = D # Определяющий диаметр аппарата
        self.D_in = Diameters[D][0] # Внутренний диаметр аппарата
        self.a = a
        self.U_bend_array = U_bend_array # Массив с объектами класса U_bend
        self.V_Buffle_array = V_Buffle_array # Массив с объектами класса V_Buffle
        self.DShell_array = DShell_array # Массив с объектами класса DShell
        self.d = d
        self.Design_clearance = Design_clearance
        self.Displacement_pipe = Displacement_pipe
        self.Buffles = Buffles
        self.OTL = self.D_in - 2*a
        self.ShowSpeeds = False
        self.TubesByPass = TubesByPass
        
        self.DNozzle = self.D/4
        
        self.ShellNozzleXin1 = 0-self.DNozzle/2
        self.ShellNozzleXin2 = 0+self.DNozzle/2
        self.ShellNozzleYin11 = -((self.D/2)**2-(self.ShellNozzleXin1)**2)**0.5
        self.ShellNozzleYin12 = self.ShellNozzleYin11-self.D/10
        self.ShellNozzleYin21 = -((self.D/2)**2-(self.ShellNozzleXin2)**2)**0.5
        self.ShellNozzleYin22 = self.ShellNozzleYin21-self.D/10
        
        self.ShellNozzleXout1 = 0-self.DNozzle/2
        self.ShellNozzleXout2 = 0+self.DNozzle/2
        self.ShellNozzleYout11 = ((self.D/2)**2-(self.ShellNozzleXout1)**2)**0.5
        self.ShellNozzleYout12 = self.ShellNozzleYout11+self.D/10
        self.ShellNozzleYout21 = ((self.D/2)**2-(self.ShellNozzleXout2)**2)**0.5
        self.ShellNozzleYout22 = self.ShellNozzleYout21+self.D/10
        
        # Вытеснительная труба
        if Displacement_pipe != None:
            self.OTL_tube = Displacement_pipe + 2*Design_clearance
        else:
            self.OTL_tube = None
            
        # U-образные трубы    
        #if U == True:
            #Buffle_U = Buffle(2*self.d, 0, 0, 0, self.D_in, 0)
            #self.Buffles.append(Buffle_U)
            
            
        # Шаг между трубами
        for i in range(len(self.step_array)):
            if d == self.step_array[i][0]:
                self.step = self.step_array[i][1]
        # Определяем углы, необходимые для построения трубной разбивки исходя из характера разбивки
        if self.PatternCharacter == 'Треугольники':
            self.alpha = 60
            self.rotation = 0
            self.delta_row = 0
            self.delta_col = 2
        if self.PatternCharacter == 'Повернутые треугольники':
            self.alpha = 60
            self.rotation = 90
            self.delta_row = 1
            self.delta_col = 1
        if self.PatternCharacter == 'Квадраты':
            self.alpha = 90
            self.rotation = 45
            self.delta_row = 1
            self.delta_col = 1
        if self.PatternCharacter == 'Коридорные квадраты':
            self.alpha = 90
            self.rotation = 0
            self.delta_row = 0
            self.delta_col = 1
        
        if PatternCharacter == 'Треугольники': 
            self.b = self.step*math.cos(math.radians(self.alpha/2)) # шаг между рядами труб
            self.c = self.step/2 # шаг между колонками
        if PatternCharacter == 'Повернутые треугольники':
            self.b = self.step/2
            self.c = self.step*math.cos(math.radians(self.alpha/2))
        if PatternCharacter == 'Квадраты':
            self.b = self.step*math.cos(math.radians(self.alpha/2))
            self.c = self.b
        if PatternCharacter == 'Коридорные квадраты':
            self.b = self.step
            self.c = self.step
    
    ############### ФУНКЦИИ НАПОЛНЕНИЯ РАЗБИВКИ ТРУБАМИ #################
    """
    def BuildTubes_slow(self, dX, dY, row, col):
        self.Tubes = [Tube(dX, dY, row, col)]
        self.TubesByRow = {}
        go = True
        while go:
            go = False
            for i in self.Tubes:
                if not i.calculated:
                    MoreTubes = self.BuildTubesSinglePoint(i.x, i.y, i.row, i.col)
                    for k in MoreTubes:
                        if k.row not in self.TubesByRow.keys():
                            self.TubesByRow[k.row] = {}
                        if k.col not in self.TubesByRow[k.row].keys():
                            self.Tubes.append(k)
                            self.TubesByRow[k.row][k.col]  = k
                            go = True
                    i.calculated = True
    """
    def BuildTubes(self, dX, dY, row, col):
        self.Tubes = [Tube(dX, dY, row, col)]
        self.TubesByRow = {0:{0:self.Tubes[0]}}
        current_task = [self.Tubes[0]]
        next_task = []
        go = True
        while go:
            go = False
            for i in current_task:
                MoreTubes = self.BuildTubesSinglePoint(i.x, i.y, i.row, i.col)
                for k in MoreTubes:
                    if k.row not in self.TubesByRow.keys():
                        self.TubesByRow[k.row] = {}
                    if k.col not in self.TubesByRow[k.row].keys():
                        self.Tubes.append(k)
                        self.TubesByRow[k.row][k.col]  = k
                        go = True
                        next_task.append(k)
            current_task = next_task
            next_task = []
        self.AllTubes = (i for i in self.Tubes)
    
    # Функция проверки наличия трубы с заданным номером ряда и колонки в общем массиве self.Tubes
    def CheckTube(self, row, col):
        for i in self.Tubes:
            if i.row == row and i.col == col:
                return True
        return False
    
    # Построение труб вокруг одной трубы (взятой как центр построения) с учетом характера разбивки,
    # присвоение каждой новой трубе координат ее центра (x, y), номера ряда и номера колонки, которым она будет принадлежать.
    # Трубы, вышедшие за пределы диаметра OTL, не строятся.
    def BuildTubesSinglePoint(self, dX, dY, row, col):
        Tubes = []
        if self.PatternCharacter == 'Треугольники':
                   
            for i in range(int(360/self.alpha)):
                delta_row = 0
                delta_col = 0
                if 0<i*self.alpha<90:
                    delta_col = 1
                    delta_row = 1
                if 90<i*self.alpha<180:
                    delta_col = -1
                    delta_row = 1
                if 180<i*self.alpha<270:
                    delta_col = -1
                    delta_row = -1
                if 270<i*self.alpha<360:
                    delta_col = 1
                    delta_row = -1
                if i*self.alpha == 90:
                    delta_row = 1
                if i*self.alpha == 270:
                    delta_row = -1
                if i*self.alpha == 0:
                    delta_col = 2
                if i*self.alpha == 180:
                    delta_col = -2
                ar = math.radians(i*self.alpha + self.rotation)
                dX1 = self.step*math.cos(ar)+dX
                dY1 = self.step*math.sin(ar)+dY
                if ((math.sqrt(dX1**2 + dY1**2) + self.d/2) <= self.OTL/2):
                    Tubes.append(Tube(dX1, dY1, row + delta_row, col + delta_col))
            return Tubes
        
        if  self.PatternCharacter == 'Повернутые треугольники':
                   
            for i in range(int(360/self.alpha)):
                
                i_alpha = i*self.alpha + self.rotation
                ar = math.radians(i_alpha)
 
                delta_row = 0
                delta_col = 0
                if i_alpha == 90:
                    delta_row = 2
                    delta_col = 0
                if i_alpha == 150:
                    delta_row = 1
                    delta_col = -1
                if i_alpha == 210:
                    delta_row = -1
                    delta_col = -1
                if i_alpha == 270:
                    delta_row = -2
                    delta_col = 0
                if i_alpha == 330:
                    delta_row = -1
                    delta_col = 1
                if i_alpha == 390:
                    delta_row = 1
                    delta_col = 1
                dX1 = self.step*math.cos(ar)+dX
                dY1 = self.step*math.sin(ar)+dY
                if ((math.sqrt(dX1**2 + dY1**2) + self.d/2) <= self.OTL/2):
                    Tubes.append(Tube(dX1, dY1, row + delta_row, col + delta_col))
            return Tubes
        
        if self.PatternCharacter == 'Коридорные квадраты':
            for i in range(int(360/self.alpha)):
                delta_row = 0
                delta_col = 0
                if i*self.alpha == 90:
                    delta_row = 1
                if i*self.alpha == 270:
                    delta_row = -1
                if i*self.alpha == 0:
                    delta_col = 1
                if i*self.alpha == 180:
                    delta_col = -1
                ar = math.radians(i*self.alpha)
                dX1 = self.step*math.cos(ar)+dX
                dY1 = self.step*math.sin(ar)+dY
                if ((math.sqrt(dX1**2 + dY1**2) + self.d/2) <= self.OTL/2):
                    Tubes.append(Tube(dX1, dY1, row + delta_row, col + delta_col))
            return Tubes
        
        if self.PatternCharacter == 'Квадраты':
            for i in range(int(360/self.alpha)):
                
                i_alpha = i*self.alpha + self.rotation
                ar = math.radians(i_alpha)

                delta_row = 0
                delta_col = 0
                if i_alpha == 45:
                    delta_row = 1
                    delta_col = 1
                if i_alpha == 135:
                    delta_row = 1
                    delta_col = -1
                if i_alpha == 225:
                    delta_row = -1
                    delta_col = -1
                if i_alpha == 315:
                    delta_row = -1
                    delta_col = 1

                dX1 = self.step*math.cos(ar)+dX
                dY1 = self.step*math.sin(ar)+dY
                if ((math.sqrt(dX1**2 + dY1**2) + self.d/2) <= self.OTL/2):
                    Tubes.append(Tube(dX1, dY1, row + delta_row, col + delta_col))
            return Tubes
    ################ 

    
    ################ Вытеснение труб перегородками и вытеснительной трубой
    def CutTubes(self, Off_rows_bottom_array, Off_rows_top_array):
        for row in sorted(self.TubesByRow.keys()):
            if row in Off_rows_bottom_array or row in Off_rows_top_array:
                for col in list(sorted(self.TubesByRow[row].keys())):
                    self.TubesByRow[row][col].state = 4
                    
        N_on_sum = 0
        for i in self.Tubes:
            if i.state != 4 and i.state != 5:
                i.state = 1
                if self.Displacement_pipe != None:
                    if ((i.x**2 + i.y**2)**0.5 - self.d/2) < (self.Displacement_pipe/2 + self.Design_clearance):
                        i.state = 2
                        
                if self.CheckBuffles(i.x, i.y) == False:
                    i.state = 3
                
                if self.CheckUBend(i.x, i.y) == False:
                    i.state = 5
                    
                if self.CheckVBuffle(i.x, i.y) == False:
                    i.state = 5
                    #print('i.state', i.state)
                    
                if self.CheckDShell(i.x, i.y) == False:
                    i.state = 5
                        
                if i.state == 1:
                    N_on_sum += 1
                    
        self.N_on_sum = N_on_sum
        self.BuildTubesByRow()
                    
    # Далее проверяем на вытеснение перегородками
    def CheckBuffles(self, x, y):
        # Проверяем на вытеснение перегородками в камере
        for i in self.Buffles:
            dist1 = round(self.GetDistance(x, y, i.BuffleType[1][0], i.BuffleType[1][1], i.BuffleType[1][2], i.BuffleType[1][3]), 6) # округление необходимо 
            dist2 = round(self.GetDistance(x, y, i.BuffleType[1][4], i.BuffleType[1][5], i.BuffleType[1][6], i.BuffleType[1][7]), 6) # округление необходимо  
            if dist1 < self.d / 2 or dist2 < self.d / 2 or dist1 + dist2 <= i.OTL_buffle:
                return False
        return True
        
    # Далее проверяем на вытеснение U-образным гибом
    def CheckUBend(self, x, y):
        # Проверяем на вытеснение U-образным гибом
        for i in self.U_bend_array:
            dist1 = round(self.GetDistance(x, y, i.U_Type[1][0], i.U_Type[1][1], i.U_Type[1][2], i.U_Type[1][3]), 6) # округление необходимо 
            dist2 = round(self.GetDistance(x, y, i.U_Type[1][4], i.U_Type[1][5], i.U_Type[1][6], i.U_Type[1][7]), 6) # округление необходимо  
            if dist1 < self.d / 2 or dist2 < self.d / 2 or dist1 + dist2 <= i.OTL_U:
                return False
        return True
    
    # Далее проверяем на вытеснение вертикальной перегородкой
    def CheckVBuffle(self, x, y):
        # Проверяем на вытеснение вертикальной перегородкой
        for i in self.V_Buffle_array:
            dist1 = round(self.GetDistance(x, y, i.V_BuffleType[1][0], i.V_BuffleType[1][1], i.V_BuffleType[1][2], i.V_BuffleType[1][3]), 6) # округление необходимо 
            dist2 = round(self.GetDistance(x, y, i.V_BuffleType[1][4], i.V_BuffleType[1][5], i.V_BuffleType[1][6], i.V_BuffleType[1][7]), 6) # округление необходимо  
            if dist1 < self.d / 2 or dist2 < self.d / 2 or dist1 + dist2 <= i.OTL_buffle:
                return False
        return True
    
    def CheckDShell(self, x, y):
        # Проверяем на вытеснение продольной перегородкой
        for i in self.DShell_array:
            dist1 = round(self.GetDistance(x, y, i.DShell_Type[1][0], i.DShell_Type[1][1], i.DShell_Type[1][2], i.DShell_Type[1][3]), 6) # округление необходимо 
            dist2 = round(self.GetDistance(x, y, i.DShell_Type[1][4], i.DShell_Type[1][5], i.DShell_Type[1][6], i.DShell_Type[1][7]), 6) # округление необходимо  
            if dist1 < self.d / 2 or dist2 < self.d / 2 or dist1 + dist2 <= i.OTL_DShell:
                return False
        return True
    
    # Считаем расстояние от центра трубы до каждой из двух прямых, образующих "коридор" перегородки
    # (с учетом толщины перегородки и конструктивного зазора)
    def GetDistance(self, x0, y0, x1, y1, x2, y2):
        return abs((y2 - y1) * x0 - (x2 - x1) * y0 + x2 * y1 - y2 * x1) / math.sqrt((y2 - y1) ** 2 + (x2 - x1) ** 2)
    ######################
   
    ############## ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ##################
    
    # Функция формирует словарь TubesByRow с ключами рядов и колонок, хранящий сами объекты - трубы
    def BuildTubesByRow(self): 
        self.TubesByRow = {}
        for i in self.Tubes:
            if i.row not in self.TubesByRow.keys():
                self.TubesByRow[i.row] = {}
            self.TubesByRow[i.row][i.col]  = i
        #self.MaxRows = len(self.TubesByRow.keys())
        
    # Функция возвращает сортированный массив с объектами - трубами в заданном ряду и с нужным статусом (если статус задан).
    def GetTubesInRow(self, Row, state=None):
        Row_array = []
        for i in sorted(self.TubesByRow[Row].keys()):
            if state is None or self.TubesByRow[Row][i].state == state:
                Row_array.append(self.TubesByRow[Row][i])
        return Row_array        
    
    # Функция, возвращающая объект - трубу по номеру ряда и колонки
    def GetTube(self, row, col):
        try:
            return self.TubesByRow[row][col]
        except:
            return False
        
    # Функция, меняющая статус объекта - трубы по номеру ряда и колонки
    def SetTube(self, row, col, state, fill_color):
        try:
            self.TubesByRow[row][col].state = state
            self.TubesByRow[row][col].fill_color = fill_color
        except:
            return False
            
    # Функция для печати массива TubesByRow (отладка)   
    def PrintTubesByRow(self):
        for i in sorted(self.TubesByRow.keys()):
            Row_data = []
            for k in sorted(self.TubesByRow[i].keys()):
                Row_data.append([self.TubesByRow[i][k].col, self.TubesByRow[i][k].state, self.TubesByRow[i][k].connections])
            print (i, Row_data)
    
    # Функция выключающая определенный ряд труб
    def TurnOffRow(self, row):
        for i in self.GetTubesInRow(row):
            if i.row == row:
                if i.state == 1:
                    i.state = 4
                
    # Функция включающая определенный ряд труб
    def TurnOnRow(self, row):
        for i in self.GetTubesInRow(row):
            if i.row == row:
                if i.state == 4:
                    i.state = 1
    ##################################        
        
            
    ################# ФУНКЦИИИ ДЛЯ РАСЧЕТА СРЕНДЕВЗВЕШЕННОЙ СКОРОСТИ ######################
    
    # Функция группировки рядов
    def GroupRows(self):
        self.GrouppedRows = {}
        if self.PatternCharacter == 'Треугольники' or self.PatternCharacter == 'Коридорные квадраты':
            for i in self.TubesByRow.keys():
                if len(self.GetTubesInRow(i, 1)) > 0:
                    self.GrouppedRows[i] = {}
                    for k in self.TubesByRow[i].keys():
                        if self.TubesByRow[i][k].state == 1:
                            self.GrouppedRows[i][self.TubesByRow[i][k].col] = self.TubesByRow[i][k]
                            self.TubesByRow[i][k].fill_color = 'orange'
        
        if self.PatternCharacter == 'Повернутые треугольники' or self.PatternCharacter == 'Квадраты':
            i = min(self.TubesByRow.keys())
            while i<=max(self.TubesByRow.keys()):
                if len(self.GetTubesInRow(i, 1)) > 0:
                    self.GrouppedRows[i] = {}
                    for k in self.GetTubesInRow(i):
                        if k.state == 1:
                            self.GrouppedRows[i][k.col] = k
                            k.position = 'up'
                            k.fill_color = 'orange'
                    if i+1 in self.TubesByRow.keys():
                        for k in self.GetTubesInRow(i+1):
                            if k.state == 1:
                                self.GrouppedRows[i][k.col] = k
                                k.position = 'down'
                                k.fill_color = 'pink'
                    i += 2                        
                else:
                    i += 1
    
              
    
    # Поиск трубы по координате Х и номеру ряда
    def FindTubeYByX(self, Row, X):
        for i in self.GrouppedRows[Row].keys():
            if self.GrouppedRows[Row][i].x == X:
                return self.GrouppedRows[Row][i]
    
    # Строим сетку с координатами всех включенных труб
    def BuildXGrid(self):
        x_grid = {}
        
        # Проверяем на наличие VDS
        self.VDS = False
        if len(self.DShell_array) > 0:
            if self.DShell_array[0].Angle == 90:
                self.VDS = True
        
        #print('GrouppedRows', self.GrouppedRows)
        for row in sorted(self.GrouppedRows.keys()):
            x_grid[row] = []
            for col in sorted(self.GrouppedRows[row].keys()):
                Tube = self.GrouppedRows[row][col]
                x_grid[row].append(Tube.x)
        
        for row in x_grid.keys():
            for i in range(len(x_grid[row])):
                x = x_grid[row][i]
                
                if i == 0 or i == len(x_grid[row])-1:
                    Tube = self.FindTubeYByX(row, x_grid[row][i])
                    x_D = self.GetPerpendicularD(Tube)[0]
                    y_D = self.GetPerpendicularD(Tube)[1]
                    Tube.connections['D'].append({'x': x_D, 'y': y_D, 'l': ((Tube.x - x_D)**2+(Tube.y - y_D)**2)**0.5 - self.d/2})
                    # Если труба одна в ряду, то перпендикуляр к окружности D не строим, а проводим 2 горизонтальных линии:
                    # вправо и влево к окружности.
                    if len(x_grid[row]) == 1:
                    #if round(Tube.x, 2) == round(x_D, 2):
                        Tube.connections['D'].pop()
                        if Tube.x == min(x_grid[row]):
                            Tube.connections['D'].append({'x': (-1)*((self.D_in/2)**2 - Tube.y**2)**0.5, 'y': Tube.y, 'l': abs((-1)*((self.D_in/2)**2 - Tube.y**2)**0.5 - Tube.x) - self.d/2})
                        if Tube.x == max(x_grid[row]):
                            Tube.connections['D'].append({'x': ((self.D_in/2)**2 - Tube.y**2)**0.5, 'y': Tube.y, 'l': abs(((self.D_in/2)**2 - Tube.y**2)**0.5 - Tube.x) - self.d/2})
                
                if (i<len(x_grid[row])-1):
                    x1 = x_grid[row][i+1]
                    Tube = self.FindTubeYByX(row, x)
                    Tube1 = self.FindTubeYByX(row, x1)
                    
                    # Что между трубами?
                    DisplacementPipeBetweenTubes = False
                    for k in self.TubesByRow[Tube.row].keys():
                        if self.TubesByRow[Tube.row][k].state == 2 and Tube.x < self.TubesByRow[Tube.row][k].x < Tube1.x:
                            DisplacementPipeBetweenTubes = True
                    if DisplacementPipeBetweenTubes:
                        self.ConnectToDisplacementPipe(Tube)
                        self.ConnectToDisplacementPipe(Tube1)
                        continue
                    
                    # Есть ли VDS между трубами?
                    if self.VDS and Tube.x < 0 < Tube1.x:
                        self.ConnectToVDS(Tube)
                        self.ConnectToVDS(Tube1)
                        continue
                            
                    if self.FindDisplacementPipe(Tube, row, self.delta_row, self.delta_col) and x>0:
                        self.ConnectToDisplacementPipe(Tube)
                    
                    if self.FindDisplacementPipe(Tube, row, self.delta_row, self.delta_col) == False or x>0:
                        Tube.connections['NextTube']['x'] = x1
                        Tube.connections['NextTube']['y'] = Tube1.y
                        Tube.connections['NextTube']['l'] = ((Tube.x - Tube1.x)**2+(Tube.y - Tube1.y)**2)**0.5 - self.d
                    else:
                        self.ConnectToDisplacementPipe(Tube)       
                
    def FindDisplacementPipe(self, Tube, row, delta_row, delta_col, exeptions = []):
        for d_r in range(-delta_row, delta_row+1):
            for d_c in range(-delta_col, delta_col+1):
                Tube_check = self.CheckPipeState(Tube, d_r, d_c, [2])
                for i in self.GrouppedRows[row].keys():
                    if Tube_check and Tube.col < i < Tube_check.col:
                        return False
                if Tube_check and (Tube_check.row == row or Tube_check.row == row+1):
                    return True
                Tube_check = self.CheckPipeState(Tube, d_r, d_c, [3])
                if Tube_check and (Tube_check.row == row or Tube_check.row == row+1) and str(Tube_check.row)+':'+str(Tube_check.col) not in exeptions:
                    pass
        return False
    
    # Проверка статуса трубы
    def CheckPipeState(self, Tube, delta_row, delta_col, state):
        if self.Displacement_pipe != None:
            if self.GetTube(Tube.row+delta_row, Tube.col+delta_col):
                Tube_check = self.TubesByRow[Tube.row+delta_row][Tube.col+delta_col]
                #print(Tube_check.state, state)
                if Tube_check.state in state:
                    if abs(Tube.y) < (self.Displacement_pipe+self.d)/2:
                        return Tube_check
        return False
    
    # Перпендикуляр к вытеснительной трубе
    def ConnectToDisplacementPipe(self, Tube):
        x = Tube.x*self.Displacement_pipe/2/(Tube.x**2+Tube.y**2)**0.5
        y = Tube.y*self.Displacement_pipe/2/(Tube.x**2+Tube.y**2)**0.5
        Tube.connections['Displacement_pipe']['x'] = x
        Tube.connections['Displacement_pipe']['y'] = y
        Tube.connections['Displacement_pipe']['l'] = ((Tube.x - x)**2+(Tube.y - y)**2)**0.5 - self.d/2
        
    # Перпендикуляр к VDS
    def ConnectToVDS(self, Tube):
        Th = self.DShell_array[0].Thikness
        Dc = self.DShell_array[0].Design_clearance
        if Tube.x < 0:
            x = -Th/2 - Dc
            l = Tube.x - x + self.d/2
        else:
            x = Th/2 + Dc
            l = Tube.x - x - self.d/2
        y = Tube.y
        Tube.connections['VDS']['x'] = x
        Tube.connections['VDS']['y'] = y
        Tube.connections['VDS']['l'] = l
    
    def GetPerpendicularD(self, Tube):
        if Tube.x == 0 and Tube.y == 0:
            x_D = self.D_in/2
            y_D = self.D_in/2
        else:
            x_D = self.D_in/2*Tube.x/(Tube.x**2+Tube.y**2)**0.5
            y_D = self.D_in/2*Tube.y/(Tube.x**2+Tube.y**2)**0.5
        return [x_D, y_D]
        
    # Расчет средневзвешенной скорости в проеме межтрубного пространства    
    def CalcSpeed(self, h, V):
        # Формируем массив скоростей по рядам (сверху вниз либо от самого минимального по номеру до самого максимального)
        v_i_array = []
        for row in sorted(self.GrouppedRows.keys()):
            # Вводим переменную - длина зазоров в ряду
            L = 0
            # Идем по колонкам в ряду и складываем все имеющиеся зазоры (с соседними трубами, с вытеснительной трубой и внутренним диаметром)
            for col in sorted(self.GrouppedRows[row].keys()):
                Tube = self.GrouppedRows[row][col]
                
                if self.VDS and Tube.x > 0:
                    for i in Tube.connections['D']:
                        L += i['l']
                    if 'l' in Tube.connections['NextTube'].keys():
                        L += Tube.connections['NextTube']['l']
                    if 'l' in Tube.connections['VDS'].keys():
                        L += Tube.connections['VDS']['l']
                if not self.VDS:
                    for i in Tube.connections['D']:
                        L += i['l']
                    if 'l' in Tube.connections['Displacement_pipe'].keys():
                        L += Tube.connections['Displacement_pipe']['l']
                    if 'l' in Tube.connections['NextTube'].keys():
                        L += Tube.connections['NextTube']['l']                   

            #print(row, L)
            
            # Скорость в ряду    
            v_i = V/3600/(L*h/1000000)
            v_i_array.append(v_i*len(self.GrouppedRows[row].keys()))
            
            # Средневзвешенная скорость в проеме
            self.v_mid = sum(v_i_array)/self.N_on_sum
            #print(row, round(v_i, 3))
        
        # Визуализация значений скорости по рядам через градиентное окрашивание труб
        if self.ShowSpeeds:
            i = 0
            max_speed = max(v_i_array)
            min_speed = min(v_i_array)
            for row in self.GrouppedRows.keys():
                row_speed = v_i_array[i]
                color = abs(int((255/(max_speed-min_speed))*row_speed))
                if color > 255:
                    color = 255
                for col in sorted(self.GrouppedRows[row].keys()):
                    Tube = self.GrouppedRows[row][col]
                    Tube.color = '#' + '%02x%02x%02x' % (color,0,255-color)
                    Tube.fill_color = '#' + '%02x%02x%02x' % (color,0,255-color)
                i += 1
                    
        return v_i_array
    
############################ ВЫСТАВЛЕНИЕ ПЕРЕГОРОДОК ###################################################
    
    def CalcTubesBetweenHorizontal(self, Y_up, Y_down):
        N = 0
        for i in sorted(self.TubesByRow.keys()):
            col = list(sorted(self.TubesByRow[i].keys()))[0]
            Yi = self.TubesByRow[i][col].y
            if round(Y_up, 3)<round(Yi, 3)<round(Y_down, 3):
                N += len(self.GetTubesInRow(i, 1))
        return N
    
    def CalcTubesBetweenBufflesHorizontal(self):
        Y_prev = (-1)*self.D_in/2
        N_passes = []
        for i in self.Buffles:
            Y_up = Y_prev
            Y_down = (i.BuffleType[1][1] + i.BuffleType[1][5]) / 2
            N = self.CalcTubesBetweenHorizontal(Y_up, Y_down)
            N_passes.append(N)
            Y_prev = Y_down
        if len(self.Buffles) > 0:
            N = self.CalcTubesBetweenHorizontal(Y_prev, self.D_in/2)
            N_passes.append(N)
        return N_passes
    
    # Идем сверху вниз по полной набивке в рамках D_min и набираем нужное количество труб в каждом ходу
    # Если при расстановке перегородок труб не хватило, переходим на следующий диаметр
    # Если труб хватило, но свободное пространство от труб распределилось неравномерно сверху и снизу,
    # сдвигаем всю разбивку на 1 ряд вниз, оставляя "выключенным" ряд вверху, снова набираем трубы в ходу,
    # расставляем перегородки и анализируем свободное пространство сверху и снизу.
    
    # Функция, ставящая горизонтальную перегородку снизу после того, как количество труб стало >= нужному количеству
    # Последним аргументом в нее посылается координата Y, от которой нужно идти сверху вниз и набирать трубы
    
    #Определяет место перегородки, набирая трубки сверху вниз от начала игрик-координаты Y_up. А также прижимает перегородку к нижнему ряду.
    def SetBuffleHorizontal(self, Y_up, N_tubes_in_pass, Thikness, DS):
        Row_array = []
        N_tubes_in_pass_real = 0
        count = 0
        #print('Y_up', Y_up)
        #print(sorted(self.TubesByRow.keys()))
        
        for row in sorted(self.TubesByRow.keys()):
            col = list(sorted(self.TubesByRow[row].keys()))[0]
            if round(self.TubesByRow[row][col].y, 1) >= round(Y_up, 1):
                #print('Координата', self.TubesByRow[row][col].y)
                count = count + 1
                #print(self.TubesByRow[row][col].y, Y_up)
                if N_tubes_in_pass_real < N_tubes_in_pass:
                    Y = self.TubesByRow[row][col].y
                    Row_array.append(row)
                    N_tubes_in_pass_real = N_tubes_in_pass_real + len(self.GetTubesInRow(row, 1))
                    
                    # Проверка на продольную перегородку в межтрубном
                    if DS == True:
                        DS_arg = -1
                    else:
                        DS_arg = sorted(self.TubesByRow.keys())[-1]
                    #print('row', row, 'N_tubes_in_pass_real', N_tubes_in_pass_real)
                    if row >= DS_arg and N_tubes_in_pass_real < N_tubes_in_pass: ############################################
                    #if row == sorted(self.TubesByRow.keys())[-1] and N_tubes_in_pass_real < N_tubes_in_pass:
                        return 'Перейти на новый диаметр'
                else:
                    break
        if count == 0:
            return 'Перейти на новый диаметр'
        else:
            Y_buffle = Y + (Thikness/2 + self.Design_clearance + self.d/2)
            if Y_buffle < 0:
                #print('Attention')
                for row in sorted(self.TubesByRow.keys()):
                    col = list(sorted(self.TubesByRow[row].keys()))[0]
                    if self.TubesByRow[row][col].y > Y + Thikness + 2*self.Design_clearance + self.d:
                        Y_buffle = self.TubesByRow[row][col].y - (Thikness/2 + self.Design_clearance + self.d/2)
                        break
        return [Y_buffle, N_tubes_in_pass_real, Row_array]
    
    #Определяет место перегородки, набирая трубки снизу вверх от начала игрик-координаты Y_up. А также прижимает перегородку к верхнему ряду. !!! При наличии ГОРИЗОНТАЛЬНОЙ продольной перегородки в межтрубном !!!
    def SetBuffleHorizontalDS(self, Y_up, N_tubes_in_pass, Thikness, DS):
        #print('Запуск')
        Row_array = []
        N_tubes_in_pass_real = 0
        count = 0
        #print('Y_up', Y_up)
        #print(sorted(self.TubesByRow.keys()))
        
        for row in list(reversed(sorted(self.TubesByRow.keys()))):
            col = list(sorted(self.TubesByRow[row].keys()))[0]
            if 0 <= round(self.TubesByRow[row][col].y, 1) <= round(Y_up, 1):
                #print('Координата', self.TubesByRow[row][col].y)
                count = count + 1
                #print(self.TubesByRow[row][col].y, Y_up)
                if N_tubes_in_pass_real < N_tubes_in_pass:
                    Y = self.TubesByRow[row][col].y
                    Row_array.append(row)
                    N_tubes_in_pass_real = N_tubes_in_pass_real + len(self.GetTubesInRow(row, 1))
                    
                    if row <= 1 and N_tubes_in_pass_real < N_tubes_in_pass: ############################################
                    #if row == sorted(self.TubesByRow.keys())[-1] and N_tubes_in_pass_real < N_tubes_in_pass:
                        return 'Перейти на новый диаметр'
                else:
                    break
        if count == 0:
            return 'Перейти на новый диаметр'
        else:
            for row in list(reversed(sorted(self.TubesByRow.keys()))):
                    col = list(sorted(self.TubesByRow[row].keys()))[0]
                    if self.TubesByRow[row][col].y < Y - (Thikness + 2*self.Design_clearance + self.d):
                        Y_buffle = self.TubesByRow[row][col].y + (Thikness/2 + self.Design_clearance + self.d/2)
                        break
        return [Y_buffle, N_tubes_in_pass_real, Row_array]
                
    #Вызывает функцю SetBuffleHorizontal, возвращая готовый массив координат горизонтальных перегородок. Один ход по межтрубному либо режим VDS - вертикальная продольная перегородка в межтрубном
    def SetAllBufflesHorizontal(self, N_tubes_in_pass, N_passes, Y_0, Thikness, v_buff, VDS):
        self.Buffles = []
        N_tubes_in_pass_real_array = []
        self.TubesByPass = []
        Full_row_array = []
        Off_rows_bottom_array = []
        Off_rows_top_array = []
        
        # Деление дольками
        if v_buff == True:
            Y_up_for_next_buffle = Y_0
            if N_passes%4 == 0:
                coeff = 1 #Коэффициент нужен для реализации режима "змейки" при нумерации ходов
            else:
                coeff = -1
            count = N_passes/2-1 #Счетчик нужен для режима VDS
            for buffle in range(N_passes):
                if buffle/2 != int(buffle/2):
                    coeff = coeff*(-1)
                    #print(coeff)
                    #print('Перегородка номер', buffle)
                    Result = self.SetBuffleHorizontal(Y_up_for_next_buffle, N_tubes_in_pass*2, Thikness, False)
                    if type(Result[0]) == str:
                        return 'Перейти на новый диаметр'
                    else:
                        Y_buffle = Result[0]
                        
                        if VDS == False:
                            N_tubes_in_pass_real_array.append(Result[1]/2)
                            self.TubesByPass.append([(N_passes-buffle), Result[1]/2, [coeff*(-self.D/4), (Y_up_for_next_buffle+Y_buffle)/2]]) #Массив из [номеров ходов, количества труб, [координат центра]]
                            N_tubes_in_pass_real_array.append(Result[1]/2)
                            self.TubesByPass.append([(N_passes-buffle+1), Result[1]/2, [coeff*self.D/4, (Y_up_for_next_buffle+Y_buffle)/2]]) #Массив из [номеров ходов, количества труб, [координат центра]]
                        else:
                            N_tubes_in_pass_real_array.append(Result[1]/2)
                            self.TubesByPass.append([(N_passes/2-count), Result[1]/2, [-self.D/4, (Y_up_for_next_buffle+Y_buffle)/2]]) #Массив из [номеров ходов, количества труб, [координат центра]]
                            N_tubes_in_pass_real_array.append(Result[1]/2)
                            self.TubesByPass.append([(N_passes/2+count+1), Result[1]/2, [self.D/4, (Y_up_for_next_buffle+Y_buffle)/2]]) #Массив из [номеров ходов, количества труб, [координат центра]]
                            count = count-1
                        Full_row_array.append(Result[2])
                        Full_row_array.append(Result[2])
                        #print(Y_buffle)
                        Y_up_for_next_buffle = Y_buffle + (Thikness/2 + self.Design_clearance + self.d/2)
                        
                        if buffle != N_passes-1:
                            Buffle1 = Buffle(0, Y_buffle, 0, self.D, self.Design_clearance)
                            self.Buffles.append(Buffle1)
                        else:
                            Y_bottom = Y_buffle - (Thikness/2 + self.Design_clearance + self.d/2)
                            #print(Y_bottom)

                            for row in sorted(self.TubesByRow.keys()):
                                col = list(sorted(self.TubesByRow[row].keys()))[0]
                                if round(self.TubesByRow[row][col].y, 6) > round(Y_bottom, 6):
                                    #print('row: ', row,'y: ', self.TubesByRow[row][col].y)
                                    self.TurnOffRow(row)
                                    Off_rows_bottom_array.append(row)
                                    #print(self.TubesByRow[row][col].state)
                                if self.TubesByRow[row][col].y < Y_0:
                                    self.TurnOffRow(row)
                                    Off_rows_top_array.append(row)
                                    
            return [self.Buffles, N_tubes_in_pass_real_array, Full_row_array, list(sorted(self.TubesByPass)), Off_rows_bottom_array, Off_rows_top_array]
        
        # Деление слоями
        # Одноходовой
        else:
            if N_passes == 1:
                N_tubes_in_pass_real_array.append(self.N_on_sum)
                Full_row_array = sorted(self.TubesByRow.keys())
                A = list(self.TubesByRow.keys())
                while N_tubes_in_pass_real_array[0] >= N_tubes_in_pass:
                    for row in list(reversed(A)):
                        col = list(sorted(self.TubesByRow[row].keys()))[0]

                        if self.TubesByRow[row][col].state == 1:
                            N_tubes_in_pass_real_array[0] = N_tubes_in_pass_real_array[0] - len(self.GetTubesInRow(row, 1))

                            self.TurnOffRow(row)
                            if row > 0:
                                Off_rows_bottom_array.append(row)
                            else:
                                Off_rows_top_array.append(row)

                            break

                #print(Off_rows_top_array, row)    
                self.TurnOnRow(row)
                if row > 0:
                    Off_rows_bottom_array.pop(-1)

                else:
                    Off_rows_top_array.pop(-1)

                N_tubes_in_pass_real_array[0] = N_tubes_in_pass_real_array[0] + len(self.GetTubesInRow(row, 1))
                #N_tubes_in_pass_real_array.append('delta')
                return [self.Buffles, N_tubes_in_pass_real_array, Full_row_array, list(sorted(self.TubesByPass)), Off_rows_bottom_array, Off_rows_top_array]
            
            # Многоходовой
            Y_up_for_next_buffle = Y_0
            #print(N_passes)
            for buffle in range(N_passes): ##################################################
                #print('Перегородка номер', buffle)
                Result = self.SetBuffleHorizontal(Y_up_for_next_buffle, N_tubes_in_pass, Thikness, False)
                if type(Result[0]) == str:
                    return 'Перейти на новый диаметр'
                else:
                    N_tubes_in_pass_real_array.append(Result[1])
                    Y_buffle = Result[0]
                    self.TubesByPass.append([(N_passes-buffle), Result[1], [0, (Y_up_for_next_buffle+Y_buffle)/2]]) #Массив из [номеров ходов, количества труб, [координат центра]]
                    Full_row_array.append(Result[2])
                    #print(Y_buffle)
                    Y_up_for_next_buffle = Y_buffle + (Thikness/2 + self.Design_clearance + self.d/2)
                    #print(Y_up_for_next_buffle)
                    if buffle != N_passes-1: #######################################
                        Buffle1 = Buffle(0, Y_buffle, 0, self.D, self.Design_clearance)
                        self.Buffles.append(Buffle1)
                    else:
                        Y_bottom = Y_buffle - (Thikness/2 + self.Design_clearance + self.d/2)
                        #print('Y_bottom', Y_bottom)
                        

                        for row in sorted(self.TubesByRow.keys()):
                            col = list(sorted(self.TubesByRow[row].keys()))[0]
                            if round(self.TubesByRow[row][col].y, 3) > round(Y_bottom, 3): ##############################################
                                #print('row: ', row,'y: ', self.TubesByRow[row][col].y)
                                self.TurnOffRow(row)
                                Off_rows_bottom_array.append(row)
                                #print(self.TubesByRow[row][col].state)
                            if self.TubesByRow[row][col].y < Y_0:
                                self.TurnOffRow(row)
                                Off_rows_top_array.append(row)
            #print('Количество труб в ходах: ', N_tubes_in_pass_real_array,'все ряды: ', Full_row_array)
            #print('Выключены трубы снизу: ', Off_rows_bottom_array,'Выключены трубы сверху: ', Off_rows_top_array) 
            return [self.Buffles, N_tubes_in_pass_real_array, Full_row_array, list(sorted(self.TubesByPass)), Off_rows_bottom_array, Off_rows_top_array]
    
    #Нужна для режима DS - горизонтальная продольная перегородка в межтрубном. Вызывает функции SetBuffleHorizontal и SetBuffleHorizontalDS, возвращая массив с координатами горизонтальных перегородок
    def SetAllBufflesHorizontalDS(self, N_tubes_in_pass, N_passes, Y_0, Thikness, v_buff): # С продольной перегородкой
        self.Buffles = []
        N_tubes_in_pass_real_array = []
        self.TubesByPass = []
        Full_row_array = []
        Off_rows_bottom_array = []
        Off_rows_top_array = []
        
        # Деление дольками
        if v_buff == True:
            Y_up_for_next_buffle = Y_0
            if N_passes%4 == 0:
                coeff = 1 #Коэффициент нужен для реализации режима "змейки" при нумерации ходов
            else:
                coeff = -1
            for buffle in range(int(N_passes/2)): #########################################
                if buffle/2 != int(buffle/2):
                    coeff = coeff*(-1)
                    #print('Перегородка номер', buffle)
                    Result = self.SetBuffleHorizontal(Y_up_for_next_buffle, N_tubes_in_pass*2, Thikness, True) #Верхняя часть аппарата
                    Result1 = self.SetBuffleHorizontalDS(-Y_up_for_next_buffle, N_tubes_in_pass*2, Thikness, True) #Нижняя часть аппарата
                    if type(Result[0]) == str:
                        return 'Перейти на новый диаметр'
                    else:
                        Y_buffle = Result[0] #Верхняя часть аппарата
                        Y_buffle1 = Result1[0] #Нижняя часть аппарата
                        
                        N_tubes_in_pass_real_array.append(Result[1]/2)
                        self.TubesByPass.append([(N_passes-buffle), Result[1]/2, [coeff*(-self.D/4), (Y_up_for_next_buffle+Y_buffle)/2]]) #Массив из [номеров ходов, количества труб, [координат центра]]
                        N_tubes_in_pass_real_array.append(Result[1]/2)
                        self.TubesByPass.append([(N_passes-buffle+1), Result[1]/2, [coeff*self.D/4, (Y_up_for_next_buffle+Y_buffle)/2]]) #Массив из [номеров ходов, количества труб, [координат центра]]
                        N_tubes_in_pass_real_array.append(Result1[1]/2)
                        self.TubesByPass.append([(buffle+1), Result1[1]/2, [coeff*(-self.D/4), self.d+(-Y_up_for_next_buffle+Y_buffle1)/2]]) #Массив из [номеров ходов, количества труб, [координат центра]]
                        N_tubes_in_pass_real_array.append(Result1[1]/2)
                        self.TubesByPass.append([(buffle), Result1[1]/2, [coeff*self.D/4, self.d+(-Y_up_for_next_buffle+Y_buffle1)/2]]) #Массив из [номеров ходов, количества труб, [координат центра]]
                        Full_row_array.append(Result[2])
                        Full_row_array.append(Result[2])
                        Full_row_array.append(Result1[2])
                        Full_row_array.append(Result1[2])
                        
                        #print(Y_buffle)
                        Y_up_for_next_buffle = Y_buffle + (Thikness/2 + self.Design_clearance + self.d/2)
                        
                        if buffle != int(N_passes/2)-1: ############################################
                            Buffle1 = Buffle(0, Y_buffle, 0, self.D, self.Design_clearance)
                            self.Buffles.append(Buffle1)
                            Buffle2 = Buffle(0, Y_buffle1, 0, self.D, self.Design_clearance)
                            self.Buffles.append(Buffle2)
                        else:
                            Buffle0 = Buffle(0, 0, 0, self.D, self.Design_clearance) ##################################
                            self.Buffles.append(Buffle0) #####################################################
                            Y_bottom = Y_buffle - (Thikness/2 + self.Design_clearance + self.d/2)
                            #print(Y_bottom)

                            for row in sorted(self.TubesByRow.keys()):
                                col = list(sorted(self.TubesByRow[row].keys()))[0]
                                if 0 >= round(self.TubesByRow[row][col].y, 6) > round(Y_bottom, 6): ####################################
                                    #print('row: ', row,'y: ', self.TubesByRow[row][col].y)
                                    self.TurnOffRow(row)
                                    Off_rows_bottom_array.append(row)
                                    #print(self.TubesByRow[row][col].state)
                                if self.TubesByRow[row][col].y < Y_0:
                                    self.TurnOffRow(row)
                                    Off_rows_top_array.append(row)
                    
            return [self.Buffles, N_tubes_in_pass_real_array, Full_row_array, list(sorted(self.TubesByPass)), Off_rows_bottom_array, Off_rows_top_array]
        
        # Деление слоями
        else:
        # Многоходовой
            Y_up_for_next_buffle = Y_0 #Выше продольной перегородки
            Y_up_for_next_buffle1 = -Y_0 #Ниже продольной перегородки
            #print(N_passes)
            for buffle in range(int(N_passes/2)): ##################################################
                #print('Перегородка номер', buffle)
                Result = self.SetBuffleHorizontal(Y_up_for_next_buffle, N_tubes_in_pass, Thikness, True) #Верхняя часть аппарата
                Result1 = self.SetBuffleHorizontalDS(Y_up_for_next_buffle1, N_tubes_in_pass, Thikness, True) #Нижняя часть аппарата
                if type(Result[0]) == str or type(Result1[0]) == str:
                    return 'Перейти на новый диаметр'
                else:
                    Y_buffle = Result[0] #Верхняя часть аппарата
                    Y_buffle1 = Result1[0] #Нижняя часть аппарата
                    N_tubes_in_pass_real_array.append(Result[1])
                    self.TubesByPass.append([(N_passes-buffle), Result[1], [0, (Y_up_for_next_buffle+Y_buffle)/2]]) #Массив из [номеров ходов, количества труб, [координат центра]]
                    N_tubes_in_pass_real_array.append(Result1[1])
                    self.TubesByPass.append([(buffle+1), Result1[1], [0, self.d+(Y_up_for_next_buffle1+Y_buffle1)/2]]) #Массив из [номеров ходов, количества труб, [координат центра]]
                    Full_row_array.append(Result[2])
                    Full_row_array.append(Result1[2]) # Добавляем ряды в нижней части окружности
                    
                    #print('Y_up_for_next_buffle, Y_buffle, Y_up_for_next_buffle1, Y_buffle1', Y_up_for_next_buffle, Y_buffle, Y_up_for_next_buffle1, Y_buffle1)
                    
                    #print('Y_buffle', Y_buffle)
                    #print('Y_buffle1', Y_buffle1)
                    Y_up_for_next_buffle = Y_buffle + (Thikness/2 + self.Design_clearance + self.d/2)
                    #print('Y_up_for_next_buffle', Y_up_for_next_buffle)
                    Y_up_for_next_buffle1 = Y_buffle1 - (Thikness/2 + self.Design_clearance + self.d/2)
                    #print('Y_up_for_next_buffle1', Y_up_for_next_buffle1)
                    if buffle != int(N_passes/2)-1: #######################################
                        Buffle1 = Buffle(0, Y_buffle, 0, self.D, self.Design_clearance)
                        self.Buffles.append(Buffle1)
                        Buffle2 = Buffle(0, Y_buffle1, 0, self.D, self.Design_clearance)
                        self.Buffles.append(Buffle2)
                    else:
                        Buffle0 = Buffle(0, 0, 0, self.D, self.Design_clearance) ##################################
                        self.Buffles.append(Buffle0) #####################################################
                        Y_bottom = Y_buffle - (Thikness/2 + self.Design_clearance + self.d/2)
                        #print(Y_bottom)

                        for row in sorted(self.TubesByRow.keys()):
                            col = list(sorted(self.TubesByRow[row].keys()))[0]
                            if 0 >= round(self.TubesByRow[row][col].y, 6) > round(Y_bottom, 6): ##############################################
                                #print('row: ', row,'y: ', self.TubesByRow[row][col].y)
                                self.TurnOffRow(row)
                                Off_rows_bottom_array.append(row)
                                #print(self.TubesByRow[row][col].state)
                            if self.TubesByRow[row][col].y < Y_0:
                                self.TurnOffRow(row)
                                Off_rows_top_array.append(row)
            #print('Количество труб в ходах: ', N_tubes_in_pass_real_array,'все ряды: ', Full_row_array)
            #print('Выключены трубы снизу: ', Off_rows_bottom_array,'Выключены трубы сверху: ', Off_rows_top_array)
                    
            return [self.Buffles, N_tubes_in_pass_real_array, Full_row_array, list(sorted(self.TubesByPass)), Off_rows_bottom_array, Off_rows_top_array]
    
    def GetY0(self):
        row = sorted(self.TubesByRow.keys())[0]
        col = list(sorted(self.TubesByRow[row].keys()))[0]
        Y_0 = self.TubesByRow[row][col].y - self.d/2
        return Y_0
    
    def FinishUpTopArray(self, Off_rows_top_array, N_tubes_in_pass):
        Row_array = []
        Row_array1 = []
        N_tubes_in_pass_real = 0
        for row in sorted(self.TubesByRow.keys()):
            if row < 0:
                Row_array.append(row)
        count = 0
        while len(Off_rows_top_array) > 2:
            count = count + 1
            Off_rows_top_array.pop(-1)
            
            for i in Row_array:
                if not (i in Off_rows_top_array):
                    Row_array1.append(i)
                    
            while N_tubes_in_pass_real < N_tubes_in_pass:
                for k in Row_array1:
                    N_tubes_in_pass_real = N_tubes_in_pass_real + len(self.GetTubesInRow(k))
                Row_array1.append(Off_rows_top_array[-1])
                Off_rows_top_array.pop(-1)
        for l in range(count):
            Off_rows_top_array.append(Row_array[-(l+1)])
        return Off_rows_top_array
    
    def LetsGiveTatianaWhatSheWants(self, Off_rows_bottom_array, Off_rows_top_array):
        result = []

        #if len(Off_rows_bottom_array) >= len(Off_rows_top_array):
        #    coef = 1
        #else:
        #    coef = -1
            
        coef = [1, -1]
            
        for k in coef:
            #print('k', k)
            Row_array = []
            N_tubes_real = 0
            res = [] # Массив для верхней и нижней половинки отдельно
            for row in sorted(self.TubesByRow.keys()):
                #print('row', row)
                N_tubes_real = N_tubes_real + len(self.GetTubesInRow(row, 1))
                if len(self.GetTubesInRow(row, 1)) > 0:
                    Row_array.append(row)
                
                if row not in Off_rows_bottom_array and row not in Off_rows_top_array:
                    col = list(sorted(self.TubesByRow[row].keys()))[0]
                    Y = round(self.TubesByRow[row][col].y, 1) - k*(self.d/2 + 5)
                    #print(round(self.TubesByRow[row][col].y, 1), -k, (self.d/2 + 5), Y)

                    if k*Y <= 0:
                        #print(Y, (abs(Y)/(self.D_in/2)))
                        angle_alpha = math.acos(abs(Y)/(self.D_in/2))*2*180/pi
                        N_rows_cross = 0
                        N_long = 0
                        for i in sorted(self.TubesByRow.keys()):
                            icol = list(sorted(self.TubesByRow[i].keys()))[0]
                            if k == 1:
                                if round(self.TubesByRow[i][icol].y, 1) >= Y:
                                    if len(self.GetTubesInRow(i, 1)) > 0:
                                        N_rows_cross = N_rows_cross + 1 #len(self.GetTubesInRow(i, 1))
                                else:
                                    N_long = N_long + len(self.GetTubesInRow(i, 1))
                            else:
                                if round(self.TubesByRow[i][icol].y, 1) <= Y:
                                    if len(self.GetTubesInRow(i, 1)) > 0:
                                        N_rows_cross = N_rows_cross + 1 #len(self.GetTubesInRow(i, 1))
                                else:
                                    N_long = N_long + len(self.GetTubesInRow(i, 1))
                        res.append([angle_alpha, N_rows_cross, N_long])

            if k == -1:
                res = list(reversed(res))

            result.append(res)
        
        resultS = copy.deepcopy(result[1])
        result0 = copy.deepcopy(result[0])
        result1 = copy.deepcopy(result[1])
        for l in range(len(result1)):
            for m in range(len(result0)):
                if result1[l][0] == result0[m][0]:
                    if result1[l][-1] < result0[m][-1]:
                        resultS[l] = result0[m]
        
        gen_res = [self.D_in, N_tubes_real, len(Row_array), resultS]
        return gen_res
    
    def ShellEntrance(self, VolumeFlow, plate, S_plate, entrance_baffle_spacing, h1, h2, F2, K):
        if ((self.D_in - self.OTL) / 2) > ((h1 + h2) / 2):
            h = (self.D_in - self.OTL) / 2
        else:
            h = (h1 + h2) / 2

        if plate == False:
            plate_k = 1
        else:
            plate_k = 0

        As = ((3.14159 * self.DNozzle * h) + (plate_k * 0.785 * self.DNozzle * self.DNozzle * (self.step - self.d) / F2 / self.step)) / 1000000
        Vs = VolumeFlow / As

        if self.DNozzle > K:
            k = self.DNozzle
        else:
            k = K

        Ab = (entrance_baffle_spacing * (self.D_in - self.OTL) + (entrance_baffle_spacing * (k - self.d) - S_plate) * (self.step - self.d) / F2 / self.step) / 1000000
        Vb = VolumeFlow / Ab

        return [Vs, Vb]
    
    def GetH(self, VDS):
        if VDS == False:
            for row in sorted(self.TubesByRow.keys()):
                if len(self.GetTubesInRow(row, 1)) > 0:
                    col = list(sorted(self.TubesByRow[row].keys()))[0]
                    Y = self.TubesByRow[row][col].y - self.d/2
                    break
            h1 = self.D/2 - abs(Y)
            h2 = ((self.D/2)**2 - (self.DNozzle/2)**2)**0.5 - abs(Y)
            K = ((self.OTL/2)**2 - Y**2)**0.5
        else:
            calc_rows = []
            flag = True
            for row in sorted(self.TubesByRow.keys()):
                if flag == True:
                    if len(self.GetTubesInRow(row, 1)) > 0:
                        for col in list(sorted(self.TubesByRow[row].keys())):
                            if self.TubesByRow[row][col].x + self.d/2 >= self.ShellNozzleXin2:
                                #print('Считаем ряд', row)
                                if row not in calc_rows:
                                    calc_rows.append(row)
                            if self.TubesByRow[row][col].x + self.d/2 >= self.ShellNozzleXin1:
                                #print('Закончили', row)
                                h1 = 10
                                h2 = 15
                                K = 30
                                flag = False
                                break
                else:
                    break
            print('calc_rows', calc_rows)
        return [h1, h2, K]
                
    def PlaceNozzles(self, NShellBuffles, VDS):
        if VDS == True:
            self.ShellNozzleXin1 = self.D/4+self.DNozzle/2
            self.ShellNozzleXin2 = self.D/4-self.DNozzle/2
            self.ShellNozzleYin11 = -((self.D/2)**2-(self.ShellNozzleXin1)**2)**0.5
            self.ShellNozzleYin21 = -((self.D/2)**2-(self.ShellNozzleXin2)**2)**0.5
            self.ShellNozzleYin12 = self.ShellNozzleYin21-self.D/10
            self.ShellNozzleYin22 = self.ShellNozzleYin21-self.D/10

            if NShellBuffles%2 == 0:
                self.ShellNozzleXout1 = -self.D/4-self.DNozzle/2
                self.ShellNozzleXout2 = -self.D/4+self.DNozzle/2
                self.ShellNozzleYout11 = -((self.D/2)**2-(self.ShellNozzleXout1)**2)**0.5
                self.ShellNozzleYout21 = -((self.D/2)**2-(self.ShellNozzleXout2)**2)**0.5
                self.ShellNozzleYout12 = self.ShellNozzleYout21-self.D/10
                self.ShellNozzleYout22 = self.ShellNozzleYout21-self.D/10
            else:
                self.ShellNozzleXout1 = -self.D/4-self.DNozzle/2
                self.ShellNozzleXout2 = -self.D/4+self.DNozzle/2
                self.ShellNozzleYout11 = ((self.D/2)**2-(self.ShellNozzleXout1)**2)**0.5
                self.ShellNozzleYout21 = ((self.D/2)**2-(self.ShellNozzleXout2)**2)**0.5
                self.ShellNozzleYout12 = self.ShellNozzleYout21+self.D/10
                self.ShellNozzleYout22 = self.ShellNozzleYout21+self.D/10
        
        elif NShellBuffles%2 == 0:
            self.ShellNozzleXout1 = 0-self.DNozzle/2
            self.ShellNozzleXout2 = 0+self.DNozzle/2
            self.ShellNozzleYout11 = -((self.D/2)**2-(self.ShellNozzleXout1)**2)**0.5
            self.ShellNozzleYout12 = self.ShellNozzleYout11-self.D/10
            self.ShellNozzleYout21 = -((self.D/2)**2-(self.ShellNozzleXout2)**2)**0.5
            self.ShellNozzleYout22 = self.ShellNozzleYout21-self.D/10