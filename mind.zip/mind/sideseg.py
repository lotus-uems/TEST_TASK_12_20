import math
from diameters import *

# Создаем класс для боковых сегментов
class SideSeg:
    def __init__(self, d, D, Design_clearance, Fraction):
        self.d = d # диаметр труб
        self.D = D # характерный диаметр аппарата
        self.D_in = Diameters[D][0] # Внутренний диаметр аппарата
        self.Design_clearance = Design_clearance # Зазор
        self.Fraction = Fraction # Доля выреза от радиуса аппарта
        self.Width = Fraction*D/2 # Ширина выреза в зависимости от диаметра аппарата
        
        # Конвертируем массив перегородок в массив с координатами отрезков и типами перегородок
        self.Get_SideSegType()
        
    def __repr__(self):
        return "<%s:%s>" %(self.Width)
    
    # Определяем координаты точек, по которым будут строиться линии, образующие "коридор"
    # пополняем этими данными массив SideSegsType
    def Get_SideSegType(self):
        SideSegType = []            
        
        x1 = -self.D/2
        x2 = -self.D/2*(1-self.Fraction)
        x3 = self.D/2*(1-self.Fraction)
        x4 = self.D/2

        Type = 'Боковые сегменты'
        SideSegType = [Type, [x1, x2, x3, x4]]

        self.SideSegType = SideSegType