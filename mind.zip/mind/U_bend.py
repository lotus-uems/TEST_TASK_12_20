import math
from diameters import *

# Создаем класс для U-образника
class U_bend:
    def __init__(self, Angle, d, D):
        self.Angle = Angle # угол поворота перегородки относительно оси x (горизонтальной оси аппарата)
        self.d = d # диаметр труб
        self.D = D # характерный диаметр аппарата
        self.D_in = Diameters[D][0] # Внутренний диаметр аппарата
        self.OTL_U= 2*self.d # Толщина "коридора" под U-образный гиб
        
        # Создаем массив с координатами отрезков для вытеснения труб и типом гиба (горизонтальный, вертикальный, радиальный)
        self.GetUType()
        
    def __repr__(self):
        return "<%s:%s>" %(self.Angle, self.OTL_U)
       
    # Определяем координаты точек, по которым будут строиться линии, образующие "коридор"
    # а также определяем тип гиба (горизонтальный, вертикальный, радиальный)
    # пополняем этими данными массив U_Types  
    def GetUType(self):
        U_Type = []            
        # рассчитываем переменные a, b, c, A, B, C, x1, x2, x3, x4, y1, y2, y3, y4 - промежуточные вычисления
        # для расчета координат X1, X2, X3, X4, Y1, Y2, Y3, Y4
        a = 0
        b = a - self.OTL_U/2
        c = a + self.OTL_U/2

        A = self.OTL_U/2
        B = ((self.D_in/2)**2-b**2)**(0.5)
        C = ((self.D_in/2)**2-c**2)**(0.5)

        # x1 и X1
        if self.Angle == 0:
            x1 = round((-1)*B, 10)
        if self.Angle == 90:
            x1 = round(self.OTL_U/2, 6)                    

        # x2 и X2
        if self.Angle == 0:
            x2 = (-1)*x1
        if self.Angle == 90:
            x2 = x1

        # x3 и X3
        if self.Angle == 0:
            x3 = round((-1)*C, 10)
        if self.Angle == 90:
            x3 = - round(self.OTL_U/2, 6)

        # x4 и X4
        if self.Angle == 0:
            x4 = (-1)*x3
        if self.Angle == 90:
            x4 = x3

        # y1 и Y1
        if self.Angle == 0:
            y1 = round((-1)*self.OTL_U/2, 10)
        if self.Angle == 90:
            y1 = round(B, 6)

        # y2 и Y2
        if self.Angle == 0:
            y2 = y1
        if self.Angle == 90:
            y2 = (-1)*y1

        # y3 и Y3
        if self.Angle == 0:
            y3 = round(self.OTL_U/2, 10)
        if self.Angle == 90:
            y3 = round(C, 6)
            

        # y4 и Y4
        if self.Angle == 0:
            y4 = y3
        elif self.Angle == 90:
            y4 = (-1)*y3
        else:
            y4 = (-1)*y1
        #Y4 = D/2 - y4

        if self.Angle == 0:
            Type = 'Горизонтальный гиб'
            U_Type = [Type, [x1, y1, x2, y2, x3, y3, x4, y4]]   

        if self.Angle == 90:
            Type = 'Вертикальный гиб'
            U_Type = [Type, [x1, y1, x2, y2, x3, y3, x4, y4]]  
            print('U_Type', U_Type)

        self.U_Type = U_Type
