import math
from diameters import *

# Создаем класс для вертикальной перегородки  
class V_Buffle:
    def __init__(self, d, D, Design_clearance):
        self.d = d # диаметр труб
        self.D = D # характерный диаметр аппарата
        self.D_in = Diameters[D][0] # Внутренний диаметр аппарата
        self.Design_clearance = Design_clearance
        self.Thikness = Diameters[D][2] # Толщина перегородки в зависимости от диаметра аппарата
        self.OTL_buffle = self.Thikness+2*Design_clearance # Толщина "коридора" под перегородку с учетом конструктивного зазора (5мм)
        
        # Конвертируем массив перегородок в массив с координатами отрезков и типами перегородок
        self.Get_V_BuffleType()
        
    def __repr__(self):
        return "<%s:%s>" %(self.Thikness)
    
    # Определяем координаты точек, по которым будут строиться линии, образующие "коридор"
    # пополняем этими данными массив U_Types  
    def Get_V_BuffleType(self):
        V_BuffleType = []            
        # рассчитываем переменные a, b, c, A, B, C, x1, x2, x3, x4, y1, y2, y3, y4 - промежуточные вычисления
        # для расчета координат X1, X2, X3, X4, Y1, Y2, Y3, Y4
        a = 0
        b = a - self.OTL_buffle/2
        c = a + self.OTL_buffle/2

        A = self.OTL_buffle/2
        B = ((self.D_in/2)**2-b**2)**(0.5)
        C = ((self.D_in/2)**2-c**2)**(0.5)

        # x1 и X1
        x1 = round(self.OTL_buffle/2, 6)

        # x2 и X2
        x2 = x1

        # x3 и X3
        x3 = - round(self.OTL_buffle/2, 6)

        # x4 и X4
        x4 = x3

        # y1 и Y1
        y1 = round(B, 6)

        # y2 и Y2
        y2 = (-1)*y1

        # y3 и Y3
        y3 = round(C, 6)

        # y4 и Y4
        y4 = (-1)*y3 

        Type = 'Вертикальный перегородка'
        V_BuffleType = [Type, [x1, y1, x2, y2, x3, y3, x4, y4]]  

        self.V_BuffleType = V_BuffleType
