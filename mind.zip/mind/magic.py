﻿import time

from tube_pattern import *
from diameters import *
from buffle import *
from U_bend import *
from vertical_buffle import *
from dshell import *
from minD import *
from DBaffle import *

import itertools

Floating_head_array = [False, True]

#U_bend_array = [[],[U_bend(0, TubePattern.d, TubePattern.D)]]
U_bend_array = [False, True]

ShellType_array = ['E', 'F']

N_tube_passes_array = [1,2,3,4,6,8,10,12,14,16,18,20]
      
PatternCharacter_array = ['Треугольники', 'Повернутые треугольники', 'Квадраты', 'Коридорные квадраты']
    
Fluoroplastic_Seal_array = [False, True]

# Формируем массив всех возможных комбинаций для обсчета
Grid_For_Oleg = [] 
count = 0
#print('Плав головка/' + 'U/' + 'Кожух/' + 'Количество ходов/' + 'Разбивка/' + 'Фторопластовое уплотнение')
#print()
for x in (itertools.product(Floating_head_array, U_bend_array, ShellType_array, N_tube_passes_array, PatternCharacter_array, Fluoroplastic_Seal_array)):
    if not (x[0] == x[1] == True): # Исключаем случаи, когда одновременно плавающая головка и у-образник
        if not ((x[2] == 'F' or x[1] == True) and x[3] % 2 !=0): # Невозможно сочетания корпус F или у-образника и нечетного количества ходов в трубном
            if not (x[2] == 'F' and x[3] > 4): # Пока не выведена поправка z для корпуса F и количества ходов всех, кроме 2 и 4
                Grid_For_Oleg.append(x)
                #print(x)
                count = count + 1

Sum = 0
D = 3200
d_arr = [10,12,16,20,25,32,38,57]
Design_clearance = 5
Displacement_pipe = None
VDS = False # Случай с VDS пока не рассматриваем
f = open("magic_data.txt", "w")

for d in d_arr:
    print('Start diameter:', d, ' | ', time.strftime("%H:%M:%S"))
    for i in Grid_For_Oleg:
        print('Start from Grid:', i, ' | ', time.strftime("%H:%M:%S"))
        U_bend_array = []
        V_Buffle_array = []
        DShell_array = []
        Buffles = []
        U_bend_array = []
        DS = False
        if i[1] == True:
            if i[2] == 'E':
                if i[3] == 2:
                    U_bend_array = [U_bend(0, d, D)]
                else:
                    U_bend_array = [U_bend(90, d, D)]
            if i[2] == 'F':
                U_bend_array = [U_bend(0, d, D)]
            
        if i[2] == 'F':
            DShell_array = [DShell(0, d, D, Design_clearance)] # Случай с VDS пока не рассматриваем
            DS = True
            
        PatternCharacter = i[4]
        if i[5]:
            a = 32
        else:
            if i[0]:
                a = 26
            else:
                a = 12
        Flag = False
        N_tubes_in_pass = 1
        while Flag == False:
            Res = Magic(PatternCharacter, d, i[3], N_tubes_in_pass, Displacement_pipe, i[5], i[0], i[1], DS, VDS, Design_clearance)
            if PatternCharacter == 'Треугольники':
                PC = 1
            if PatternCharacter == 'Повернутые треугольники':
                PC = 2
            if PatternCharacter == 'Квадраты':
                PC = 3
            if PatternCharacter == 'Коридорные квадраты':
                PC = 4
            if Displacement_pipe is None:
                DP = 0
            
            if Res == False:
                Flag = True
                print('End from Grid:', i, ' | ', time.strftime("%H:%M:%S"), Sum)
            else:
                f.write(str(PC) + ';' + str(d) + ';' + str(i[3]) + ';' + str(N_tubes_in_pass) + ';' + str(DP) + ';' + str(i[5]) + ';' + str(i[0]) + ';' + str(i[1]) + ';' + str(DS) + ';' + str(VDS) + ';' + str(Design_clearance) + ';' + str(Res[0]) + ',\n')
                N_tubes_in_pass += 1
                Sum += 1
    print('End diameter:', d, ' | ', time.strftime("%H:%M:%S"), Sum)

f.close()