import math
from diameters import *

# Создаем класс для перегородки    
class Buffle:
    def __init__(self, x, y, Angle, D, Design_clearance):
        self.x = x # координата x центра перегородки
        self.y = y # координата y центра перегородки
        self.Angle = Angle # угол поворота перегородки относительно оси x (горизонтальной оси аппарата)
        self.D_in = Diameters[D][0] # Внутренний диаметр аппарата
        self.Design_clearance = Design_clearance
        self.Thikness = Diameters[D][2] # Толщина перегородки в зависимости от диаметра аппарата
        self.OTL_buffle = self.Thikness+2*Design_clearance # Толщина "коридора" под перегородку с учетом конструктивного зазора (5мм)
        
        # Конвертируем массив перегородок в массив с координатами отрезков и типами перегородок
        self.GetBuffleType()
        
    def __repr__(self):
        return "<%s:%s [%s]>" %(self.x, self.y, self.Thikness)
       
    # Определяем координаты точек, по которым будут строиться линии, образующие "коридор" перегородки
    # (с учетом толщины перегородки и конструктивного зазора),
    # а также определяем тип каждой перегородки
    # (радиальная - центр находится в центре аппарата, остальные перегородки - с центром в любой другой точке)
    # пополняем этими данными массив BuffleTypes  
    def GetBuffleType(self):
        BuffleType = []            
        # рассчитываем переменные a, b, c, A, B, C, x1, x2, x3, x4, y1, y2, y3, y4 - промежуточные вычисления
        # для расчета координат X1, X2, X3, X4, Y1, Y2, Y3, Y4
        a = (self.x**2+self.y**2)**(0.5)
        b = a - self.OTL_buffle/2
        c = a + self.OTL_buffle/2

        A = self.OTL_buffle/2
        B = ((self.D_in/2)**2-b**2)**(0.5)
        C = ((self.D_in/2)**2-c**2)**(0.5)

        # x1 и X1
        if self.Angle == 0:
            x1 = (-1)*B
        elif self.Angle == 90:
            if (self.x-self.OTL_buffle/2)>0:
                x1 = self.x-(self.OTL_buffle/2)
            elif (self.x-self.OTL_buffle/2)<0:
                x1 = (self.x+self.OTL_buffle/2)
            else:
                x1 = 0                    
        else:
            x1 = (-1)*math.cos(math.radians(self.Angle))*(((self.D_in/2)**2-(self.OTL_buffle/2)**2)**0.5-math.tan(math.radians(self.Angle))*(self.OTL_buffle/2))
        #X1 = D/2 + x1

        # x2 и X2
        if self.Angle == 0:
            x2 = (-1)*x1
        elif self.Angle == 90:
            x2 = x1
        else:
            x2 = (self.D_in/2)*math.cos(math.radians(self.Angle)-math.asin(self.OTL_buffle/self.D_in))
        #X2 = D/2 + x2

        # x3 и X3
        if self.Angle == 0:
            x3 = (-1)*C
        elif self.Angle == 90:
            if (self.x - self.OTL_buffle/2) > 0:
                x3 = self.x + self.OTL_buffle/2
            elif (self.x - self.OTL_buffle/2) < 0:
                x3 = self.x - self.OTL_buffle/2
            else:
                x3 = 0
        else:
            x3 = (-1)*x2
        #X3 = D/2 + x3

        # x4 и X4
        if self.Angle == 0:
            x4 = (-1)*x3
        elif self.Angle == 90:
            x4 = x3
        else:
            x4 = (-1)*x1
        #X4 = D/2 + x4

        # y1 и Y1
        if self.Angle == 0:
            if self.y >= 0:
                y1 = self.y-(self.OTL_buffle/2)
            else:
                y1 = self.y+(self.OTL_buffle/2)
        elif self.Angle == 90:
            y1 = B
        else:
            y1 = (-1)*(math.sin(math.radians(self.Angle))*(((self.D_in/2)**2 - (self.OTL_buffle/2)**2)**0.5 - math.tan(math.radians(self.Angle))*(self.OTL_buffle/2)) + (self.OTL_buffle/2)/math.cos(math.radians(self.Angle)))
        #Y1 = D/2 - y1

        # y2 и Y2
        if self.Angle == 0:
            y2 = y1
        elif self.Angle == 90:
            y2 = (-1)*y1
        else:
            y2 = (self.D_in/2)*(math.sin(math.radians(self.Angle) - math.asin(self.OTL_buffle/self.D_in)))
        #Y2 = D/2 - y2

        # y3 и Y3
        if self.Angle == 0:
            if self.y >= 0:
                y3 = self.y + (self.OTL_buffle/2)
            else:
                y3 = self.y - (self.OTL_buffle/2)
        else:
            if self.Angle == 90:
                y3 = C
            else:
                y3 = (-1)*y2
        #Y3 = D/2 - y3

        # y4 и Y4
        if self.Angle == 0:
            y4 = y3
        elif self.Angle == 90:
            y4 = (-1)*y3
        else:
            y4 = (-1)*y1
        #Y4 = D/2 - y4

        if self.x == 0 and self.y == 0:
            Type = 'Радиальные перегородки'
            BuffleType = [Type, [x1, y1, x2, y2, x3, y3, x4, y4]]   

        else:
            Type = 'Остальные перегородки'
            BuffleType = [Type, [x1, y1, x2, y2, x3, y3, x4, y4]]  

        self.BuffleType = BuffleType
