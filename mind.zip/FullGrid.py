import math
import json
import itertools
from time import gmtime, strftime

from STHE.Heat.Import.TubePattern.Magic import *

def ConvertPC(PatternCharacter):
    if PatternCharacter == 'Треугольники':
        PC = 1
    if PatternCharacter == 'Повернутые треугольники':
        PC = 2
    if PatternCharacter == 'Квадраты':
        PC = 3
    if PatternCharacter == 'Коридорные квадраты':
        PC = 4
    return PC
   
def BuildGrid(ShellType_array = ['E', 'F'], N_tube_passes_array = [1,2,3,4,6,8,10,12,14,16,18,20], U_bend_array = [False, True]):
    Floating_head_array = [False, True]
    #U_bend_array = [[],[U_bend(0, TubePattern.d, TubePattern.D)]]
    PatternCharacter_array = ['Треугольники', 'Повернутые треугольники', 'Квадраты', 'Коридорные квадраты']
    Fluoroplastic_Seal_array = [False, True]
    # Формируем массив всех возможных комбинаций для обсчета
    Grid_For_Oleg = [] 
    count = 0
    #print('Плав головка/' + 'U/' + 'Кожух/' + 'Количество ходов/' + 'Разбивка/' + 'Фторопластовое уплотнение')
    #print()
    for x in (itertools.product(Floating_head_array, U_bend_array, ShellType_array, N_tube_passes_array, PatternCharacter_array, Fluoroplastic_Seal_array)):
        if not (x[0] == x[1] == True): # Исключаем случаи, когда одновременно плавающая головка и у-образник
            if not ((x[2] == 'F' or x[1] == True) and x[3] % 2 !=0): # Невозможно сочетания корпус F или у-образника и нечетного количества ходов в трубном
                if not (x[2] == 'F' and x[3] > 4): # Пока не выведена поправка z для корпуса F и количества ходов всех, кроме 2 и 4
                    Grid_For_Oleg.append(x)
                    #print(x)
                    count = count + 1
    #print('Число комбинаций:', count)  
    #print(Grid_For_Oleg)
    return Grid_For_Oleg


def Go(Grid_For_Oleg, d_arr = [16], Depth = False, filename='minD.sql'):
    
    Sum = 0
    D = 3200
    Design_clearance = 5
    Displacement_pipe = None
    VDS = False # Случай с VDS пока не рассматриваем
    #TubesByPass = None
    DStart = 0
    f = open(filename, 'w')
    A = 2*(math.acos(0.35))*180/math.pi 
    
    for d in d_arr:
        print('[',Sum,  strftime("%a, %d %b %Y %H:%M:%S +0000", gmtime()), '] Диаметр труб:', d)
        for i in Grid_For_Oleg:
            print('[',Sum, strftime("%a, %d %b %Y %H:%M:%S +0000", gmtime()), '] Сетка:',i)
            U_bend_array = []
            V_Buffle_array = []
            DShell_array = []
            Buffles = []
            U_bend_array = []
            DS = False
            if i[1] == True:
                if i[2] == 'E':
                    if i[3] == 2:
                        U_bend_array = [U_bend(0, d, D)]
                    else:
                        U_bend_array = [U_bend(90, d, D)]
                if i[2] == 'F':
                    U_bend_array = [U_bend(0, d, D)]

            if i[2] == 'F':
                DShell_array = [DShell(0, d, D, Design_clearance)] # Случай с VDS пока не рассматриваем
                DS = True

            PatternCharacter = i[4]
            if i[5]:
                a = 32
            else:
                if i[0]:
                    a = 26
                else:
                    a = 12
            #TubePattern1 = TubePattern(PatternCharacter, D, a, d, Design_clearance, Displacement_pipe, U_bend_array, V_Buffle_array, DShell_array, Buffles, TubesByPass)
            #TubePattern1.BuildTubes(0, 0, 0, 0)
            Flag = False
            N_tubes_in_pass = 1
            while Flag == False:
                #print(PatternCharacter, 'd:', d, '| Ходов:', i[3], '| Труб в ходу:', N_tubes_in_pass, Displacement_pipe, i[5], i[0], i[1], DS, VDS, Design_clearance)
                
                #print(PatternCharacter, d, i[3], N_tubes_in_pass, Displacement_pipe, i[5], i[0], i[1], DS, VDS, Design_clearance, DStart)
                
                Res = Magic(PatternCharacter, d, i[3], N_tubes_in_pass, Displacement_pipe, i[5], i[0], i[1], DS, VDS, Design_clearance, DStart, 0.01)
                
                if Res == False:
                    Flag = True
                else:
                    PC = ConvertPC(PatternCharacter)
                    if Displacement_pipe is None:
                        DP = 0
                    sql = "INSERT INTO UEMS_minD (md_PatternCharacter, md_d, md_N_tube_passes, md_N_tubes_in_pass, md_Displacement_pipe, md_Fluoroplastic_Seal, md_Floating_head, md_U, md_DS, md_VDS, md_Design_clearance, md_Passes, md_Tatianarray, md_Zazory, md_minD, md_TubesByRow, md_N_on_sum) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, '%s', '%s', %s, %s, '%s', %s);" % (PC, d, i[3], N_tubes_in_pass, DP, i[5], i[0], i[1], DS, VDS, Design_clearance, json.dumps(Res[1]), json.dumps(Res[2]), round(Res[3], 3), Res[4], json.dumps(sorted(list(Res[0].TubesByRow.keys()))), Res[7])
                    f.write(sql)
                    Sum += 1
                    #print('[', Sum, '] Пишем в базу вариант:', PC, d, N_tubes_in_pass, Res[4], 'Труб в ходу:', N_tubes_in_pass)

                    # Пробегаем все оставшиеся диаметры
                    Diams = []
                    if Depth:
                        Flag2 = False
                    else:
                        Flag2 = True
                    Di = Res[4]
                    while Flag2 == False:

                        if Di == False or Di == 3200:
                            break
                        DStart = Di
                        Res2 = Magic(PatternCharacter, d, i[3], N_tubes_in_pass, Displacement_pipe, i[5], i[0], i[1], DS, VDS, Design_clearance, DStart, 0.01)
                        #print(Res2)
                        #print(PatternCharacter, d, i[3], N_tubes_in_pass, Displacement_pipe, i[5], i[0], i[1], DS, VDS, Design_clearance, DStart)
                        PC = ConvertPC(PatternCharacter)
                        if Displacement_pipe is None:
                            DP = 0
                        # проверка неполную набивку
                        #print(Res2)
                        angle_alpha = Res2[2][0][3][0][0]
                        if angle_alpha <= A:
                            sql = "INSERT INTO UEMS_minD (md_PatternCharacter, md_d, md_N_tube_passes, md_N_tubes_in_pass, md_Displacement_pipe, md_Fluoroplastic_Seal, md_Floating_head, md_U, md_DS, md_VDS, md_Design_clearance, md_Passes, md_Tatianarray, md_Zazory, md_minD, md_TubesByRow, md_N_on_sum) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, '%s', '%s', %s, %s, '%s', %s);" % (PC, d, i[3], N_tubes_in_pass, DP, i[5], i[0], i[1], DS, VDS, Design_clearance, json.dumps(Res2[1]), json.dumps(Res2[2]), round(Res2[3], 3), Res2[4], json.dumps(sorted(list(Res2[0].TubesByRow.keys()))), Res2[7])
                            #DB_run(db_conn, sql)
                            f.write(sql)
                            Diams.append(Res2[4])
                            Sum += 1
                            #print(Res2[0].D_in)
                            #print(Res2)
                            #print(angle_alpha, A, Res2[0].D_in, Res2[0].N_on_sum)
                        else:
                            Flag2 = True
                            #print('   ->[', Sum, '] Дошли до диаметра:', Di, 'Труб в ходу:', N_tubes_in_pass, 'Добавлены диаметры:', Diams)
                            #print('Слишком мало труб в диаметре:', Res2[0].D_in, Diams)
                        Di = NextD(Diameters, Di)
                    DStart = 0
                    N_tubes_in_pass += 1
                    Sum += 1
    f.close()
                
Grid_For_Oleg = BuildGrid(ShellType_array = ['E'], N_tube_passes_array = [20])
print(Grid_For_Oleg, len(Grid_For_Oleg))
d_arr = [57,20,12,16,10,25,32,38,57]
d_arr = [25]
Go(Grid_For_Oleg, d_arr, True, 'minD_deep_25_20.sql')
